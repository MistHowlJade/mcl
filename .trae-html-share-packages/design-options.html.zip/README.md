# MCL · 新一代我的世界启动器

> 为解决第三方启动器（PCL2 / HMCL / BakaXL / MultiMC / Prism / ATLauncher）的痛点而生。
>
> 设计依据：《我的世界启动器痛点大全 v4》（117 条痛点）与《第三方启动器痛点词频报告》（741 条 GitHub Issue 语料，18 类痛点分类）。本文档按这两份文档逐条映射，标注 MCL 如何解决。

---

## 一、为什么是 MCL

第三方启动器没有一款是全能的：下载快选 PCL，开源跨平台选 HMCL，多实例管理选 Prism——玩家只能"混用三件套"，还要忍受格式不互通、账号割裂、错误信息看不懂。MCL 的目标：**一个启动器，把 P0 痛点一次性解决掉。**

| 痛点维度（词频报告） | 提及占比 | 优先级 | MCL 的解法 |
|---|---|---|---|
| UI/界面 | 55% | P1 | 深色游戏库设计系统（石墨黑 + 翡翠绿、实例封面驱动）、高 DPI 缩放（100–200%）、设置项全部带人话解释 |
| 模组/整合包 | 52% | **P0** | Modrinth 直装/搜索、模组体检（重复/损坏/异加载器）、Modrinth/CurseForge/MultiMC 整合包自动识别导入（嵌套目录也能识别） |
| 报错提示/日志 | 43% | **P0** | **崩溃分析器**：常见错误人话翻译 + 一键修复（换 Java / 调内存 / 修库 / 清 natives） |
| 下载问题 | 33% | **P0** | 多线程分段下载、BMCLAPI↔官方自动择优与兜底、断点续传、SHA-1 校验失败自动重下备用源 |
| 安装/文件 | 30% | P0 | 一键修复（重新校验并修复损坏库），替代危险民间技巧"关闭文件校验" |
| 更新问题 | 30% | P1 | "禁止 Mod 更新"实例级开关（痛点 #41）、保守更新策略 |
| 版本管理/隔离 | 28% | P1 | 实例 = 完全隔离的 .minecraft；共享库/资源零拷贝，根治磁盘膨胀 |
| 存档/数据 | 22% | P1 | 启动前自动备份 + 恢复前自动再备份；手动备份/恢复/删除 |
| 崩溃/闪退 | 20% | P1 | 残余进程启动前自动清理；崩溃即自动分析；natives 按次唯一目录 |
| Java 环境 | 19% | **P1**（伤害最高） | **自动匹配/下载 Temurin**：1.16.5↓=Java 8、1.17–1.20.4=Java 17、1.20.5+ =Java 21；64 位检测；8u291 TLS1.3 警告；绝不瞎选 |
| 服务端/联机 | 18% | P2 | **内置服务器管理**：原版/Fabric/Quilt/Forge/NeoForge 一键安装、启停、控制台、server.properties、世界备份，Java 与版本自动对齐 |
| 内存/性能 | 16% | P1 | 内存三预设（低配 2G / 标准 4G / 大型整合包·光影 8G + Aikar G1GC 参数） |
| 启动失败 | 13% | P0 | 启动前校验 + 库完整性修复 + 人话报错 |
| 登录/账号 | 10% | P2（低频高伤） | 微软设备码登录（国内网络可用）、离线账号、令牌过期自动刷新、XErr 错误码人话翻译、系统时间偏移检测 |
| 网络/代理 | 10% | P2 | HTTP/HTTPS 代理（下载/API/登录）、镜像测速选择器、超时可调、失败自动换源 |
| 多语言/本地化 | 6% | P1 | 简体中文 UI、全部设置带中文解释 |
| 皮肤/披风 | 6% | P2 | 离线账号本地皮肤/披风预览（64×64 PNG）；微软账号一键上传/恢复官方皮肤（Mojang API） |
| 杀软/误报 | 2% | P2（低频高伤） | 完全开源（MIT）、可审计、零遥测、只下载官方游戏文件、不捆绑任何东西 |

### 痛点大全 v4 逐条映射（摘要）

| # | 痛点 | MCL |
|---|---|---|
| 1 | Java 版本匹配地狱 | ✅ 按 MC 版本自动选 Java，缺失自动下载 Temurin |
| 2 | 教程过时误导 | ✅ MCL 自身不需要本机 Java（框架级自动管理） |
| 3 | 32 位 Java 陷阱 | ✅ 检测并标注 32 位；自动下载 64 位 Temurin |
| 4 | 多 Java 共存冲突 | ✅ 自动检测列表 + 按版本精确匹配，不瞎选 |
| 5 | Java 路径选择反人类 | ✅ 永远不需要填路径（高级项可选） |
| 6 | JVM 参数玄学 | ✅ 三预设 + 空/换行分隔的自定义参数，全部带解释 |
| 7 | 启动器自身运行依赖 | ✅ Electron 打包，用户无需安装 Java/.NET |
| 9 | 单线程下载慢 | ✅ 多线程 + Range 分段下载（≥4MB 文件） |
| 10 | 镜像源不稳定 | ✅ 双源自动切换 + 测速选择器 + 失败重试 |
| 11 | 下载卡 0% / 静默失败 | ✅ 分级超时，错误信息明确到"哪个文件、为什么" |
| 12 | 校验失败死循环 | ✅ SHA-1 不匹配自动删损坏文件重下备用源 |
| 13 | 并发下载卡死 | ✅ 有界队列 + 取消支持 |
| 14 | API 超时阈值不合理 | ✅ 全局 15s 超时可调；Modrinth 查询带超时与重试 |
| 16 | 依赖库下载地狱 | ✅ 断点续传（.part/.seg）、并发、失败隔离不整体重来 |
| 17 | 微软 OAuth 参差 | ✅ 标准设备码流程 + XBL/XSTS/MC 完整链路 |
| 18 | 错误码难懂 | ✅ 0x801901f4 类错误 → XErr 人话表（2148916233/38…） |
| 19 | 登录依赖系统组件 | ✅ 报错直接定位（含系统时间偏移检测） |
| 20 | 系统时间静默阻断 | ✅ 检测服务器 Date 头与本机时差，>5 分钟直接告诉你 |
| 22 | 多账号切换繁琐 | ✅ 账号列表一键切换，令牌自动刷新 |
| 24 | 名字困惑 | ✅ 界面标注"微软玩家名（与 Xbox 代号不同）"语义 |
| 25 | 闪退无提示 | ✅ 退出码非 0 自动进入崩溃分析，人话标题 |
| 26 | 崩溃报告读不懂 | ✅ 堆栈 → 人话 + 一键修复按钮 |
| 27 | 崩溃归因难 | ✅ 已知模式库 + 兜底关键行定位 |
| 29 | 配置/存档全搅 | ✅ 实例隔离 + 版本级目录 |
| 30 | 日志难获取 | ✅ 日志页 + 一键导出诊断包（已脱敏） |
| 31 | 残余进程死循环 | ✅ 启动前自动 taskkill 本启动器上次启动的进程 |
| 32 | 显卡驱动黑屏 | ✅ 崩溃分析器识别 OpenGL/GLFW 模式 |
| 33 | 加载器版本矩阵 | ✅ 创建实例时引导选版本，Oracle/Fabric/Quilt/Forge/NeoForge |
| 35 | 整合包导入失败 | ✅ 嵌套目录剥离 + 三格式识别（mrpack/manifest/mmc） |
| 36 | 作者锁下载渠道 | ✅ 无密钥 → 创建实例 + 逐项手动下载链接，不静默失败 |
| 37 | 中文搜索爆炸 | ✅ 默认按下载量排序，相关度可切换 |
| 38 | mod 列表加载失败 | ✅ 统一 20s 超时 + 人话错误提示 |
| 39 | 整合包格式不统一 | ✅ 一个导入器覆盖 mrpack/manifest/mmc 三格式 |
| 40 | 更新/回滚无快照 | ✅ 启动前自动备份 + 手动备份 + 恢复前再备份 |
| 41 | 玩家误更新 mod | ✅ 实例级"禁止 Mod 自动更新"开关 |
| 42 | mods 目录混乱 | ✅ 模组体检：重复检测 + 零字节检测 + 异加载器检测 |
| 43 | 不隔离就互踩 | ✅ 每个实例 = 独立 game 目录 |
| 44 | 隔离方案不一致 | ✅ MCL 一种方案，不为难你 |
| 45 | 换启动器迁移痛苦 | ✅ 迁移中心：HMCL/PCL2/Prism/MultiMC/.minecraft 一键预览导入 |
| 46 | 换电脑/云同步 | ✅ WebDAV 完整快照（可选存档）+ GitHub Gist 仅配置同步；绝不上传账号令牌与密钥 |
| 47 | 备份机制缺失 | ✅ 默认开启启动前自动备份 |
| 48 | 磁盘占用失控 | ✅ 库/资源全实例共享（引用不复制），唯一目录方案 |
| 50–54 | 杀软/信任 | ✅ 开源 + 零遥测 + 仅下载官方文件 + 无捆绑 |
| 55 | 卡"正在开始安装" | ✅ 下载进度可见、失败原因可见、可重试 |
| 56 | natives 被占用 | ✅ 按次唯一 natives 目录，天然规避 |
| 57 | 运行库损坏 | ✅ 一键修复：SHA-1 校验 → 仅重下损坏文件 |
| 58 | "关闭校验"民间技巧 | ✅ 修复代替关校验，默认绝不暴露"关闭校验"选项 |
| 60 | 假整合包自带环境 | ✅ MCL 不执行第三方启动脚本 |
| 61 | 误双击 minecraft.jar | ✅ 新手动线：MCL 就是唯一入口 |
| 62 | 内存分配两难 | ✅ 三预设 + Aikar 参数（heavy 预设） |
| 63 | 启动器自身吃资源 | ✅ Electron + 单实例锁；空闲零占用游戏资源 |
| 64 | 高 DPI 适配差 | ✅ 内置 100–200% 界面缩放 + 全 rem 布局 |
| 65 | 非 UTF-8 乱码闪退 | ✅ 默认注入 UTF-8 文件编码参数 |
| 66 | 设置项无解释 | ✅ 每个设置带人话 Tip |
| 67 | 更新破坏兼容 | ✅ 语义化版本、保守发布 |
| 68 | 新手第一道墙 | ✅ 零配置：选版本→点启动，Java 自动搞定 |
| 70–72 | 皮肤 | ✅ 离线皮肤/披风本地预览；微软账号上传/恢复官方皮肤；界面明确说明"离线皮肤他人不可见"是离线模式设计 |
| 74 | 旧 Java TLS 不兼容 | ✅ 自动识别 <8u291 并警告 + 一键切换 |
| 生态 #5 | Log4j 防护 | ✅ 1.17 以下自动附加格式校验关闭参数 |
| 3.4 | 功能矩阵各有硬伤 | ✅ 下载（多线程）+ 开源（MIT）+ 自动 Java + 隔离，四合一 |
| 3.2 | 数据不互通 | ✅ 搬进来：迁移中心一键导入；搬出去：导出 MultiMC/Prism 实例、Modrinth `.mrpack`、MCL 完整快照 |

---

## 二、功能总览

- 🚀 **启动台**：当前账号、实例卡片、一键启动、实时日志、崩溃直达修复；**游玩统计**（最近 7 天趋势、按实例累计，只存本机）
- ⌨️ **快捷键**：`Ctrl+Enter` 启动当前实例、`Ctrl+K` 聚焦搜索、`Alt+1~9` 快速切页
- 📦 **实例管理**：创建/复制/删除（先备份）、磁盘占用统计、**标签/收藏/搜索/排序**、禁止 Mod 更新开关、高级设置（Java 路径 / 实例 JVM 参数 / 独立分辨率）、**游戏设置可视化**（图形化改常用 `options.txt` 项，游戏运行时拒绝写入）、**实例导出**（MultiMC/Prism、Modrinth `.mrpack`、MCL 完整 ZIP）
- 🖥️ **服务器管理**：原版 / Fabric / Quilt / Forge / NeoForge 一键安装，启停、实时控制台与命令、server.properties 可视化编辑、端口检测、EULA 门禁、世界备份/恢复，退出启动器自动结束服务端；**局域网世界扫描**（224.0.2.60:4445，一键复制连接地址）
- 🧩 **模组中心**：Modrinth 搜索直装（按实例版本/加载器过滤）、已安装列表、更新检查、**模组体检**（解析 jar 元数据，发现重复/损坏/异加载器模组并一键隔离）、整合包导入（也可直接把 `.mrpack` / `.zip` **拖进启动器窗口**）
- 🎨 **内容管理**：资源包 / 光影包 / 截图 / 世界集中管理；**Modrinth 在线下载**资源包/光影/世界；世界支持文件夹导入、**ZIP 导入/导出**；启用状态直接写入 `options.txt`、`iris.properties`、`optionsshaders.txt`；删除世界前自动打包备份
- 📥 **下载任务**：游戏文件 / 模组 / 资源包 / 整合包 / Java / 更新 / 服务端统一进度面板，带速度、成功失败记录、取消（游戏文件）、重试与打开目录；记录只含元数据，不含下载内容
- 💾 **存档备份**：启动前自动备份、手动备份、恢复前自动再备份、保留份数可配
- 🩺 **崩溃分析**：已知错误模式库（OOM / Java 版本 / Mixin / 缺前置 / natives / OpenGL / TLS / 模块化）→ 人话解释 + 一键修复；粘贴日志即可分析任意文本
- 🚚 **迁移中心**：自动发现 HMCL / PCL2 / Prism / MultiMC / .minecraft，预览后批量导入存档/模组/配置/资源包（库与资源不复制，共享目录按需下载）
- ☁️ **云同步**：WebDAV（完整快照，可选存档）或 GitHub Gist（仅配置）；账号令牌、CurseForge 密钥、云同步凭据永不进入快照
- 👤 **账号**：微软设备码登录（含 XErr 人话翻译与系统时间偏移检测）、离线账号、本地皮肤/披风预览、微软账号官方皮肤上传与恢复
- 📜 **日志**：启动器日志 + 游戏 latest.log，可搜索（error/mixin/OOM 直筛）
- ⚙️ **设置**：每个选项带人话解释（界面 DPI / 默认分辨率 / 启动确认 / 崩溃日志 / 全局 JVM 参数 / 镜像源测速 / Java 检测与**一键装 Java 8/17/21** / 内存 / HTTP 代理 / 云同步 / 更新下载 / 缓存清理）

---

## 三、构建与开发

```bash
npm install        # 安装依赖（需要 Node.js 18+）
npm run dev        # 开发模式（Vite HMR + Electron）
npm run typecheck  # 类型检查
npm run build      # 产物：dist/（渲染进程）+ electron-dist/（主进程）
npm run verify     # typecheck + build + 逻辑冒烟（39 项，CI 同款）
npm run start      # 运行构建产物
npm run package         # 单文件便携 exe：release/versions/便携版/MCL-<版本>-portable-x64.exe
npm run package:dir     # 零依赖目录/ZIP：release/versions/稳定版/
npm run package:dir:dev # 开发版（自动开 DevTools）：release/versions/开发版/
npm run package:versions # 一条命令产出上面三个版本
```

三条打包命令的产物统一放在 `release/versions/` 下：`稳定版/`（免安装目录 + ZIP，日常使用）、`开发版/`（免安装目录 + ZIP，启动自动开 DevTools、界面显示“开发版”）、`便携版/`（单文件 exe）。`npm run package:versions` 会依次构建三者。

`npm run package` 使用 **electron-builder** 生成单文件便携 exe（一个 `MCL.exe`，双击即运行，对标 PCL2）。electron-builder 只是打包用 devDependency，运行时仍然零第三方依赖（React 已由 Vite 打进 `dist/`）。打包源已固化 npmmirror 镜像，国内网络可直接构建；Linux 交叉打包通过 `win.signAndEditExecutable: false` 跳过 wine 依赖，代价是 exe 不写入 PE 图标/版本信息，不影响运行。单文件体积较大（内含 Electron 运行时），启动时会解压到临时目录，未签名会触发 Windows SmartScreen 提示。NSIS 固定用 3.0.5.0 并解压到系统临时目录（纯 ASCII 路径）——默认的 3.0.4.1 或中文路径都会让大包构建报 `error creating mmap`。

`npm run package:dir` 是原来的零依赖打包脚本，生成免安装目录与便携 ZIP。**默认就是 PCL2 / HMCL 式便携布局**：打包态所有数据（`shared/libraries|assets|versions`、`instances/`、`java/`、`cache/` 等）都写在启动器旁边的 `mcl-data/`，拷走整个文件夹即带走全部游戏本体与资源；只有启动器目录不可写（如装在 Program Files）时才退回 `%APPDATA%/mcl`。单文件 exe 的 `mcl-data/` 会创建在 exe 同级目录。保留兼容：exe 同级放空的 `portable.txt` 仍会强制使用该目录。已有 `%APPDATA%/mcl` 数据不会自动迁移，需要保留时把该文件夹改名为启动器旁的 `mcl-data`。

> 仓库约定：`master` 已开启分支保护，**禁止任何直接 push**（管理员也一样）。所有更改需先推到临时分支、提 PR 并合并；不要绕过该流程覆盖远程历史。

### 目录结构

```
electron/
  main.ts            主进程入口（单实例锁、无边框窗口、残余进程清理、mcl-media:// 本地图片协议）
  preload.ts         渲染桥（contextIsolation + sandbox）
  shared/types.ts    两端共享类型
  services/
    downloader.ts    多线程分段下载引擎（断点续传/SHA-1/镜像切换）
    tasks.ts         下载任务中心（进度/速度/取消/重试，只持久化元数据）
    version.ts       版本清单/inheritsFrom 合并/库与资源规划
    minecraft.ts     启动管线（natives 唯一目录、classpath、Aikar 参数、全局 JVM 参数）
    java.ts          Java 检测/推荐/自动下载（Adoptium）
    auth.ts          微软设备码 + XBL/XSTS/MC 链路 + 离线账号 + 皮肤/披风
    server.ts        服务端生命周期（Vanilla/Fabric/Quilt/Forge/NeoForge 安装、控制台、备份）
    cloud.ts         云同步（WebDAV 快照 / GitHub Gist 配置，快照脱敏）
    exporter.ts      实例导出（MultiMC/Prism、mrpack、完整 ZIP）
    content.ts       资源包/光影/截图/世界管理（开关写入 options.txt；世界 ZIP 导入/导出）
    update.ts        启动器更新检查 + 安装包下载（GitHub Release，不自动替换程序）
    modrinth.ts      Modrinth API（模组/整合包/资源包/光影/世界 搜索、安装、更新检查）
    proxy.ts         HTTP/HTTPS 代理（CONNECT 隧道，零依赖，游戏 JVM 参数注入）
    lan.ts           局域网世界扫描（UDP 224.0.2.60:4445）
    modpack.ts       整合包导入（modrinth/curseforge/mmc，嵌套剥离）
    modhealth.ts     模组体检（jar 元数据解析）
    backup.ts        存档备份（zip 读写，零依赖）
    crash.ts         崩溃模式库 → 人话 + 一键修复
    migrate.ts       其它启动器扫描/预览/导入
    diagnostic.ts    诊断包导出（已脱敏）
    zip.ts           零依赖 ZIP 读写；流式写入 + ZIP64（>4GB / 65535 条目），防解压炸弹
src/                 React 渲染进程（启动台/实例/服务器/模组/下载任务/内容/备份/崩溃/迁移/账号/云同步/日志/设置）
```

**所有数据收敛到一个文件夹**：打包态以启动器旁边的 `mcl-data/` 为唯一数据根，里面既有游戏本体/共享库/资源/实例/存档/模组/Java/下载缓存，也有 Electron 自身的 `electron-user-data/`、`electron-cache/`、`electron-logs/`、`electron-crash-dumps/`。`app.setPath()` 在 `app.whenReady()` 之前完成，不会在 `%APPDATA%` 留下散落目录；拷走整个 `mcl-data/` 即带走全部数据。打包期间的 Electron / electron-builder 缓存也统一放在项目根目录 `.build-cache/`（已在 `.gitignore`）。

## 四、安全与信任（为什么 MCL 不骗你装 Java）

1. **开源**（MIT），每一行可审计。
2. **零遥测**：没有任何统计、上报、联网行为（除你操作的下载/登录/API 请求外）。
3. **游戏本体仅从 Mojang 官方渠道下载**（或你自己选择的社区镜像，失败自动切换官方）——MCL 不修改、不重新分发游戏文件。
4. **微软登录全程在官方页完成**，MCL 不接触你的密码；令牌只存本机 `accounts.json`。
5. **无捆绑**：没有全家桶、没有赞助解锁、没有"金山毒霸"式安装器。
6. 诊断包导出会自动剔除 API 密钥等敏感信息（CurseForge Key、WebDAV 地址/账号/密码、GitHub Token/Gist ID、代理地址/账号/密码）。
7. 云同步只使用你自己的 WebDAV / GitHub 账号，MCL 没有中间服务器；快照绝不包含 `accounts.json`、微软令牌与任何密钥。

## 五、路线图

- ✅ 云存档/配置同步（WebDAV 完整快照 / GitHub Gist 仅配置）
- ✅ 双向导出（MCL → MultiMC/Prism、Modrinth `.mrpack`、完整实例 ZIP）
- ✅ 服务端管理：一键开服、加载器安装、控制台、server.properties、世界备份
- ✅ 微软账号皮肤上传/恢复；离线皮肤与披风预览
- ✅ HTTP/HTTPS 代理（下载 / API / 微软登录 / 云同步 + 游戏 JVM 参数）
- ✅ Modrinth 在线下载资源包 / 光影 / 世界；世界 ZIP 导入导出；实例复制
- ✅ 局域网世界扫描（224.0.2.60:4445）与一键复制连接地址
- ✅ 单文件便携 exe `npm run package`（PCL2 式一个 exe）；零依赖目录/ZIP 备选 `npm run package:dir`
- ⬜ 离线模式下经材质包注入他人可见的皮肤（社区方案，存在兼容性风险）
- ⬜ macOS / Linux 体验打磨（开发环境即 Windows，当前优先 Windows）
- ⬜ 代码签名（需要证书，当前开发版未签名，Defender 可能提示，请核对签名与源码一致）

## 六、人工复测

开发阶段只做了静态验证（`npm run typecheck` / `npm run build` / `node scripts/smoke-check.js`），
未实际启动游戏或登录账号。完整的真机验证步骤见 [VERIFY.md](VERIFY.md)，欢迎按清单复测并提 Issue。

## 七、免责声明

MCL 是第三方启动器，与 Mojang Studios / Microsoft / CurseForge 无关联。Minecraft 是 Mojang 的商标。
下载游戏本体需遵守 Mojang 的使用条款；MCL 只下载你本就有权获取的官方文件。

## License

MIT © 2026 MCL Contributors
