"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.downloadTasks = void 0;
/**
 * 下载任务中心：把启动器发起的所有下载/安装汇总成一份可查看的清单。
 * - 只持久化任务元数据（名字、进度、时间、结果），不缓存任何下载内容
 * - 进度由各业务在已有回调里上报，不改动下载引擎本身
 * - 失败/完成状态写盘，重启启动器后仍能看到最近发生过什么
 */
const events_1 = require("events");
const paths = __importStar(require("./paths"));
const store_1 = require("./store");
const MAX_TASKS = 60;
const KINDS = ['launch', 'mod', 'resourcepack', 'shader', 'world', 'modpack', 'java', 'update', 'server', 'other'];
const STATUSES = ['running', 'done', 'failed', 'canceled'];
function isAction(value) {
    if (!value || typeof value !== 'object')
        return false;
    const a = value;
    if (a.openDir !== undefined && typeof a.openDir !== 'string')
        return false;
    if (a.revealFile !== undefined && typeof a.revealFile !== 'string')
        return false;
    if (a.retry !== undefined) {
        if (!a.retry || typeof a.retry !== 'object')
            return false;
        const r = a.retry;
        if (r.type === 'update')
            return true;
        if (r.type === 'java')
            return Number.isInteger(r.major);
        if (r.type === 'modpack')
            return typeof r.filePath === 'string';
        if (r.type === 'launch')
            return typeof r.instanceId === 'string';
        return false;
    }
    return true;
}
/** 磁盘里的旧记录可能来自手工编辑/旧版本：逐字段校验后再进入内存，避免界面崩掉 */
function normalizeTask(value) {
    if (!value || typeof value !== 'object')
        return null;
    const t = value;
    if (typeof t.id !== 'string' || typeof t.name !== 'string')
        return null;
    if (!KINDS.includes(t.kind) || !STATUSES.includes(t.status))
        return null;
    const num = (v, fallback = 0) => typeof v === 'number' && Number.isFinite(v) && v >= 0 ? v : fallback;
    const out = {
        id: t.id,
        name: t.name.slice(0, 200),
        kind: t.kind,
        status: t.status,
        bytesDone: num(t.bytesDone),
        bytesTotal: num(t.bytesTotal),
        speed: num(t.speed),
        startedAt: num(t.startedAt, Date.now()),
    };
    if (typeof t.finishedAt === 'number')
        out.finishedAt = t.finishedAt;
    // 取消回调只存在于本次进程内，重启后不能再取消旧任务
    out.cancelable = false;
    if (typeof t.error === 'string')
        out.error = t.error.slice(0, 500);
    if (isAction(t.action))
        out.action = t.action;
    // 上次启动时被强制关闭的「运行中」任务没有结束回合，标成取消，避免永远转圈
    if (out.status === 'running')
        out.status = 'canceled';
    return out;
}
class DownloadTasks extends events_1.EventEmitter {
    constructor() {
        super(...arguments);
        this.tasks = [];
        this.loaded = false;
        /** 相邻两次进度的采样点，用来估算瞬时速度 */
        this.samples = new Map();
        /** 内存中的取消回调：不写盘，进程重启后自然失效 */
        this.cancelers = new Map();
    }
    ensureLoaded() {
        if (this.loaded)
            return;
        this.loaded = true;
        const raw = (0, store_1.readJson)(paths.tasksFile(), []);
        this.tasks = Array.isArray(raw)
            ? raw.map(normalizeTask).filter((t) => !!t).slice(0, MAX_TASKS)
            : [];
    }
    persist() {
        try {
            (0, store_1.writeJson)(paths.tasksFile(), this.tasks.slice(0, MAX_TASKS));
        }
        catch { /* 记录写失败不影响下载本身 */ }
    }
    changed() { this.emit('changed'); }
    list() {
        this.ensureLoaded();
        return this.tasks.map(t => ({ ...t }));
    }
    /** 开始一个任务，返回 id 供后续上报 */
    begin(kind, name, action) {
        this.ensureLoaded();
        const id = `${Date.now().toString(36)}-${Math.random().toString(36).slice(2, 8)}`;
        const task = {
            id,
            name: String(name ?? '').slice(0, 200) || '下载任务',
            kind: KINDS.includes(kind) ? kind : 'other',
            status: 'running',
            bytesDone: 0,
            bytesTotal: 0,
            speed: 0,
            startedAt: Date.now(),
        };
        if (isAction(action))
            task.action = action;
        this.tasks.unshift(task);
        this.tasks = this.tasks.slice(0, MAX_TASKS);
        this.samples.set(id, { at: Date.now(), done: 0 });
        this.persist();
        this.changed();
        return id;
    }
    /** 登记本次进程内可取消的任务（如游戏文件下载） */
    setCanceler(id, cancel) {
        const task = this.tasks.find(t => t.id === id);
        if (!task || task.status !== 'running')
            return;
        this.cancelers.set(id, cancel);
        task.cancelable = true;
        this.changed();
    }
    /** 传输进度：total 可以后到（HEAD 探测后），只增不减地记录 */
    progress(id, bytesDone, bytesTotal) {
        const task = this.tasks.find(t => t.id === id);
        if (!task || task.status !== 'running')
            return;
        const done = Number.isFinite(bytesDone) && bytesDone >= 0 ? bytesDone : task.bytesDone;
        if (typeof bytesTotal === 'number' && Number.isFinite(bytesTotal) && bytesTotal >= 0) {
            task.bytesTotal = bytesTotal;
        }
        const now = Date.now();
        const last = this.samples.get(id) ?? { at: now - 200, done: task.bytesDone };
        const elapsed = now - last.at;
        if (elapsed >= 200 && done >= last.done) {
            // 平滑一下：相邻采样间隔太短时速度会跳得厉害
            task.speed = Math.round(((done - last.done) * 1000) / elapsed);
            this.samples.set(id, { at: now, done });
        }
        task.bytesDone = done;
        this.changed();
    }
    /** 给没有精确字节流任务用的简单进度：直接把总量视为已完成 */
    done(id, action) {
        const task = this.tasks.find(t => t.id === id);
        if (!task || task.status !== 'running')
            return;
        task.status = 'done';
        task.bytesDone = task.bytesTotal > 0 ? task.bytesTotal : task.bytesDone;
        task.speed = 0;
        task.finishedAt = Date.now();
        if (isAction(action))
            task.action = { ...(task.action ?? {}), ...action };
        task.cancelable = false;
        this.samples.delete(id);
        this.cancelers.delete(id);
        this.persist();
        this.changed();
    }
    fail(id, error, action) {
        const task = this.tasks.find(t => t.id === id);
        if (!task || task.status !== 'running')
            return;
        task.status = 'failed';
        task.error = String(error ?? '未知错误').slice(0, 500);
        task.speed = 0;
        task.finishedAt = Date.now();
        if (isAction(action))
            task.action = { ...(task.action ?? {}), ...action };
        task.cancelable = false;
        this.samples.delete(id);
        this.cancelers.delete(id);
        this.persist();
        this.changed();
    }
    cancel(id) {
        const task = this.tasks.find(t => t.id === id);
        if (!task || task.status !== 'running')
            return;
        const cancel = this.cancelers.get(id);
        this.cancelers.delete(id);
        task.cancelable = false;
        if (cancel) {
            try {
                cancel();
            }
            catch { /* 取消失败也不影响记录状态 */ }
        }
        task.status = 'canceled';
        task.speed = 0;
        task.finishedAt = Date.now();
        this.samples.delete(id);
        this.persist();
        this.changed();
    }
    clearFinished() {
        this.ensureLoaded();
        this.tasks = this.tasks.filter(t => t.status === 'running');
        this.persist();
        this.changed();
    }
    remove(id) {
        this.tasks = this.tasks.filter(t => t.id !== id);
        this.samples.delete(id);
        this.cancelers.delete(id);
        this.persist();
        this.changed();
    }
}
exports.downloadTasks = new DownloadTasks();
