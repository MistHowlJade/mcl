"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.importModpack = importModpack;
/**
 * 整合包导入：自动识别格式 + 嵌套目录剥离（痛点 #35/#39）
 * 支持：Modrinth (modrinth.index.json) / CurseForge (manifest.json) / MultiMC 系 (mmc-pack.json)
 * CurseForge 官方 API 需要密钥；没有密钥时给出逐项下载链接，绝不悄悄失败（痛点 #36）
 */
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const zip_1 = require("./zip");
const instances_1 = require("./instances");
const paths = __importStar(require("./paths"));
const net_1 = require("./net");
const downloader_1 = require("./downloader");
const settings_1 = require("./settings");
/** 在 zip 中查找打包格式的入口文件（允许嵌套 ≤4 层目录），返回剥离前缀 */
function findPackRoot(entries) {
    const candidates = [
        { file: 'modrinth.index.json', format: 'modrinth' },
        { file: 'manifest.json', format: 'curseforge' },
        { file: 'mmc-pack.json', format: 'mmc' },
        { file: 'instance.json', format: 'mcl' },
    ];
    for (const { file, format } of candidates) {
        const hit = entries.find(e => {
            const norm = e.name.replace(/\\/g, '/');
            const segs = norm.split('/').filter(Boolean);
            return segs[segs.length - 1] === file && segs.length - 1 <= 4;
        });
        if (hit) {
            // 必须用归一化后的路径计算前缀，Windows 打包的 ZIP 可能用反斜杠
            const norm = hit.name.replace(/\\/g, '/');
            const idx = norm.lastIndexOf('/');
            return { format, prefix: idx >= 0 ? norm.slice(0, idx + 1) : '' };
        }
    }
    return null;
}
const stripPrefix = (name, prefix) => name.replace(/\\/g, '/').slice(prefix.length);
/** 远程文件名净化：去掉目录成分，杜绝 ../ 路径穿越 */
const sanitizeRemoteName = (name) => {
    const base = String(name).replace(/\\/g, '/').split('/').filter(Boolean).pop() ?? '';
    return base || `file-${Date.now()}`;
};
const safeTarget = (root, rel) => {
    const target = path.resolve(root, rel);
    return target.startsWith(path.resolve(root) + path.sep) ? target : null;
};
async function importModpack(zipPath, targetName, onLog) {
    const log = onLog ?? (() => { });
    const entries = await (0, zip_1.zipListFromFile)(zipPath);
    const root = findPackRoot(entries);
    if (!root) {
        return { instanceId: null, format: 'unknown', importedMods: 0, skippedFiles: [], warnings: ['无法识别的整合包格式：找不到 modrinth.index.json / manifest.json / mmc-pack.json。支持 Modrinth、CurseForge 与 MultiMC 整合包。'] };
    }
    const { format, prefix } = root;
    log(`识别到 ${format} 格式整合包${prefix ? `（根目录：${prefix}）` : ''}`);
    const readEntry = async (fileName) => {
        const hit = entries.find(e => e.name.replace(/\\/g, '/') === prefix + fileName);
        if (!hit)
            return null;
        // 只读元数据小文件；用文件级解压避免把整个整合包读进内存
        const tmp = path.join(paths.cacheDir(), `modpack-meta-${Date.now()}-${process.pid}-${Math.random().toString(36).slice(2, 8)}.bin`);
        try {
            await (0, zip_1.zipExtractEntryToFile)(zipPath, hit, tmp);
            return fs.readFileSync(tmp);
        }
        finally {
            fs.rmSync(tmp, { force: true });
        }
    };
    const warnings = [];
    const skippedFiles = [];
    const copyOverrides = async (overridesDirName, destGameDir) => {
        const overPrefix = prefix + overridesDirName + '/';
        let count = 0;
        for (const entry of entries) {
            const norm = entry.name.replace(/\\/g, '/');
            if (!norm.startsWith(overPrefix) || norm.endsWith('/'))
                continue;
            const rel = stripPrefix(norm, overPrefix);
            const target = safeTarget(destGameDir, rel);
            if (!target) {
                warnings.push(`已跳过可疑路径：${norm}`);
                continue;
            }
            try {
                fs.mkdirSync(path.dirname(target), { recursive: true });
                await (0, zip_1.zipExtractEntryToFile)(zipPath, entry, target);
                count++;
            }
            catch (e) {
                // 单个覆盖文件失败不应让整个整合包导入中断，记录下来让用户知道
                warnings.push(`覆盖文件写入失败：${norm}（${e instanceof Error ? e.message : String(e)}）`);
            }
        }
        return count;
    };
    if (format === 'modrinth') {
        let index;
        try {
            index = JSON.parse((await readEntry('modrinth.index.json')).toString('utf8'));
        }
        catch {
            throw new Error('整合包索引 modrinth.index.json 不是有效 JSON，文件可能已损坏。');
        }
        const mcVersion = String(index?.dependencies?.minecraft ?? '1.20.1');
        let loader = 'vanilla';
        let loaderVersion = null;
        if (index?.dependencies?.['fabric-loader']) {
            loader = 'fabric';
            loaderVersion = String(index.dependencies['fabric-loader']);
        }
        else if (index?.dependencies?.['quilt-loader']) {
            loader = 'quilt';
            loaderVersion = String(index.dependencies['quilt-loader']);
        }
        else if (index?.dependencies?.forge) {
            loader = 'forge';
            loaderVersion = String(index.dependencies.forge);
        }
        else if (index?.dependencies?.neoforge) {
            loader = 'neoforge';
            loaderVersion = String(index.dependencies.neoforge);
        }
        const instance = (0, instances_1.createInstance)({ name: targetName ?? index.name ?? 'Modrinth 整合包', mcVersion, loader, loaderVersion, memoryPreset: 'heavy' });
        const game = paths.gameDir(instance.id);
        // 下载 files（跳过服务端专用文件 env.client === 'unsupported'）
        const rawFiles = index?.files;
        if (!Array.isArray(rawFiles))
            warnings.push('整合包索引里的 files 字段不是数组，可能已损坏；实例已创建但没有自动下载模组。');
        const files = Array.isArray(rawFiles) ? rawFiles : [];
        let skippedServer = 0;
        let invalidFiles = 0;
        const downloadable = files.filter(f => {
            if (f?.env?.client === 'unsupported') {
                skippedServer++;
                return false;
            }
            if (!Array.isArray(f?.downloads) || typeof f.downloads[0] !== 'string' || !f.downloads[0]) {
                invalidFiles++;
                return false;
            }
            if (typeof f?.path !== 'string' || !f.path.trim()) {
                invalidFiles++;
                return false;
            }
            return true;
        });
        if (skippedServer > 0)
            warnings.push(`已跳过 ${skippedServer} 个服务端专用文件（env.client = unsupported）。`);
        if (invalidFiles > 0)
            warnings.push(`已跳过 ${invalidFiles} 个没有下载地址的文件（整合包索引可能不完整）。`);
        log(`需要下载 ${downloadable.length} 个文件（已过滤 ${skippedServer} 个服务端文件）…`);
        const tasks = downloadable.map((f, i) => ({
            id: `packfile:${i}`,
            url: f.downloads[0],
            sha1: f.hashes?.sha1,
            size: f.size,
            dest: safeTarget(game, f.path) ?? path.join(game, 'pack-files', sanitizeRemoteName(f.path.split('/').pop() ?? `file-${i}`)),
            name: sanitizeRemoteName(f.path.split('/').pop() ?? `file-${i}`),
        }));
        const downloadSettings = (0, settings_1.getSettings)().download;
        const dl = new downloader_1.DownloadManager({
            source: downloadSettings.source,
            customMirror: downloadSettings.customMirror,
            maxThreads: downloadSettings.maxThreads,
            retries: 3,
            timeoutMs: downloadSettings.timeoutMs,
        });
        const reports = await dl.run(tasks);
        const ok = reports.filter(r => r.ok).length;
        for (const r of reports)
            if (!r.ok) {
                skippedFiles.push(r.name);
                warnings.push(`下载失败：${r.name}（${r.error}）`);
            }
        const overridden = await copyOverrides('overrides', game);
        const clientOverridden = await copyOverrides('client-overrides', game); // 客户端覆盖层：同名文件覆盖 overrides
        log(`完成：${ok}/${downloadable.length} 个文件下载成功，overrides ${overridden} 个、client-overrides ${clientOverridden} 个文件，实例已创建。`);
        return { instanceId: instance.id, format, importedMods: ok, skippedFiles, warnings };
    }
    if (format === 'curseforge') {
        let manifest;
        try {
            manifest = JSON.parse((await readEntry('manifest.json')).toString('utf8'));
        }
        catch {
            throw new Error('整合包清单 manifest.json 不是有效 JSON，文件可能已损坏。');
        }
        const mcVersion = String(manifest?.minecraft?.version ?? '1.20.1');
        const rawLoaders = manifest?.minecraft?.modLoaders;
        const modLoaderEntry = (Array.isArray(rawLoaders) ? rawLoaders : []).find((l) => l?.primary)
            ?? (Array.isArray(rawLoaders) ? rawLoaders[0] : undefined);
        let loader = 'vanilla';
        let loaderVersion = null;
        const idStr = modLoaderEntry?.id ?? '';
        const m = idStr.match(/^(forge|fabric|quilt|neoforge)-(.+)$/);
        if (m) {
            loader = m[1];
            loaderVersion = m[2];
        }
        const instance = (0, instances_1.createInstance)({ name: targetName ?? manifest?.name ?? 'CurseForge 整合包', mcVersion, loader, loaderVersion, memoryPreset: 'heavy' });
        const game = paths.gameDir(instance.id);
        await copyOverrides('overrides', game);
        const rawCfFiles = Array.isArray(manifest?.files) ? manifest.files : [];
        // 清单里的 projectID/fileID 必须是正整数：否则会拼出 /mods/undefined/files/undefined 的无效请求
        const files = rawCfFiles.filter((f) => Number.isInteger(f?.projectID) && f.projectID > 0 && Number.isInteger(f?.fileID) && f.fileID > 0);
        if (files.length !== rawCfFiles.length) {
            warnings.push(`已跳过 ${rawCfFiles.length - files.length} 个缺少有效 projectID/fileID 的条目。`);
        }
        const apiKey = (0, settings_1.getSettings)().curseforge.apiKey.trim();
        if (apiKey) {
            log(`使用 CurseForge API 下载 ${files.length} 个模组…`);
            const manual = [];
            let ok = 0;
            for (const f of files) {
                try {
                    const info = await (0, net_1.fetchJson)(`https://api.curseforge.com/v1/mods/${f.projectID}/files/${f.fileID}`, { timeoutMs: 20000, headers: { 'x-api-key': apiKey, 'User-Agent': net_1.USER_AGENT } });
                    const file = info?.data;
                    const url = file?.downloadUrl;
                    if (!file || !url) {
                        manual.push({ name: `CF project ${f.projectID}`, url: `https://www.curseforge.com/projects/${f.projectID}/files/${f.fileID}` });
                        continue;
                    }
                    const safeName = sanitizeRemoteName(file.fileName || `cf-${f.projectID}-${f.fileID}.jar`);
                    // API 返回的 SHA-1 / 文件大小是唯一能证明下载完整性的依据：
                    // 被墙或被劫持时服务器可能返回 200 的 HTML 错误页，不能把这种文件当模组装进 mods
                    const sha1 = (Array.isArray(file.hashes) ? file.hashes : [])
                        .find(h => h?.algo === 1 && /^[a-f0-9]{40}$/i.test(String(h?.value ?? '')))?.value;
                    const size = typeof file.fileLength === 'number' && Number.isInteger(file.fileLength) && file.fileLength > 0
                        ? file.fileLength
                        : undefined;
                    const dl = new downloader_1.DownloadManager({ source: 'official', maxThreads: 2, retries: 2 });
                    const reports = await dl.run([{ id: `cf:${f.fileID}`, url, dest: path.join(game, 'mods', safeName), name: safeName, sha1, size }]);
                    if (reports[0]?.ok)
                        ok++;
                    else
                        manual.push({ name: file.fileName || safeName, url });
                }
                catch {
                    manual.push({ name: `CF project ${f.projectID}`, url: `https://www.curseforge.com/projects/${f.projectID}/files/${f.fileID}` });
                }
            }
            for (const m of manual)
                skippedFiles.push(m.name);
            warnings.push(...manual.map(x => `需手动下载：${x.name} → ${x.url}`));
            return { instanceId: instance.id, format, importedMods: ok, skippedFiles, warnings, manualDownloads: manual.length ? manual : undefined };
        }
        // 无密钥：给出逐项链接（痛点 #36：绝不静默失败）
        warnings.push('未配置 CurseForge API 密钥：已创建实例并复制 overrides，但模组需要手动下载。可在设置 → CurseForge API 中填写密钥后重新导入，或点下面的链接逐个下载放入 mods 目录。');
        const manualDownloads = files.map(f => ({ name: `project ${f.projectID} / file ${f.fileID}`, url: `https://www.curseforge.com/projects/${f.projectID}/files/${f.fileID}/download` }));
        return { instanceId: instance.id, format, importedMods: 0, skippedFiles: files.map(f => `${f.projectID}/${f.fileID}`), warnings, manualDownloads };
    }
    if (format === 'mcl') {
        // MCL 自己的完整实例快照：instance.json + game/...
        // 必须放在通用 createInstance 之前，否则会多建一个只有 instance.json 的空孤儿实例
        let rawCfg = {};
        try {
            rawCfg = JSON.parse((await readEntry('instance.json')).toString('utf8'));
        }
        catch {
            throw new Error('实例快照里的 instance.json 不是有效 JSON，文件可能已损坏。');
        }
        const instance = (0, instances_1.createInstance)({
            name: targetName ?? (typeof rawCfg.name === 'string' ? rawCfg.name : 'MCL 实例快照'),
            mcVersion: typeof rawCfg.mcVersion === 'string' ? rawCfg.mcVersion : '1.20.1',
            loader: ['vanilla', 'fabric', 'quilt', 'forge', 'neoforge'].includes(rawCfg.loader) ? rawCfg.loader : 'vanilla',
            loaderVersion: typeof rawCfg.loaderVersion === 'string' ? rawCfg.loaderVersion : null,
            memoryPreset: ['low', 'standard', 'heavy'].includes(rawCfg.memoryPreset) ? rawCfg.memoryPreset : 'standard',
        });
        const game = paths.gameDir(instance.id);
        const gamePrefix = `${prefix}game/`;
        let copied = 0;
        for (const entry of entries) {
            const norm = entry.name.replace(/\\/g, '/');
            if (!norm.startsWith(gamePrefix) || norm.endsWith('/'))
                continue;
            const rel = stripPrefix(norm, gamePrefix);
            if (!rel)
                continue;
            const target = safeTarget(game, rel);
            if (!target) {
                warnings.push(`已跳过可疑路径：${norm}`);
                continue;
            }
            try {
                fs.mkdirSync(path.dirname(target), { recursive: true });
                await (0, zip_1.zipExtractEntryToFile)(zipPath, entry, target);
                copied++;
            }
            catch (e) {
                warnings.push(`文件写入失败：${norm}（${e instanceof Error ? e.message : String(e)}）`);
            }
        }
        return { instanceId: instance.id, format, importedMods: copied, skippedFiles, warnings };
    }
    // MultiMC/紧凑格式：整个包就是实例内容（除 mmc-pack.json 本身）
    const instance = (0, instances_1.createInstance)({ name: targetName ?? path.basename(zipPath, '.zip'), mcVersion: '1.20.1', loader: 'vanilla', memoryPreset: 'standard' });
    const game = paths.gameDir(instance.id);
    let mmcJson = null;
    try {
        mmcJson = JSON.parse((await readEntry('mmc-pack.json')).toString('utf8'));
    }
    catch {
        warnings.push('mmc-pack.json 解析失败，按 vanilla 1.20.1 创建');
    }
    if (Array.isArray(mmcJson?.components)) {
        const mc = mmcJson.components.find((c) => c?.uid === 'net.minecraft');
        const loaderComp = mmcJson.components.find((c) => ['net.fabricmc.fabric-loader', 'net.minecraftforge', 'org.quiltmc.quilt-loader', 'net.neoforged'].includes(c?.uid));
        if (mc?.version) {
            updateInstanceMcVersion(instance.id, mc.version);
        }
        if (loaderComp) {
            const loaderType = loaderComp.uid === 'net.fabricmc.fabric-loader' ? 'fabric' : loaderComp.uid === 'org.quiltmc.quilt-loader' ? 'quilt' : loaderComp.uid === 'net.neoforged' ? 'neoforge' : 'forge';
            (0, instances_1.updateInstance)(instance.id, { loader: loaderType, loaderVersion: loaderComp.version ?? null });
            warnings.push('MultiMC 整合包已转换为 MCL 实例，加载器将在首次启动时安装。');
        }
    }
    // MultiMC/Prism 各版本导出包可能用 minecraft/ 或 .minecraft/；
    // MCL 自己导出的包用的是 .minecraft/，两种都要认，否则回导会落到 game/.minecraft/ 下读不到
    const normalizedNames = entries.map(e => e.name.replace(/\\/g, '/'));
    const gameSub = normalizedNames.some(n => n.startsWith(`${prefix}minecraft/`)) ? 'minecraft/'
        : normalizedNames.some(n => n.startsWith(`${prefix}.minecraft/`)) ? '.minecraft/' : '';
    const gamePrefix = prefix + gameSub;
    const SKIP_META = new Set(['instance.cfg', 'mmc-pack.json', 'icon.png', 'instance.png', 'logo.png']);
    let copied = 0, modsCopied = 0, savesCopied = 0;
    for (const entry of entries) {
        const norm = entry.name.replace(/\\/g, '/');
        if (!norm.startsWith(gamePrefix) || norm.endsWith('/'))
            continue;
        const rel = stripPrefix(norm, gamePrefix);
        if (!rel)
            continue;
        if (SKIP_META.has(rel.split('/')[0]))
            continue; // 跳过实例元数据（instance.cfg 等）
        const target = safeTarget(game, rel);
        if (!target) {
            warnings.push(`已跳过可疑路径：${norm}`);
            continue;
        }
        try {
            fs.mkdirSync(path.dirname(target), { recursive: true });
            await (0, zip_1.zipExtractEntryToFile)(zipPath, entry, target);
            copied++;
            if (rel.startsWith('mods/'))
                modsCopied++;
            else if (rel.startsWith('saves/'))
                savesCopied++;
        }
        catch (e) {
            warnings.push(`文件写入失败：${norm}（${e instanceof Error ? e.message : String(e)}）`);
        }
    }
    log(`已复制 mods ${modsCopied} 个、saves ${savesCopied} 个、共 ${copied} 个文件${gameSub ? `（${gameSub}前缀已剥离）` : ''}`);
    warnings.push(`MultiMC 格式：${gameSub ? `已识别 ${gameSub} 游戏目录，` : ''}整包展开为实例目录（${copied} 个文件：mods ${modsCopied}、saves ${savesCopied}）。`);
    return { instanceId: instance.id, format, importedMods: copied, skippedFiles, warnings };
}
function updateInstanceMcVersion(id, mcVersion) {
    (0, instances_1.updateInstance)(id, { mcVersion });
}
