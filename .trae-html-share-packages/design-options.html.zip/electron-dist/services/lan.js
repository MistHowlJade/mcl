"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.scanLanWorlds = scanLanWorlds;
/**
 * 局域网世界扫描：监听 Minecraft 的局域网广播（224.0.2.60:4445）
 * 对应「对局域网开放」后自动发现，不需要玩家手动问 IP。
 */
const dgram = __importStar(require("dgram"));
const os = __importStar(require("os"));
const MULTICAST = '224.0.2.60';
const PORT = 4445;
function localAddresses() {
    const set = new Set(['127.0.0.1', 'localhost']);
    for (const list of Object.values(os.networkInterfaces())) {
        for (const item of list ?? []) {
            if (!item.internal)
                set.add(item.address);
        }
    }
    return set;
}
function scanLanWorlds(timeoutMs = 4500) {
    return new Promise(resolve => {
        const socket = dgram.createSocket({ type: 'udp4', reuseAddr: true });
        const found = new Map();
        const locals = localAddresses();
        let finished = false;
        let timer = null;
        const finish = () => {
            if (finished)
                return;
            finished = true;
            if (timer)
                clearTimeout(timer);
            try {
                socket.close();
            }
            catch { /* ignore */ }
            resolve([...found.values()].sort((a, b) => a.motd.localeCompare(b.motd)));
        };
        // NaN/Infinity 会让 setTimeout 立刻触发或永不触发；统一夹到 1.5–15 秒
        const wait = Number.isFinite(timeoutMs) ? Math.max(1500, Math.min(15000, Math.floor(timeoutMs))) : 4500;
        timer = setTimeout(finish, wait);
        socket.once('error', finish);
        socket.on('message', (msg, rinfo) => {
            const text = msg.toString('utf8');
            const motdRaw = /\[MOTD\]([\s\S]*?)\[\/MOTD\]/i.exec(text)?.[1] ?? 'Minecraft 局域网世界';
            const motd = motdRaw.replace(/\u00a7[\da-fk-or]/gi, '').replace(/\s+/g, ' ').trim() || 'Minecraft 局域网世界';
            const port = parseInt(/\[AD\]([\s\S]*?)\[\/AD\]/i.exec(text)?.[1] ?? '', 10);
            // 端口来自局域网广播，可能是恶意/损坏数据：超出范围时按默认端口显示
            const safePort = Number.isInteger(port) && port >= 1 && port <= 65535 ? port : 25565;
            const key = `${rinfo.address}:${safePort}`;
            found.set(key, {
                motd,
                address: rinfo.address,
                port: safePort,
                local: locals.has(rinfo.address),
            });
        });
        try {
            socket.bind(PORT, () => {
                try {
                    socket.addMembership(MULTICAST);
                }
                catch { /* 没有可用网卡时保持监听，仍可能收到单播 */ }
            });
        }
        catch {
            finish();
        }
    });
}
