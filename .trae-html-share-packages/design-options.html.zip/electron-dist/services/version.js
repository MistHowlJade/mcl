"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.getVersionManifest = getVersionManifest;
exports.getAutoSource = getAutoSource;
exports.resolveSourceUrl = resolveSourceUrl;
exports.evalRule = evalRule;
exports.evalRules = evalRules;
exports.newestVersion = newestVersion;
exports.mergeProfile = mergeProfile;
exports.fetchVersionJson = fetchVersionJson;
exports.resolveVersion = resolveVersion;
exports.collectLibraries = collectLibraries;
exports.expandVirtualAssets = expandVirtualAssets;
exports.fetchAssetIndex = fetchAssetIndex;
exports.assetDestPath = assetDestPath;
exports.buildDownloadPlan = buildDownloadPlan;
/**
 * 版本清单与版本 JSON 解析（inheritsFrom 合并、规则评估、库/资源规划）
 */
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const crypto = __importStar(require("crypto"));
const net_1 = require("./net");
const paths_1 = require("./paths");
const store_1 = require("./store");
// 与 net.ts 的测速缓存统一放在 dataRoot/cache，不要再用 versionsDir/../cache 拼出不存在的目录
const manifestCacheFile = () => path.join((0, paths_1.cacheDir)(), 'version_manifest.json');
async function getVersionManifest(source, customMirror) {
    const cache = (0, store_1.readJson)(manifestCacheFile(), null);
    if (cache && Date.now() - cache.at < 30 * 60 * 1000
        && cache.manifest && Array.isArray(cache.manifest.versions)) {
        return cache.manifest;
    }
    const url = resolveSourceUrl(net_1.OFFICIAL.versionManifest, source, customMirror);
    // 镜像偶尔 20 秒超时：再补一次官方源，避免创建实例弹窗直接停在「0 个版本」
    const candidates = url === net_1.OFFICIAL.versionManifest ? [url] : [url, net_1.OFFICIAL.versionManifest];
    let lastError = null;
    for (const candidate of candidates) {
        try {
            const manifest = await (0, net_1.fetchJson)(candidate, { timeoutMs: 20000 });
            if (!manifest || !Array.isArray(manifest.versions)) {
                throw new Error('版本清单格式不正确（缺少 versions 列表）');
            }
            try {
                (0, store_1.writeJson)(manifestCacheFile(), { at: Date.now(), manifest });
            }
            catch { /* 缓存失败不阻塞 */ }
            return manifest;
        }
        catch (e) {
            lastError = e;
        }
    }
    // 全部源都失败时退回旧缓存：比「一个版本都没有」更能让用户完成创建
    if (cache?.manifest && Array.isArray(cache.manifest.versions)) {
        console.warn('[mcl] 版本清单刷新失败，使用旧缓存：', (0, net_1.errorReason)(lastError));
        return cache.manifest;
    }
    // 前缀由渲染层统一添加，这里只描述连接失败原因，避免「版本清单加载失败」重复两次
    throw new Error(`无法连接下载源：${(0, net_1.errorReason)(lastError)}。请检查网络或在设置中切换下载源后重试。`);
}
/** auto 模式实际生效源：读最近测速缓存（无测速或过期则默认 BMCLAPI，mirror:test 可刷新） */
function getAutoSource() {
    // 走 net.ts 的统一健康缓存，避免路径各写一份导致读不到测速结果
    try {
        const health = (0, net_1.lastHealthCheck)();
        if (health && Date.now() - health.at < 10 * 60 * 1000) {
            const okList = health.latencies.filter(l => l.ok);
            if (okList.length === 2)
                return okList[0].latencyMs <= okList[1].latencyMs ? okList[0].source : okList[1].source;
            if (okList.length === 1)
                return okList[0].source;
        }
    }
    catch { /* 缓存异常不阻塞 */ }
    return 'bmclapi';
}
function resolveSourceUrl(officialUrl, source, customMirror) {
    if (source === 'official')
        return officialUrl;
    if (source === 'auto')
        return (0, net_1.mapToMirror)(officialUrl, getAutoSource());
    if (source === 'bmclapi')
        return (0, net_1.mapToMirror)(officialUrl, 'bmclapi');
    if (source === 'custom' && customMirror)
        return (0, net_1.mapToMirror)(officialUrl, 'custom', customMirror);
    return officialUrl;
}
/* ---------- 规则评估 ---------- */
/**
 * evalRule 语义 = "规则条件是否适用"（不是"是否允许启动"）：
 *   - 条件匹配 → true（规则生效，由 evalRules 按 action 决定允许性）
 *   - 条件不匹配 → false（规则不适用）
 * 每条规则独立求值，互不依赖 action。
 */
function evalRule(rule, features = {}) {
    if (rule.os) {
        const osName = process.platform === 'win32' ? 'windows' : process.platform === 'darwin' ? 'osx' : 'linux';
        if (rule.os.name && rule.os.name !== osName)
            return false;
        if (rule.os.arch) {
            const arch = process.arch;
            const want = typeof rule.os.arch === 'string' ? rule.os.arch.toLowerCase() : '';
            if (want === 'x86') {
                if (arch !== 'ia32' && arch !== 'arm')
                    return false;
            }
            else if (want === 'x64' || want === 'x86_64' || want === 'amd64') {
                if (arch !== 'x64')
                    return false;
            }
            else if (want === 'arm64' || want === 'aarch64') {
                if (arch !== 'arm64')
                    return false;
            }
            // 未覆盖的 arch 不作判断（交给上层按不匹配处理见 MOJANG 规范需谨慎，但不拦截）
        }
        if (rule.os.version) {
            try {
                const sysVer = process.getSystemVersion ? process.getSystemVersion() : '';
                if (sysVer && !new RegExp(rule.os.version).test(sysVer))
                    return false;
            }
            catch { /* 正则非法时不拦截 */ }
        }
    }
    if (rule.features) {
        for (const key of Object.keys(rule.features)) {
            if (!!features[key] !== !!rule.features[key])
                return false;
        }
    }
    return true;
}
function evalRules(rules, features = {}) {
    if (!Array.isArray(rules) || rules.length === 0)
        return true;
    let allowed = false;
    for (const rule of rules) {
        if (!rule || typeof rule !== 'object')
            continue;
        const applies = evalRule(rule, features);
        if (applies)
            allowed = rule.action === 'allow';
    }
    return allowed;
}
const PRERELEASE = /-(?:alpha|beta|pre|preview|rc|snapshot)\d*(?:[.\-+]|$)/i;
/**
 * Maven 元数据里的 <version> 不保证按版本号排序：数字感知比较取最新，避免 47.10 被 47.9 盖住。
 * NeoForge/Quilt 的元数据同时列有 -beta：界面承诺“最新稳定版”，有正式版时不能自动选测试版。
 */
function newestVersion(versions) {
    const stable = versions.filter(v => !PRERELEASE.test(String(v)));
    const pool = stable.length > 0 ? stable : versions;
    return pool.reduce((best, v) => (best === undefined || String(v).localeCompare(best, 'en', { numeric: true }) > 0 ? v : best), undefined);
}
/** 合并加载器 profile json（fabric/quilt/forge）到已解析的基础版本上 */
function mergeProfile(base, profile) {
    const merged = mergeVersionJson(profile, base);
    // profile 的 inheritsFrom 不应覆盖基础解析
    delete merged.inheritsFrom;
    return merged;
}
/* ---------- inheritsFrom 合并 ---------- */
/**
 * 库去重键：group:artifact[:classifier][@ext]。
 * inheritsFrom 的常见场景是子版本用同坐标、不同版本覆盖父版本库（Forge 补丁库），
 * 直接拼接会让旧版库先进入 classpath；这里保留子版本。classifier 不同的 native 库不受影响。
 */
function libraryKey(lib) {
    const raw = String(lib?.name ?? '');
    if (!raw)
        return `raw:${JSON.stringify(lib)}`;
    const at = raw.indexOf('@');
    const ext = at >= 0 ? raw.slice(at + 1) : 'jar';
    const parts = (at >= 0 ? raw.slice(0, at) : raw).split(':');
    if (parts.length >= 2)
        return `${parts[0]}:${parts[1]}:${parts[3] ?? ''}:${ext}`;
    return raw;
}
function mergeVersionJson(child, parent) {
    const merged = { ...parent, ...child };
    // libraries 按坐标去重：父在前，子覆盖同坐标的版本（Map.set 保留父条目顺序）
    const libs = new Map();
    const parentLibs = Array.isArray(parent.libraries) ? parent.libraries : [];
    const childLibs = Array.isArray(child.libraries) ? child.libraries : [];
    for (const lib of [...parentLibs, ...childLibs]) {
        if (lib && typeof lib === 'object')
            libs.set(libraryKey(lib), lib);
    }
    merged.libraries = [...libs.values()];
    // arguments 合并
    if (parent.arguments || child.arguments) {
        const parentArgs = parent.arguments && typeof parent.arguments === 'object' ? parent.arguments : {};
        const childArgs = child.arguments && typeof child.arguments === 'object' ? child.arguments : {};
        merged.arguments = {
            game: [
                ...(Array.isArray(parentArgs.game) ? parentArgs.game : []),
                ...(Array.isArray(childArgs.game) ? childArgs.game : []),
            ],
            jvm: [
                ...(Array.isArray(parentArgs.jvm) ? parentArgs.jvm : []),
                ...(Array.isArray(childArgs.jvm) ? childArgs.jvm : []),
            ],
        };
    }
    merged.inheritsFrom = child.inheritsFrom;
    return merged;
}
/** 读取本地缓存的原始 version json（若存在） */
function localVersionJsonPath(id) {
    return path.join((0, paths_1.versionsDir)(), id, `${id}.json`);
}
async function fetchVersionJson(entry, source, customMirror) {
    if (!isSafePathSegment(entry.id))
        throw new Error(`版本 id 非法：${String(entry.id)}`);
    const local = localVersionJsonPath(entry.id);
    if (fs.existsSync(local)) {
        const cached = (0, store_1.readJson)(local, null);
        if (cached)
            return cached;
    }
    const url = resolveSourceUrl(entry.url, source, customMirror);
    const json = await (0, net_1.fetchJson)(url, { timeoutMs: 45000 });
    fs.mkdirSync(path.dirname(local), { recursive: true });
    (0, store_1.writeJson)(local, json);
    return json;
}
/** 完整解析（含递归 inheritsFrom） */
async function resolveVersion(entry, source, customMirror, depth = 0) {
    if (depth > 5)
        throw new Error('inheritsFrom 嵌套过深');
    const raw = await fetchVersionJson(entry, source, customMirror);
    if (!raw || typeof raw !== 'object' || Array.isArray(raw))
        throw new Error(`版本 JSON 格式不正确：${entry.id}`);
    if (raw.inheritsFrom) {
        if (typeof raw.inheritsFrom !== 'string')
            throw new Error(`版本 JSON 的 inheritsFrom 字段非法：${entry.id}`);
        const parentEntry = await findManifestEntry(raw.inheritsFrom, source, customMirror);
        const parent = await resolveVersion(parentEntry, source, customMirror, depth + 1);
        return mergeVersionJson(raw, parent);
    }
    return raw;
}
async function findManifestEntry(id, source, customMirror) {
    const manifest = await getVersionManifest(source, customMirror);
    const hit = manifest.versions.find(v => v.id === id);
    if (!hit)
        throw new Error(`清单中找不到版本：${id}`);
    if (!isSafePathSegment(hit.id))
        throw new Error(`版本清单包含非法版本 id：${String(hit.id)}`);
    return hit;
}
/* ---------- 库与 natives ---------- */
/** 版本 id / 索引 id 会直接拼进数据目录，不能是 . / .. 或带路径分隔符 */
function isSafePathSegment(id) {
    return typeof id === 'string'
        && id.length > 0 && id.length <= 128
        && /^[0-9A-Za-z_\-[\]]+(\.[0-9A-Za-z_\-[\]]+)*$/.test(id);
}
/** 版本元数据/资源索引是远程内容：entry.path 可能是 ../../ 或绝对路径 */
function isSafeRelativePath(rel) {
    if (typeof rel !== 'string' || !rel || rel.length > 1024)
        return false;
    const norm = rel.replace(/\\/g, '/');
    if (norm.startsWith('/') || /^[A-Za-z]:/.test(norm))
        return false;
    return norm.split('/').every(seg => !!seg && seg !== '.' && seg !== '..');
}
const assertSafeRelPath = (rel, what) => {
    if (!isSafeRelativePath(rel))
        throw new Error(`${what}包含非法文件路径：${rel}`);
    return rel.replace(/\\/g, '/');
};
const mavenToPath = (name) => {
    // Maven 坐标可能带 @扩展名（如 group:artifact:version@zip），@ 必须在拆坐标前剥离
    const at = name.indexOf('@');
    const extRaw = at >= 0 ? name.slice(at + 1) : 'jar';
    if (!/^[A-Za-z0-9.]+$/.test(extRaw))
        throw new Error(`非法 maven 扩展名：${name}`);
    const ext = extRaw;
    const parts = (at >= 0 ? name.slice(0, at) : name).split(':');
    if (parts.length < 3)
        throw new Error(`非法 maven 坐标：${name}`);
    const [group, artifact, version, ...rest] = parts;
    const classifier = rest.length > 0 && rest[0] && !rest[0].startsWith('@') ? rest[0] : null;
    const groupPath = group.replace(/\./g, '/');
    const file = classifier ? `${artifact}-${version}-${classifier}.${ext}` : `${artifact}-${version}.${ext}`;
    return assertSafeRelPath(path.join(groupPath, artifact, version, file).replace(/\\/g, '/'), 'maven 坐标');
};
function osNativeKey() {
    const os = process.platform === 'win32' ? 'windows' : process.platform === 'darwin' ? 'osx' : 'linux';
    const arch = process.arch === 'x64' ? '64' : process.arch === 'arm64' ? 'arm64' : '32';
    return `natives-${os}${arch === '64' ? '' : '-' + arch}`;
}
function collectLibraries(resolved) {
    const out = [];
    const libraries = Array.isArray(resolved.libraries) ? resolved.libraries : [];
    for (const lib of libraries) {
        if (!lib || typeof lib !== 'object')
            continue;
        if (lib.rules && !evalRules(lib.rules))
            continue;
        const name = typeof lib.name === 'string' ? lib.name : '';
        if (!name)
            throw new Error('版本元数据里有一个库缺少 maven 坐标（name），文件可能已损坏，请删除该版本缓存后重试');
        // artifact 主体
        const artifact = lib.downloads?.artifact;
        if (artifact) {
            const rel = assertSafeRelPath(artifact.path ?? mavenToPath(name), '库文件');
            out.push({
                name,
                url: artifact.url ?? `${net_1.OFFICIAL.libraries}/${rel}`,
                path: rel,
                sha1: artifact.sha1,
                size: artifact.size,
                isNative: false,
            });
        }
        else if (lib.url) {
            // 旧版 json：url 为 repo base
            const rel = mavenToPath(name);
            out.push({ name, url: `${String(lib.url).replace(/\/+$/, '')}/${rel}`, path: rel, isNative: false });
        }
        else if (!(lib.natives && typeof lib.natives === 'object' && Object.keys(lib.natives).length > 0)) {
            // 1.6–1.12 的 lwjgl-platform/jinput-platform/twitch-platform 等只有 natives classifier，
            // 官方仓库根本没有它们的主 jar；合成 Maven 坐标必然 404 并中断整个版本下载。
            const rel = mavenToPath(name);
            out.push({ name, url: `${net_1.OFFICIAL.libraries}/${rel}`, path: rel, isNative: false });
        }
        // natives
        const classifiers = lib.downloads?.classifiers ?? {};
        const osKey = process.platform === 'win32' ? 'windows' : process.platform === 'darwin' ? 'osx' : 'linux';
        const arch = process.arch === 'ia32' ? '32' : process.arch === 'arm64' ? 'arm64' : '64';
        // 1.7.10/1.8.9 的 twitch 库用 natives-windows-${arch} 这种占位符，
        // 不展开会拼出字面量 ${arch} 的 Maven 坐标，下载必然 404 并中断整个版本安装。
        const expandArch = (key) => key.replace(/\$\{arch\}/g, arch);
        const wanted = expandArch(osNativeKey());
        const nativeEntry = classifiers[wanted] ?? classifiers[`natives-${osKey}-${arch}`] ?? classifiers[`natives-${osKey}`];
        if (nativeEntry) {
            const rel = assertSafeRelPath(nativeEntry.path ?? mavenToPath(name), 'natives 文件');
            out.push({
                name,
                url: nativeEntry.url ?? `${net_1.OFFICIAL.libraries}/${rel}`,
                path: rel,
                sha1: nativeEntry.sha1,
                size: nativeEntry.size,
                isNative: true,
                nativeKey: wanted,
            });
        }
        else if (lib.natives) {
            // 旧版 json（如 1.7.10）：只有 natives 映射，没有 downloads.classifiers，
            // 需要按 maven classifier 自行拼出 natives jar，否则游戏会缺 lwjgl dll 直接崩。
            const rawClassifier = lib.natives[osKey];
            if (typeof rawClassifier === 'string' && rawClassifier) {
                const classifier = expandArch(rawClassifier);
                const rel = mavenToPath(`${name}:${classifier}`);
                const base = typeof lib.url === 'string' && lib.url
                    ? String(lib.url).replace(/\/+$/, '')
                    : net_1.OFFICIAL.libraries;
                out.push({ name, url: `${base}/${rel}`, path: rel, isNative: true, nativeKey: wanted });
            }
        }
    }
    return out;
}
/* ---------- 资源索引 ---------- */
/** 1.6.x 的 legacy 资源需要 objects/<hash> 额外展开成 assets/virtual/legacy/<资源名> */
/** 资源对象下载完成后再展开 legacy 虚拟目录：索引先到、对象后下，首次安装必须调用本函数 */
function expandVirtualAssets(indexId) {
    if (!isSafePathSegment(indexId))
        return;
    const file = path.join((0, paths_1.assetsIndexDir)(), `${indexId}.json`);
    if (!fs.existsSync(file))
        return;
    const cached = (0, store_1.readJson)(file, {});
    try {
        ensureVirtualLegacy(mapAssets(cached));
    }
    catch { /* 索引损坏时交给下次启动重下 */ }
}
function ensureVirtualLegacy(objects) {
    const root = path.resolve(path.join((0, paths_1.assetsDir)(), 'virtual', 'legacy'));
    for (const obj of objects) {
        const rel = obj.name.replace(/\\/g, '/');
        // 远程索引里的资源名不能逃出 virtual/legacy
        if (!rel || rel.startsWith('/') || /(^|\/)\.\.(\/|$)/.test(rel))
            continue;
        const dest = path.resolve(root, rel);
        if (!dest.startsWith(root + path.sep))
            continue;
        const src = assetDestPath(obj.hash);
        if (!fs.existsSync(src))
            continue;
        try {
            fs.mkdirSync(path.dirname(dest), { recursive: true });
            if (!fs.existsSync(dest))
                fs.copyFileSync(src, dest);
        }
        catch { /* 单个资源失败不影响其它资源 */ }
    }
}
async function fetchAssetIndex(resolved, source, customMirror) {
    const ai = resolved.assetIndex ?? resolved.assets;
    if (typeof ai === 'string' || !ai || typeof ai !== 'object' || typeof ai.url !== 'string') {
        // 旧版：assetIndex 字段是名字，需要自行从 launchermeta 拿？兜底：按名字走缓存或报错
        const indexId = typeof ai === 'string' ? ai : ai?.id;
        if (!isSafePathSegment(indexId))
            throw new Error(`资源索引 id 非法：${String(indexId)}`);
        const localIndex = path.join((0, paths_1.assetsIndexDir)(), `${indexId}.json`);
        if (fs.existsSync(localIndex)) {
            const cached = (0, store_1.readJson)(localIndex, { objects: {} });
            const objects = mapAssets(cached);
            if (indexId === 'legacy')
                ensureVirtualLegacy(objects);
            return { indexId, objects };
        }
        throw new Error(`该版本使用旧式资源索引（${indexId}），首次导入请连接网络`);
    }
    if (!isSafePathSegment(ai.id))
        throw new Error(`资源索引 id 非法：${String(ai.id)}`);
    const url = resolveSourceUrl(ai.url, source, customMirror);
    const fallbackUrl = ai.url; // 官方源兜底
    let indexJson = null;
    let lastError = null;
    for (const candidate of [url, fallbackUrl]) {
        try {
            const res = await (0, net_1.fetchWithTimeout)(candidate, { timeoutMs: 30000, headers: { Accept: 'application/json' } });
            if (res.status >= 400)
                throw new Error(`HTTP ${res.status}`);
            let parsed;
            try {
                parsed = JSON.parse(res.body.toString('utf8'));
            }
            catch {
                throw new Error('资源索引不是合法 JSON');
            }
            // 资源索引是所有资源 hash 的来源：本身声明了 SHA-1 就必须校验。
            // 镜像若返回陈旧或被篡改的索引，后续每个资源的路径都会基于错误 hash。
            if (typeof ai.sha1 === 'string' && /^[a-f0-9]{40}$/i.test(ai.sha1)) {
                const actual = crypto.createHash('sha1').update(res.body).digest('hex');
                if (actual !== ai.sha1.toLowerCase())
                    throw new Error('资源索引 SHA-1 校验失败');
            }
            indexJson = parsed;
            break;
        }
        catch (e) {
            lastError = e;
        }
    }
    if (!indexJson) {
        throw new Error(`资源索引下载失败（镜像与官方源均失败）：${(0, net_1.errorReason)(lastError)}`);
    }
    try {
        fs.mkdirSync((0, paths_1.assetsIndexDir)(), { recursive: true });
        (0, store_1.writeJson)(path.join((0, paths_1.assetsIndexDir)(), `${ai.id}.json`), indexJson);
    }
    catch { /* ignore */ }
    const objects = mapAssets(indexJson);
    if (ai.virtual === true || ai.id === 'legacy')
        ensureVirtualLegacy(objects);
    return { indexId: ai.id, objects };
}
function mapAssets(indexJson) {
    return Object.entries(indexJson.objects ?? {}).map(([name, obj]) => {
        // 资源索引来自远程：hash 会拼进 cache 路径，必须是 40 位 SHA-1
        if (!obj || typeof obj.hash !== 'string' || !/^[a-f0-9]{40}$/i.test(obj.hash)) {
            throw new Error(`资源索引包含非法 hash（${name}），已停止下载以免写错目录`);
        }
        return { hash: obj.hash.toLowerCase(), size: Number.isFinite(obj.size) ? obj.size : 0, name };
    });
}
function assetDestPath(hash) {
    if (!/^[a-f0-9]{40}$/i.test(hash))
        throw new Error('资源 hash 格式不正确');
    const sub = hash.slice(0, 2);
    return path.join((0, paths_1.assetsObjectsDir)(), sub, hash);
}
async function buildDownloadPlan(entry, source, customMirror, includeAssets = true) {
    const resolved = await resolveVersion(entry, source, customMirror);
    const tasks = [];
    // 同一目标文件只允许一个任务：旧版资源索引里多个虚拟资源会共用同一个 objects/<hash> 文件，
    // 库也可能在 inheritsFrom 合并后重复出现。重复任务会并发写同一个 .part，把文件写坏。
    const seenDest = new Set();
    const pushTask = (task) => {
        const key = process.platform === 'win32' ? task.dest.toLowerCase() : task.dest;
        if (seenDest.has(key))
            return;
        seenDest.add(key);
        tasks.push(task);
    };
    // 客户端 jar（旧版 jar 也走 downloads.client）
    const client = resolved.downloads?.client;
    if (client) {
        pushTask({
            id: `client:${entry.id}`,
            url: client.url,
            sha1: client.sha1,
            size: client.size,
            dest: path.join((0, paths_1.versionsDir)(), entry.id, `${entry.id}.jar`),
            name: `${entry.id} 客户端`,
        });
    }
    // 库
    for (const lib of collectLibraries(resolved)) {
        pushTask({
            id: `lib:${lib.path}`,
            url: lib.url,
            sha1: lib.sha1,
            size: lib.size,
            dest: path.join((0, paths_1.librariesDir)(), ...lib.path.split('/')),
            name: lib.isNative ? `natives ${path.basename(lib.path)}` : path.basename(lib.path),
        });
    }
    // 资源
    let assetIndexId = resolved.assets ?? 'legacy';
    if (includeAssets) {
        const { indexId, objects } = await fetchAssetIndex(resolved, source, customMirror);
        assetIndexId = indexId;
        for (const obj of objects) {
            const hash = obj.hash;
            pushTask({
                id: `asset:${hash}`,
                url: `https://resources.download.minecraft.net/${hash.slice(0, 2)}/${hash}`,
                sha1: hash,
                size: obj.size,
                dest: assetDestPath(hash),
                name: `资源 ${path.basename(obj.name)}`,
            });
        }
    }
    return { tasks, resolved, assetIndexId };
}
