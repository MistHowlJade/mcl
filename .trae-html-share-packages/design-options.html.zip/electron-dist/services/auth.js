"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.cancelMicrosoftLogin = cancelMicrosoftLogin;
exports.listAccounts = listAccounts;
exports.getActiveAccount = getActiveAccount;
exports.setActiveAccount = setActiveAccount;
exports.removeAccount = removeAccount;
exports.offlineUuid = offlineUuid;
exports.createOfflineAccount = createOfflineAccount;
exports.beginMicrosoftLogin = beginMicrosoftLogin;
exports.translateXstsError = translateXstsError;
exports.finishMicrosoftLogin = finishMicrosoftLogin;
exports.getValidAccessToken = getValidAccessToken;
exports.setLocalSkin = setLocalSkin;
exports.clearLocalSkin = clearLocalSkin;
exports.setLocalCape = setLocalCape;
exports.clearLocalCape = clearLocalCape;
exports.uploadMicrosoftSkin = uploadMicrosoftSkin;
exports.resetMicrosoftSkin = resetMicrosoftSkin;
/**
 * 账号系统
 * 微软账号（Live 设备码流程：00000000402b5328 是微软 Live 的公共客户端，国内网络可用）+ 离线账号
 * 痛点 #17（OAuth 各家实现参差）#18（错误码人话翻译）#20（系统时间错误检测）#22（多账号）#24（名字说明）
 *
 * 说明：设备码端点为 login.live.com 的 oauth20_*.srf（consumers 租户的 v2.0 端点不接受该 Live 客户端）。
 */
const crypto = __importStar(require("crypto"));
const fs = __importStar(require("fs"));
const net_1 = require("./net");
const paths = __importStar(require("./paths"));
const store_1 = require("./store");
const CLIENT_ID = '00000000402b5328';
const DEVICE_CODE_URL = 'https://login.live.com/oauth20_connect.srf';
const TOKEN_URL = 'https://login.live.com/oauth20_token.srf';
const LIVE_SCOPE = 'service::user.auth.xboxlive.com::MBI_SSL';
/** 用户关闭登录弹窗后标记取消，轮询在下一轮尽快退出，避免后台白等 15 分钟 */
const canceledMicrosoftLogins = new Set();
function cancelMicrosoftLogin(userCode) {
    if (userCode)
        canceledMicrosoftLogins.add(String(userCode));
}
const load = () => {
    const raw = (0, store_1.readJson)(paths.accountsFile(), { accounts: [], activeId: null });
    // accounts.json 可能被手工改坏/半写入：只保留字段完整的账号，坏条目跳过而不是让账号页崩溃
    const accounts = Array.isArray(raw?.accounts)
        ? raw.accounts.filter((a) => a && typeof a.id === 'string' && typeof a.name === 'string' && typeof a.uuid === 'string' && (a.type === 'microsoft' || a.type === 'offline'))
        : [];
    const rawActive = typeof raw?.activeId === 'string' ? raw.activeId : null;
    // activeId 指向已删除/不存在的账号时自动落到第一个，避免“有账号却显示未登录”
    const activeId = rawActive && accounts.some(a => a.id === rawActive) ? rawActive : (accounts[0]?.id ?? null);
    return { accounts, activeId };
};
const save = (data) => (0, store_1.writeJson)(paths.accountsFile(), data);
const publicView = (a) => ({
    id: a.id,
    type: a.type,
    name: a.name,
    uuid: a.uuid,
    skinUrl: a.skinUrl ?? null,
    capeUrl: a.capeUrl ?? null,
    skinModel: a.skinModel ?? null,
    expiresAt: a.expiresAt ?? null,
    lastUsedAt: a.lastUsedAt,
});
function listAccounts() {
    return load().accounts.map(publicView);
}
function getActiveAccount() {
    const data = load();
    const hit = data.accounts.find(a => a.id === data.activeId);
    return hit ? publicView(hit) : null;
}
function setActiveAccount(id) {
    const data = load();
    if (data.accounts.some(a => a.id === id)) {
        data.activeId = id;
        save(data);
    }
}
function removeAccount(id) {
    const data = load();
    data.accounts = data.accounts.filter(a => a.id !== id);
    if (data.activeId === id)
        data.activeId = data.accounts[0]?.id ?? null;
    save(data);
}
/* ---------- 离线账号 ---------- */
function offlineUuid(name) {
    const md5 = crypto.createHash('md5').update(`OfflinePlayer:${name}`, 'utf8').digest();
    md5[6] = (md5[6] & 0x0f) | 0x30;
    md5[8] = (md5[8] & 0x3f) | 0x80;
    const hex = md5.toString('hex');
    return `${hex.slice(0, 8)}-${hex.slice(8, 12)}-${hex.slice(12, 16)}-${hex.slice(16, 20)}-${hex.slice(20)}`;
}
function createOfflineAccount(name, skinUrl) {
    const trimmed = name.trim();
    if (!/^[A-Za-z0-9_]{1,16}$/.test(trimmed)) {
        throw new Error('离线玩家名只能包含英文字母、数字、下划线，且不超过 16 个字符');
    }
    const data = load();
    const account = {
        id: `offline:${trimmed.toLowerCase()}`,
        type: 'offline',
        name: trimmed,
        uuid: offlineUuid(trimmed),
        skinUrl: skinUrl ?? null,
        capeUrl: null,
        skinModel: null,
        expiresAt: null,
        lastUsedAt: Date.now(),
    };
    data.accounts = data.accounts.filter(a => a.id !== account.id);
    data.accounts.push(account);
    if (!data.activeId)
        data.activeId = account.id;
    save(data);
    return publicView(account);
}
/* ---------- 微软账号：设备码 ---------- */
async function beginMicrosoftLogin() {
    const body = new URLSearchParams({
        client_id: CLIENT_ID,
        scope: LIVE_SCOPE,
        response_type: 'device_code',
    }).toString();
    const res = await (0, net_1.fetchWithTimeout)(DEVICE_CODE_URL, {
        method: 'POST',
        timeoutMs: 20000,
        headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
        body,
    });
    if (res.status >= 400) {
        let detail = `HTTP ${res.status}`;
        try {
            const json = JSON.parse(res.body.toString('utf8'));
            detail = json.error_description ?? json.error ?? detail;
        }
        catch { /* 用默认描述 */ }
        throw new Error(`无法启动微软登录：${detail}`);
    }
    const json = JSON.parse(res.body.toString('utf8'));
    return {
        deviceCode: json.device_code,
        userCode: json.user_code ?? json.userCode,
        verificationUri: json.verification_uri ?? 'https://microsoft.com/link',
        expiresIn: json.expires_in ?? 900,
        interval: json.interval ?? 5,
        message: json.message ?? `请在浏览器中打开 ${json.verification_uri ?? 'https://microsoft.com/link'} 并输入代码 ${json.user_code}`,
    };
}
/** XSTS XErr → 人话（痛点 #18） */
function translateXstsError(xerr, raw) {
    const code = String(xerr ?? '');
    switch (code) {
        case '2148916233': return '该微软账号还没有 Xbox 个人资料。请先用浏览器打开 xbox.com 登录一次，创建资料后再试。';
        case '2148916234': return '当前地区不支持 Xbox Live 服务。';
        case '2148916235': return 'Xbox Live 服务暂时异常，请稍后再试。';
        case '2148916236': return '需要先同意 Xbox Live 服务条款（用该账号在浏览器登录一次 xbox.com 即可）。';
        case '2148916237': return '该账号需要完成成年人验证后才能使用 Xbox Live。';
        case '2148916238': return '该账号是未成年账号，需要家长先把它加入家庭组并同意。';
        case '2148916242': return '该账号需要完成家长验证。';
        default: return `Xbox Live 授权失败（XErr ${code || '未知'}）${raw ? `：${raw}` : ''}`;
    }
}
function checkClockSkew(resHeaders) {
    const dateHeader = resHeaders?.['date'] ?? resHeaders?.['Date'];
    if (!dateHeader)
        return null;
    const serverTime = new Date(Array.isArray(dateHeader) ? dateHeader[0] : dateHeader).getTime();
    if (Number.isNaN(serverTime))
        return null;
    const skewMs = Math.abs(serverTime - Date.now());
    if (skewMs > 5 * 60 * 1000) {
        return `你的系统时间与服务器相差超过 ${Math.round(skewMs / 60000)} 分钟，微软登录会因此被拒绝。请校准系统日期/时间后重试。（这是最常见的"明明密码对却登不上"的原因）`;
    }
    return null;
}
async function pollMicrosoftToken(session) {
    const deadline = Date.now() + session.expiresIn * 1000;
    while (Date.now() < deadline) {
        if (canceledMicrosoftLogins.has(session.userCode))
            throw new Error('登录已取消。');
        await new Promise(r => setTimeout(r, session.interval * 1000));
        if (canceledMicrosoftLogins.has(session.userCode))
            throw new Error('登录已取消。');
        const body = new URLSearchParams({
            client_id: CLIENT_ID,
            grant_type: 'urn:ietf:params:oauth:grant-type:device_code',
            device_code: session.deviceCode,
        }).toString();
        const res = await (0, net_1.fetchWithTimeout)(TOKEN_URL, {
            method: 'POST',
            timeoutMs: 20000,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
            body,
        });
        let json = {};
        try {
            json = JSON.parse(res.body.toString('utf8'));
        }
        catch { /* keep empty */ }
        if (res.status < 400) {
            return {
                msToken: json.access_token,
                refreshToken: json.refresh_token ?? null,
                expiresIn: json.expires_in ?? 86400,
                skewWarning: checkClockSkew(res.headers),
            };
        }
        const err = String(json.error ?? '');
        if (err === 'authorization_pending')
            continue; // 用户还没完成
        if (err === 'slow_down') {
            await new Promise(r => setTimeout(r, 5000));
            continue;
        }
        if (err === 'authorization_declined')
            throw new Error('你在浏览器中拒绝了此次登录请求。');
        if (err === 'expired_token')
            throw new Error('登录代码已过期，请重新发起登录。');
        throw new Error(`微软登录失败：${json.error_description ?? json.error ?? `HTTP ${res.status}`}`);
    }
    throw new Error('登录超时：验证代码已过期，请重试。');
}
/** 用 MS access_token 走完 Xbox → XSTS → Minecraft 链路，返回 MC 令牌与资料 */
async function mcTokenFromMsToken(msToken) {
    // Xbox Live 用户令牌
    const xblRes = await (0, net_1.fetchWithTimeout)('https://user.auth.xboxlive.com/user/authenticate', {
        method: 'POST',
        timeoutMs: 20000,
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
            Properties: { AuthMethod: 'RPS', SiteName: 'user.auth.xboxlive.com', RpsTicket: `d=${msToken}` },
            RelyingParty: 'http://auth.xboxlive.com',
            TokenType: 'JWT',
        }),
    });
    if (xblRes.status >= 400) {
        const skew = checkClockSkew(xblRes.headers);
        throw new Error(skew ?? `Xbox Live 认证失败（HTTP ${xblRes.status}）。请确认系统时间正确，或稍后再试。`);
    }
    const xbl = JSON.parse(xblRes.body.toString('utf8'));
    const xblToken = xbl.Token;
    const uhs = xbl?.DisplayClaims?.xui?.[0]?.uhs ?? '';
    // XSTS
    const xstsRes = await (0, net_1.fetchWithTimeout)('https://xsts.auth.xboxlive.com/xsts/authorize', {
        method: 'POST',
        timeoutMs: 20000,
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({
            Properties: { SandboxId: 'RETAIL', UserTokens: [xblToken] },
            RelyingParty: 'rp://api.minecraftservices.com/',
            TokenType: 'JWT',
        }),
    });
    if (xstsRes.status >= 400) {
        let xerr;
        try {
            xerr = String(JSON.parse(xstsRes.body.toString('utf8'))?.XErr ?? '');
        }
        catch { /* ignore */ }
        throw new Error(translateXstsError(xerr, undefined));
    }
    const xsts = JSON.parse(xstsRes.body.toString('utf8'));
    const xstsToken = xsts.Token;
    // Minecraft 服务令牌
    const mcRes = await (0, net_1.fetchWithTimeout)('https://api.minecraftservices.com/authentication/login_with_xbox', {
        method: 'POST',
        timeoutMs: 20000,
        headers: { 'Content-Type': 'application/json', Accept: 'application/json' },
        body: JSON.stringify({ identityToken: `XBL3.0 x=${uhs};${xstsToken}` }),
    });
    if (mcRes.status >= 400) {
        throw new Error(`Minecraft 服务认证失败（HTTP ${mcRes.status}）。`);
    }
    const mcJson = JSON.parse(mcRes.body.toString('utf8'));
    const mcToken = mcJson.access_token;
    const mcExpiresIn = mcJson.expires_in ?? 86400;
    // 玩家资料（同时检查是否购买了 Java 版）
    const profRes = await (0, net_1.fetchWithTimeout)('https://api.minecraftservices.com/minecraft/profile', {
        timeoutMs: 20000,
        headers: { Authorization: `Bearer ${mcToken}`, Accept: 'application/json' },
    });
    if (profRes.status === 404 || profRes.status === 401 || profRes.status === 403) {
        throw new Error('该微软账号没有购买 Minecraft Java 版，因此无法登录。\n请确认在 minecraft.net 购买过 Java Edition，或使用离线账号。');
    }
    if (profRes.status >= 400) {
        throw new Error(`获取玩家资料失败（HTTP ${profRes.status}）。`);
    }
    const profile = JSON.parse(profRes.body.toString('utf8'));
    const rawId = String(profile.id).replace(/-/g, '');
    const dashed = rawId.length === 32 ? `${rawId.slice(0, 8)}-${rawId.slice(8, 12)}-${rawId.slice(12, 16)}-${rawId.slice(16, 20)}-${rawId.slice(20)}` : rawId;
    return {
        mcToken,
        mcExpiresIn,
        name: profile.name,
        uuid: dashed,
        skinUrl: profile?.skins?.[0]?.url ?? null,
        skinModel: String(profile?.skins?.[0]?.variant ?? '').toLowerCase() === 'slim' ? 'slim' : 'classic',
    };
}
/** 完整走通 Xbox → XSTS → Minecraft 服务 链路并保存账号 */
async function finishMicrosoftLogin(session) {
    try {
        const { msToken, refreshToken, skewWarning } = await pollMicrosoftToken(session);
        const chain = await mcTokenFromMsToken(msToken);
        const data = load();
        const account = {
            id: `microsoft:${chain.uuid.replace(/-/g, '')}`,
            type: 'microsoft',
            name: chain.name,
            uuid: chain.uuid,
            skinUrl: chain.skinUrl,
            capeUrl: null,
            skinModel: chain.skinModel,
            accessToken: chain.mcToken,
            refreshToken: refreshToken ?? null,
            expiresAt: Date.now() + chain.mcExpiresIn * 1000,
            lastUsedAt: Date.now(),
        };
        data.accounts = data.accounts.filter(a => a.id !== account.id);
        data.accounts.push(account);
        data.activeId = account.id;
        save(data);
        return { account: publicView(account), warn: skewWarning };
    }
    finally {
        canceledMicrosoftLogins.delete(session.userCode);
    }
}
/** 用刷新令牌换新的 MS token，再重跑整条链路 */
async function refreshMicrosoftAccount(account) {
    if (!account.refreshToken)
        return null;
    try {
        const body = new URLSearchParams({
            client_id: CLIENT_ID,
            grant_type: 'refresh_token',
            refresh_token: account.refreshToken,
            scope: LIVE_SCOPE,
        }).toString();
        const res = await (0, net_1.fetchWithTimeout)(TOKEN_URL, {
            method: 'POST',
            timeoutMs: 20000,
            headers: { 'Content-Type': 'application/x-www-form-urlencoded', Accept: 'application/json' },
            body,
        });
        if (res.status >= 400)
            return null;
        const json = JSON.parse(res.body.toString('utf8'));
        const chain = await mcTokenFromMsToken(json.access_token);
        account.accessToken = chain.mcToken;
        if (json.refresh_token)
            account.refreshToken = json.refresh_token;
        account.expiresAt = Date.now() + chain.mcExpiresIn * 1000;
        account.name = chain.name;
        account.uuid = chain.uuid;
        account.skinUrl = chain.skinUrl;
        account.skinModel = chain.skinModel;
        account.lastUsedAt = Date.now();
        return account;
    }
    catch {
        return null;
    }
}
/** 同一账号的刷新请求合并为一个，避免并发使用旧 refresh_token（微软会轮换令牌） */
const refreshJobs = new Map();
function refreshAccountOnce(account) {
    const existing = refreshJobs.get(account.id);
    if (existing)
        return existing;
    // 传副本：refreshMicrosoftAccount 会就地修改对象，不能让并发调用共享它
    const job = refreshMicrosoftAccount({ ...account })
        .finally(() => { refreshJobs.delete(account.id); });
    refreshJobs.set(account.id, job);
    return job;
}
/** 获取可用于启动的 accessToken（自动刷新）；返回 null 表示需要重新登录 */
async function getValidAccessToken(accountId) {
    const data = load();
    const account = data.accounts.find(a => a.id === accountId);
    if (!account)
        return null;
    if (account.type === 'offline') {
        return { accessToken: '0', userType: 'legacy', uuid: account.uuid, name: account.name };
    }
    let valid = account;
    if (!valid.accessToken || !valid.expiresAt || valid.expiresAt - Date.now() <= 60_000) {
        const refreshed = await refreshAccountOnce(valid);
        if (!refreshed)
            return null;
        valid = refreshed;
        // 等待刷新期间用户可能新增/移除了其它账号：重新读取，只写回这一个账号，
        // 不能把开头读到的旧快照整体 save 回去（会复活已删除的账号或丢掉新登录的账号）。
        const fresh = load();
        const idx = fresh.accounts.findIndex(a => a.id === accountId);
        if (idx < 0)
            return null;
        fresh.accounts[idx] = refreshed;
        save(fresh);
    }
    return { accessToken: valid.accessToken, userType: 'msa', uuid: valid.uuid, name: valid.name };
}
/* ---------- 皮肤 / 披风 ---------- */
const SKIN_API = 'https://api.minecraftservices.com/minecraft/profile/skins';
const MAX_IMAGE_BYTES = 4 * 1024 * 1024;
function readPng(filePath) {
    const buf = fs.readFileSync(filePath);
    if (buf.length < 32)
        throw new Error('图片文件为空或已损坏');
    if (buf.length > MAX_IMAGE_BYTES)
        throw new Error('图片超过 4 MB，请换一张（Minecraft 皮肤是 64×64 的小图）');
    if (buf.readUInt32BE(0) !== 0x89504e47)
        throw new Error('请选择 PNG 格式的图片（Minecraft 皮肤 / 披风必须是 PNG）');
    const width = buf.readUInt32BE(16);
    const height = buf.readUInt32BE(20);
    return { width, height, dataUrl: `data:image/png;base64,${buf.toString('base64')}` };
}
function updateAccount(accountId, mutate) {
    const data = load();
    const account = data.accounts.find(a => a.id === accountId);
    if (!account)
        throw new Error('账号不存在');
    mutate(account);
    save(data);
    return publicView(account);
}
/** 离线账号导入本地皮肤：仅保存到本机，仅启动器界面可见 */
function setLocalSkin(accountId, filePath, model) {
    const data = load();
    const account = data.accounts.find(a => a.id === accountId);
    if (!account)
        throw new Error('账号不存在');
    if (account.type === 'microsoft')
        throw new Error('微软账号请使用「上传皮肤到 Mojang」，这样其他玩家才能看到。');
    const png = readPng(filePath);
    if (png.width !== 64 || (png.height !== 64 && png.height !== 32)) {
        throw new Error(`皮肤尺寸应为 64×64（或旧版 64×32），当前是 ${png.width}×${png.height}。`);
    }
    account.skinUrl = png.dataUrl;
    account.skinModel = model;
    save(data);
    return publicView(account);
}
function clearLocalSkin(accountId) {
    return updateAccount(accountId, account => {
        if (account.type === 'microsoft')
            throw new Error('微软账号的皮肤由 Mojang 管理，请使用「恢复默认皮肤」。');
        account.skinUrl = null;
        account.skinModel = null;
    });
}
/** 本地披风预览：Minecraft 客户端不会读取，仅启动器展示用 */
function setLocalCape(accountId, filePath) {
    const png = readPng(filePath);
    if (png.width !== 64 || (png.height !== 32 && png.height !== 64)) {
        throw new Error(`披风尺寸应为 64×32，当前是 ${png.width}×${png.height}。`);
    }
    return updateAccount(accountId, account => { account.capeUrl = png.dataUrl; });
}
function clearLocalCape(accountId) {
    return updateAccount(accountId, account => { account.capeUrl = null; });
}
/** 微软账号上传皮肤到 Mojang（multipart，零第三方依赖） */
async function uploadMicrosoftSkin(accountId, filePath, variant) {
    const data = load();
    const account = data.accounts.find(a => a.id === accountId);
    if (!account)
        throw new Error('账号不存在');
    if (account.type !== 'microsoft')
        throw new Error('只有微软账号可以上传皮肤到 Mojang。');
    const png = readPng(filePath);
    if (png.width !== 64 || (png.height !== 64 && png.height !== 32)) {
        throw new Error(`皮肤尺寸应为 64×64（或旧版 64×32），当前是 ${png.width}×${png.height}。`);
    }
    const token = await getValidAccessToken(accountId);
    if (!token)
        throw new Error('登录令牌已过期，请先在账号页重新登录微软账号。');
    const boundary = `----MCLSkin${crypto.randomBytes(8).toString('hex')}`;
    const head = Buffer.from(`--${boundary}\r\nContent-Disposition: form-data; name="variant"\r\n\r\n${variant}\r\n` +
        `--${boundary}\r\nContent-Disposition: form-data; name="file"; filename="skin.png"\r\nContent-Type: image/png\r\n\r\n`, 'utf8');
    const tail = Buffer.from(`\r\n--${boundary}--\r\n`, 'utf8');
    const body = Buffer.concat([head, fs.readFileSync(filePath), tail]);
    const res = await (0, net_1.fetchWithTimeout)(SKIN_API, {
        method: 'POST',
        timeoutMs: 30000,
        headers: {
            Authorization: `Bearer ${token.accessToken}`,
            'Content-Type': `multipart/form-data; boundary=${boundary}`,
            Accept: 'application/json',
        },
        body,
    });
    if (res.status === 401 || res.status === 403) {
        throw new Error('Mojang 拒绝了皮肤上传（登录已过期或账号没有 Java 版）。请重新登录后再试。');
    }
    if (res.status === 400) {
        let detail = '';
        try {
            detail = JSON.parse(res.body.toString('utf8'))?.errorMessage ?? '';
        }
        catch { /* ignore */ }
        throw new Error(`Mojang 认为这张皮肤不合规${detail ? `：${detail}` : '（请检查 PNG 尺寸与内容）'}。`);
    }
    if (res.status >= 400)
        throw new Error(`皮肤上传失败（HTTP ${res.status}），请稍后再试。`);
    return updateAccount(accountId, acc => {
        acc.skinUrl = png.dataUrl;
        acc.skinModel = variant;
    });
}
/** 微软账号恢复为 Mojang 默认皮肤 */
async function resetMicrosoftSkin(accountId) {
    const accountData = load();
    const account = accountData.accounts.find(a => a.id === accountId);
    if (!account)
        throw new Error('账号不存在');
    if (account.type !== 'microsoft')
        throw new Error('只有微软账号可以恢复 Mojang 默认皮肤。');
    const token = await getValidAccessToken(accountId);
    if (!token)
        throw new Error('登录令牌已过期，请先在账号页重新登录微软账号。');
    const res = await (0, net_1.fetchWithTimeout)(SKIN_API, {
        method: 'DELETE',
        timeoutMs: 20000,
        headers: { Authorization: `Bearer ${token.accessToken}`, Accept: 'application/json' },
    });
    // 204 = 成功；其他错误按人话抛出
    if (res.status >= 400 && res.status !== 404) {
        throw new Error(`恢复默认皮肤失败（HTTP ${res.status}），请稍后再试。`);
    }
    return updateAccount(accountId, acc => {
        acc.skinUrl = null;
        acc.skinModel = null;
    });
}
