"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.CHANNEL_LABEL = void 0;
exports.getChannel = getChannel;
/**
 * 构建渠道：打包脚本在应用根目录写入 channel.json（stable / dev）。
 * 源码直跑或单文件便携版没有该文件，按稳定版处理；dev 版会打开 DevTools 并显示「开发版」标识。
 */
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const VALID = ['stable', 'dev'];
function getChannel() {
    try {
        const file = path.join(__dirname, '..', 'channel.json');
        const raw = JSON.parse(fs.readFileSync(file, 'utf8'));
        if (VALID.includes(raw.channel))
            return raw.channel;
    }
    catch { /* 没有渠道文件或内容损坏都按稳定版处理 */ }
    return 'stable';
}
exports.CHANNEL_LABEL = { stable: '稳定版', dev: '开发版' };
