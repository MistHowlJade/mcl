"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.environmentReport = environmentReport;
exports.exportDiagnostic = exportDiagnostic;
/**
 * 诊断包导出（痛点 #30：报障要日志时玩家找不到）
 * 内容：最近日志 + 崩溃报告 + 系统环境 + 实例清单 + 设置（已脱敏 token）
 */
const fs = __importStar(require("fs"));
const os = __importStar(require("os"));
const path = __importStar(require("path"));
const electron_1 = require("electron");
const zip_1 = require("./zip");
const paths = __importStar(require("./paths"));
const settings_1 = require("./settings");
const instances_1 = require("./instances");
const java_1 = require("./java");
function sanitizeSettings(settings) {
    const clone = JSON.parse(JSON.stringify(settings));
    if (clone.curseforge.apiKey)
        clone.curseforge.apiKey = '<已隐藏>';
    // 云同步凭据绝不出现在诊断包里（URL 也可能内嵌 token）
    clone.cloud.webdavUrl = clone.cloud.webdavUrl ? '<已隐藏>' : '';
    clone.cloud.webdavUsername = clone.cloud.webdavUsername ? '<已隐藏>' : '';
    clone.cloud.webdavPassword = clone.cloud.webdavPassword ? '<已隐藏>' : '';
    clone.cloud.gistToken = clone.cloud.gistToken ? '<已隐藏>' : '';
    clone.cloud.gistId = clone.cloud.gistId ? '<已隐藏>' : '';
    clone.network.proxyUrl = clone.network.proxyUrl ? '<已隐藏>' : '';
    clone.network.proxyUsername = clone.network.proxyUsername ? '<已隐藏>' : '';
    clone.network.proxyPassword = clone.network.proxyPassword ? '<已隐藏>' : '';
    return clone;
}
function environmentReport() {
    return {
        os: `${os.type()} ${os.release()}`,
        release: os.release(),
        arch: os.arch(),
        totalMemoryMB: Math.round(os.totalmem() / 1024 / 1024),
        freeMemoryMB: Math.round(os.freemem() / 1024 / 1024),
        cpuCores: os.cpus().length,
        hostnameHidden: '***',
    };
}
async function exportDiagnostic(instanceId) {
    // 先弹保存对话框（用户取消就什么都不做，不白做全量打包）
    const { canceled, filePath } = await electron_1.dialog.showSaveDialog({
        title: '导出诊断包',
        defaultPath: `mcl-diagnostic-${new Date().toISOString().slice(0, 10)}.zip`,
        filters: [{ name: 'ZIP 压缩包', extensions: ['zip'] }],
    });
    if (canceled || !filePath)
        return null;
    const files = [];
    const tmpDir = fs.mkdtempSync(path.join(os.tmpdir(), 'mcl-diag-'));
    const writeTmp = (name, content) => {
        const p = path.join(tmpDir, name);
        fs.mkdirSync(path.dirname(p), { recursive: true });
        fs.writeFileSync(p, content);
        return p;
    };
    // 1) 日志（最近 20 个）
    const mtimeOf = (file) => { try {
        return fs.statSync(file).mtimeMs;
    }
    catch {
        return 0;
    } };
    if (fs.existsSync(paths.logsDir())) {
        const logs = fs.readdirSync(paths.logsDir())
            .filter(f => f.endsWith('.log') || f.endsWith('.txt'))
            .map(f => ({ f, m: mtimeOf(path.join(paths.logsDir(), f)) }))
            .filter(x => x.m > 0)
            .sort((a, b) => b.m - a.m).slice(0, 20);
        for (const { f } of logs)
            files.push({ name: `logs/${f}`, absPath: path.join(paths.logsDir(), f) });
    }
    // 2) 崩溃报告（最近 5 个）
    // instanceId 来自渲染进程：只接受真实存在的实例，避免 ../ 把别的目录打进诊断包
    const validInstanceId = typeof instanceId === 'string' && (0, instances_1.listInstances)().some(i => i.id === instanceId) ? instanceId : null;
    if (validInstanceId) {
        const crashDir = path.join(paths.gameDir(validInstanceId), 'crash-reports');
        if (fs.existsSync(crashDir)) {
            const crashes = fs.readdirSync(crashDir)
                .filter(f => f.endsWith('.txt'))
                .map(f => ({ f, m: mtimeOf(path.join(crashDir, f)) }))
                .filter(x => x.m > 0)
                .sort((a, b) => b.m - a.m).slice(0, 5);
            for (const { f } of crashes)
                files.push({ name: `crash-reports/${f}`, absPath: path.join(crashDir, f) });
        }
        const latestLog = path.join(paths.gameDir(validInstanceId), 'logs', 'latest.log');
        if (fs.existsSync(latestLog))
            files.push({ name: 'game-logs/latest.log', absPath: latestLog });
    }
    // 3) 环境与设置（脱敏）
    files.push({ name: 'environment.json', absPath: writeTmp('environment.json', JSON.stringify(environmentReport(), null, 2)) });
    files.push({ name: 'settings.json', absPath: writeTmp('settings.json', JSON.stringify(sanitizeSettings((0, settings_1.getSettings)()), null, 2)) });
    const instances = (0, instances_1.listInstances)().map(i => ({ id: i.id, name: i.name, mcVersion: i.mcVersion, loader: i.loader, loaderVersion: i.loaderVersion, memoryPreset: i.memoryPreset, modsCount: i.modsCount }));
    files.push({ name: 'instances.json', absPath: writeTmp('instances.json', JSON.stringify(instances, null, 2)) });
    try {
        const javas = await (0, java_1.detectSystemJavas)();
        files.push({ name: 'javas.json', absPath: writeTmp('javas.json', JSON.stringify(javas, null, 2)) });
    }
    catch { /* 检测失败也不阻塞导出 */ }
    try {
        const buffer = (0, zip_1.zipFromFiles)(files);
        fs.writeFileSync(filePath, buffer);
    }
    finally {
        fs.rmSync(tmpDir, { recursive: true, force: true });
    }
    electron_1.shell.showItemInFolder(filePath);
    return filePath;
}
