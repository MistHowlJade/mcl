"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.bindServiceEvents = bindServiceEvents;
exports.registerIpcHandlers = registerIpcHandlers;
/**
 * IPC 总线：渲染进程 ↔ 主进程
 * 所有 handle 包装统一错误边界（异常 → 标准 { ok:false, error } 之外的抛出由 renderer catch）
 */
const electron_1 = require("electron");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const paths = __importStar(require("./paths"));
const settings_1 = require("./settings");
const instances = __importStar(require("./instances"));
const versionService = __importStar(require("./version"));
const javaService = __importStar(require("./java"));
const authService = __importStar(require("./auth"));
const minecraft = __importStar(require("./minecraft"));
const backups = __importStar(require("./backup"));
const modrinth = __importStar(require("./modrinth"));
const modpack = __importStar(require("./modpack"));
const modhealth = __importStar(require("./modhealth"));
const migrate = __importStar(require("./migrate"));
const crashService = __importStar(require("./crash"));
const diagnostic = __importStar(require("./diagnostic"));
const logsService = __importStar(require("./logs"));
const serverService = __importStar(require("./server"));
const cloudService = __importStar(require("./cloud"));
const contentService = __importStar(require("./content"));
const exporter = __importStar(require("./exporter"));
const updateService = __importStar(require("./update"));
const lanService = __importStar(require("./lan"));
const tasks_1 = require("./tasks");
const version_1 = require("./version");
const net_1 = require("./net");
const channel_1 = require("./channel");
const sendToAll = (channel, payload) => {
    for (const win of electron_1.BrowserWindow.getAllWindows()) {
        if (!win.isDestroyed())
            win.webContents.send(channel, payload);
    }
};
/**
 * 运行中的实例会持续写存档/日志：复制、备份、导出、删世界前统一拒绝，
 * 避免产出半写入的损坏文件，或删到游戏正在使用的世界。
 */
function assertInstanceIdle(instanceId, action) {
    const busyStates = ['preparing', 'downloading', 'launching', 'running'];
    if (minecraft.launchState.instanceId === instanceId && busyStates.includes(minecraft.launchState.status)) {
        throw new Error(`这个实例正在运行，无法${action}。请先退出游戏，等实例状态变为「已退出」后再试。`);
    }
}
/** 云快照可能覆盖存档/配置：有游戏在运行时整体拒绝，避免两边同时写同一批文件 */
function assertNoGameBusy(action) {
    const busyStates = ['preparing', 'downloading', 'launching', 'running'];
    if (busyStates.includes(minecraft.launchState.status)) {
        throw new Error(`游戏正在运行，无法${action}。请先退出游戏，避免覆盖正在写入的存档与配置。`);
    }
}
/* ---------- 下载任务中心：与启动流程联动 ---------- */
let launchDownloadTask = null;
function finishLaunchDownloadTask(ok, error) {
    if (!launchDownloadTask)
        return;
    const id = launchDownloadTask;
    launchDownloadTask = null;
    if (ok)
        tasks_1.downloadTasks.done(id);
    else
        tasks_1.downloadTasks.fail(id, error ?? '下载未完成');
}
/** 把一次「有明确开始/结束」的业务包成任务，失败时把人话错误带进任务列表 */
async function withTask(kind, name, fn, action) {
    const id = tasks_1.downloadTasks.begin(kind, name, action);
    try {
        const result = await fn();
        tasks_1.downloadTasks.done(id, action);
        return result;
    }
    catch (e) {
        tasks_1.downloadTasks.fail(id, (0, net_1.errorReason)(e), action);
        throw e;
    }
}
// 服务事件 → 渲染进程
function bindServiceEvents() {
    tasks_1.downloadTasks.on('changed', () => sendToAll('tasks:changed', tasks_1.downloadTasks.list()));
    minecraft.launchEvents.on('status', (s) => {
        if (s.status === 'downloading' && s.instanceId) {
            if (!launchDownloadTask) {
                const inst = instances.getInstance(s.instanceId);
                launchDownloadTask = tasks_1.downloadTasks.begin('launch', `${inst?.name ?? '游戏'} · 下载游戏文件`, { retry: { type: 'launch', instanceId: s.instanceId } });
                tasks_1.downloadTasks.setCanceler(launchDownloadTask, () => minecraft.cancelLaunchDownload());
            }
        }
        else if (['launching', 'running'].includes(s.status) && launchDownloadTask) {
            // 进入启动阶段说明本次下载已完成
            finishLaunchDownloadTask(true);
        }
    });
    minecraft.launchEvents.on('progress', (p) => {
        if (launchDownloadTask && p)
            tasks_1.downloadTasks.progress(launchDownloadTask, p.done, p.total);
    });
    minecraft.launchEvents.on('exit', (e) => {
        if (e?.crashed)
            finishLaunchDownloadTask(false, '游戏启动失败');
    });
    minecraft.launchEvents.on('status', s => sendToAll('launch:status', s));
    minecraft.launchEvents.on('log', line => sendToAll('launch:log', line));
    minecraft.launchEvents.on('progress', p => sendToAll('launch:progress', p));
    minecraft.launchEvents.on('crash', d => sendToAll('launch:crash', d));
    minecraft.launchEvents.on('exit', e => sendToAll('launch:exit', e));
    serverService.serverEvents.on('status', (info) => sendToAll('server:status', info));
    serverService.serverEvents.on('log', (payload) => sendToAll('server:log', payload));
}
const isSafeExternal = (url) => /^https?:\/\//i.test(url);
function registerIpcHandlers() {
    /* ---------- 应用元信息 ---------- */
    electron_1.ipcMain.handle('app:info', () => ({
        name: 'MCL',
        version: electron_1.app.getVersion(),
        dataDir: paths.dataRoot(),
        platform: process.platform,
        arch: process.arch,
        channel: (0, channel_1.getChannel)(),
    }));
    /* ---------- 窗口控制（无边框窗口） ---------- */
    electron_1.ipcMain.handle('win:minimize', () => electron_1.BrowserWindow.getFocusedWindow()?.minimize());
    electron_1.ipcMain.handle('win:toggleMaximize', () => {
        const win = electron_1.BrowserWindow.getFocusedWindow();
        if (!win)
            return false;
        if (win.isMaximized())
            win.unmaximize();
        else
            win.maximize();
        return win.isMaximized();
    });
    electron_1.ipcMain.handle('win:isMaximized', () => electron_1.BrowserWindow.getFocusedWindow()?.isMaximized() ?? false);
    electron_1.ipcMain.handle('win:close', () => electron_1.BrowserWindow.getFocusedWindow()?.close());
    electron_1.ipcMain.handle('win:setZoom', (_e, factor) => {
        const win = electron_1.BrowserWindow.getFocusedWindow();
        if (win)
            win.webContents.setZoomFactor(Math.min(2, Math.max(0.75, Number(factor) || 1)));
        return true;
    });
    /* ---------- 设置 ---------- */
    electron_1.ipcMain.handle('settings:get', () => (0, settings_1.getSettings)());
    electron_1.ipcMain.handle('settings:update', (_e, patch) => (0, settings_1.updateSettings)(patch));
    electron_1.ipcMain.handle('settings:reset', () => (0, settings_1.resetSettings)());
    /* ---------- Shell ---------- */
    electron_1.ipcMain.handle('shell:openPath', (_e, p) => {
        if (typeof p !== 'string' || !p)
            return '路径无效';
        // 只允许打开 MCL 数据目录内的路径：即使渲染进程被注入，也不能借 openPath 启动任意程序
        const root = path.resolve(paths.dataRoot());
        const target = path.resolve(p);
        if (target !== root && !target.startsWith(root + path.sep))
            return '只能打开 MCL 数据目录内的文件';
        return electron_1.shell.openPath(target);
    });
    electron_1.ipcMain.handle('shell:openExternal', (_e, url) => {
        if (!isSafeExternal(url))
            return;
        return electron_1.shell.openExternal(url);
    });
    electron_1.ipcMain.handle('clipboard:write', (_e, text) => {
        electron_1.clipboard.writeText(String(text ?? ''));
        return true;
    });
    electron_1.ipcMain.handle('dialog:pickFolder', async () => {
        const win = electron_1.BrowserWindow.getFocusedWindow();
        const result = await electron_1.dialog.showOpenDialog(win, { properties: ['openDirectory'], title: '选择数据目录' });
        return result.canceled ? null : result.filePaths[0];
    });
    electron_1.ipcMain.handle('dialog:pickFile', async (_e, filters) => {
        const win = electron_1.BrowserWindow.getFocusedWindow();
        const result = await electron_1.dialog.showOpenDialog(win, { properties: ['openFile'], filters });
        return result.canceled ? null : result.filePaths[0];
    });
    /* ---------- 版本清单 ---------- */
    electron_1.ipcMain.handle('versions:list', async () => {
        const settings = (0, settings_1.getSettings)();
        const manifest = await (0, version_1.getVersionManifest)(settings.download.source, settings.download.customMirror);
        return manifest.versions.map(v => ({ id: v.id, type: v.type, releaseTime: v.releaseTime }));
    });
    /* ---------- Java ---------- */
    electron_1.ipcMain.handle('java:detect', () => javaService.detectSystemJavas());
    electron_1.ipcMain.handle('java:recommended', (_e, mcVersion) => ({
        major: javaService.recommendedJavaMajor(mcVersion),
    }));
    electron_1.ipcMain.handle('java:install', async (_e, major) => {
        const taskId = tasks_1.downloadTasks.begin('java', `安装 Java ${major}`);
        const action = { openDir: paths.javaDir(), retry: { type: 'java', major } };
        try {
            const exe = await javaService.installJava(major, (stage, received, total) => {
                if (typeof received === 'number' && typeof total === 'number')
                    tasks_1.downloadTasks.progress(taskId, received, total);
                sendToAll('java:progress', { stage, received, total });
            });
            tasks_1.downloadTasks.done(taskId, { ...action, revealFile: exe });
            return exe;
        }
        catch (e) {
            tasks_1.downloadTasks.fail(taskId, (0, net_1.errorReason)(e), action);
            throw e;
        }
    });
    /* ---------- 实例 ---------- */
    electron_1.ipcMain.handle('instances:list', () => instances.listInstances());
    electron_1.ipcMain.handle('instances:get', (_e, id) => instances.getInstance(id));
    electron_1.ipcMain.handle('instances:create', (_e, input) => instances.createInstance(input));
    electron_1.ipcMain.handle('instances:update', (_e, id, patch) => instances.updateInstance(id, patch));
    electron_1.ipcMain.handle('instances:duplicate', (_e, id) => {
        assertInstanceIdle(id, '复制实例');
        return instances.duplicateInstance(id);
    });
    electron_1.ipcMain.handle('instances:delete', async (_e, id) => {
        // 游戏运行时删除会把正在使用的存档/模组删到一半，先拒绝并给出人话提示
        assertInstanceIdle(id, '删除实例');
        const backupDir = path.join(paths.backupsDir(), 'deleted-instances');
        return instances.deleteInstanceWithBackup(id, backupDir);
    });
    electron_1.ipcMain.handle('instances:diskUsage', (_e, id) => ({ instance: instances.instanceDiskBytes(id), shared: instances.sharedDiskBytes() }));
    electron_1.ipcMain.handle('instances:openGameDir', (_e, id) => {
        const instance = instances.getInstance(id);
        if (!instance)
            throw new Error('实例不存在');
        return electron_1.shell.openPath(instance.gameDir);
    });
    electron_1.ipcMain.handle('instances:openInstanceDir', (_e, id) => {
        const instance = instances.getInstance(id);
        if (!instance)
            throw new Error('实例不存在');
        return electron_1.shell.openPath(paths.instanceDir(instance.id));
    });
    /* ---------- 启动 ---------- */
    electron_1.ipcMain.handle('launch:start', async (_e, instanceId, accountId) => {
        // 状态由 launchInstance 自己接管（它的并发保护依赖 status，不能在这里预写 instanceId）
        void minecraft.launchInstance(instanceId, { accountId }).catch(err => {
            const message = (0, net_1.errorReason)(err);
            // 若只是"已有实例在运行"被拒绝，绝不能把正在运行的实例状态重置为 idle
            if (!(err instanceof minecraft.LaunchBusyError) && minecraft.launchState.instanceId === instanceId) {
                minecraft.launchState.status = 'idle';
                minecraft.launchState.message = message;
                minecraft.launchState.progress = null;
                sendToAll('launch:status', { ...minecraft.launchState });
            }
            finishLaunchDownloadTask(false, message);
            sendToAll('launch:failed', { instanceId, error: message });
        });
        return { started: true };
    });
    electron_1.ipcMain.handle('launch:state', () => ({ ...minecraft.launchState }));
    electron_1.ipcMain.handle('launch:cancelDownload', () => minecraft.cancelLaunchDownload());
    electron_1.ipcMain.handle('launch:killResidual', async () => ({ killed: await minecraft.killResidualProcesses() }));
    /* ---------- 账号 ---------- */
    electron_1.ipcMain.handle('accounts:list', () => authService.listAccounts());
    electron_1.ipcMain.handle('accounts:active', () => authService.getActiveAccount());
    electron_1.ipcMain.handle('accounts:setActive', (_e, id) => { authService.setActiveAccount(id); return true; });
    electron_1.ipcMain.handle('accounts:remove', (_e, id) => { authService.removeAccount(id); return true; });
    electron_1.ipcMain.handle('accounts:createOffline', (_e, name, skinDataUrl) => authService.createOfflineAccount(name, skinDataUrl ?? null));
    electron_1.ipcMain.handle('accounts:beginMicrosoft', async () => {
        const session = await authService.beginMicrosoftLogin();
        // 后台完成轮询链路；结果通过事件推给渲染进程（带 userCode 供前端忽略旧尝试）
        void authService.finishMicrosoftLogin(session).then(result => {
            sendToAll('accounts:microsoft-result', { ok: true, userCode: session.userCode, account: result.account, warn: result.warn ?? null });
        }).catch(err => {
            const message = (0, net_1.errorReason)(err);
            sendToAll('accounts:microsoft-result', { ok: false, userCode: session.userCode, canceled: message.includes('登录已取消'), error: message });
        });
        return session;
    });
    electron_1.ipcMain.handle('accounts:cancelMicrosoft', (_e, userCode) => { authService.cancelMicrosoftLogin(userCode); return true; });
    /* ---------- 皮肤 / 披风 ---------- */
    const pickPng = async (title) => {
        const win = electron_1.BrowserWindow.getFocusedWindow();
        const result = await electron_1.dialog.showOpenDialog(win, {
            properties: ['openFile'],
            title,
            filters: [{ name: 'PNG 图片', extensions: ['png'] }],
        });
        return result.canceled ? null : (result.filePaths[0] ?? null);
    };
    electron_1.ipcMain.handle('accounts:localSkin', async (_e, accountId, model) => {
        const file = await pickPng('选择皮肤 PNG（64×64 或旧版 64×32）');
        if (!file)
            return null;
        return authService.setLocalSkin(accountId, file, model === 'slim' ? 'slim' : 'classic');
    });
    electron_1.ipcMain.handle('accounts:clearLocalSkin', (_e, accountId) => authService.clearLocalSkin(accountId));
    electron_1.ipcMain.handle('accounts:localCape', async (_e, accountId) => {
        const file = await pickPng('选择披风 PNG（64×32）');
        if (!file)
            return null;
        return authService.setLocalCape(accountId, file);
    });
    electron_1.ipcMain.handle('accounts:clearLocalCape', (_e, accountId) => authService.clearLocalCape(accountId));
    electron_1.ipcMain.handle('accounts:microsoftSkin', async (_e, accountId, variant) => {
        const file = await pickPng('选择要上传到 Mojang 的皮肤 PNG');
        if (!file)
            return null;
        return authService.uploadMicrosoftSkin(accountId, file, variant === 'slim' ? 'slim' : 'classic');
    });
    electron_1.ipcMain.handle('accounts:microsoftSkinReset', (_e, accountId) => authService.resetMicrosoftSkin(accountId));
    /* ---------- 模组（Modrinth） ---------- */
    electron_1.ipcMain.handle('modrinth:search', (_e, query, opts) => modrinth.searchMods(query, opts));
    electron_1.ipcMain.handle('modrinth:searchContent', (_e, query, opts) => modrinth.searchContent(query, opts));
    electron_1.ipcMain.handle('modrinth:installContent', (_e, instanceId, projectId, versionId, kind, opts) => {
        const inst = instances.getInstance(instanceId);
        const sub = kind === 'modpack' ? null : kind === 'worlds' ? 'saves' : kind;
        const action = { openDir: inst ? (sub ? path.join(inst.gameDir, sub) : paths.instancesDir()) : paths.instancesDir() };
        const labels = { modpack: '整合包', resourcepacks: '资源包', shaderpacks: '光影包', worlds: '世界' };
        const taskKinds = { modpack: 'modpack', resourcepacks: 'resourcepack', shaderpacks: 'shader', worlds: 'world' };
        return withTask(taskKinds[kind], `下载${labels[kind]}：${opts.name ?? projectId}`, () => modrinth.installContent(instanceId, projectId, versionId, kind, opts), action);
    });
    electron_1.ipcMain.handle('modrinth:installed', (_e, instanceId) => {
        const tracked = modrinth.readInstalledMods(instanceId);
        const files = modrinth.listModFiles(instanceId);
        // mods 里可能同时有 foo.jar 与 foo.jar.disabled（手工复制/解压造成）：
        // 来源记录只挂在启用中的那份，否则两条结果会得到同一个 fileName，列表 key 重复且操作指向不明
        const enabledNames = new Set(files.filter(f => !f.disabled).map(f => f.fileName.toLowerCase()));
        const claimed = new Set();
        return files.map(f => {
            // 禁用文件磁盘名是 foo.jar.disabled，跟踪记录里仍是 foo.jar：
            // 不归一化会丢掉来源与可更新标记，更新时也找不到记录
            const trackedName = f.fileName.replace(/\.disabled$/i, '');
            const key = trackedName.toLowerCase();
            const claimable = !claimed.has(key) && (!f.disabled || !enabledNames.has(key));
            const match = claimable ? tracked.find(t => t.fileName.toLowerCase() === key) : undefined;
            if (match)
                claimed.add(key);
            return match ? { ...match, fileName: trackedName, sizeBytes: f.sizeBytes, disabled: f.disabled } : {
                fileName: f.fileName, projectId: null, versionId: null, versionNumber: null, title: null, loader: null,
                installedAt: 0, sizeBytes: f.sizeBytes, disabled: f.disabled, updateAvailable: null,
            };
        });
    });
    electron_1.ipcMain.handle('modrinth:install', (_e, instanceId, projectId, versionId, opts) => {
        const inst = instances.getInstance(instanceId);
        return withTask('mod', `安装模组：${projectId}`, () => modrinth.installMod(instanceId, projectId, versionId ?? undefined, opts), inst ? { openDir: path.join(inst.gameDir, 'mods') } : undefined);
    });
    electron_1.ipcMain.handle('modrinth:checkUpdates', (_e, instanceId, mcVersion, loader) => modrinth.checkModUpdates(instanceId, mcVersion, loader));
    electron_1.ipcMain.handle('modrinth:updateMod', (_e, instanceId, fileName) => {
        const inst = instances.getInstance(instanceId);
        return withTask('mod', `更新模组：${fileName}`, () => modrinth.updateMod(instanceId, fileName), inst ? { openDir: path.join(inst.gameDir, 'mods') } : undefined);
    });
    electron_1.ipcMain.handle('modrinth:toggle', (_e, instanceId, fileName) => modrinth.toggleModDisabled(instanceId, fileName));
    /* ---------- 模组体检 ---------- */
    electron_1.ipcMain.handle('mods:health', (_e, instanceId) => {
        const instance = instances.getInstance(instanceId);
        if (!instance)
            throw new Error('实例不存在');
        return modhealth.checkModHealth(instanceId, instance.gameDir, instance.loader);
    });
    electron_1.ipcMain.handle('mods:healthFix', (_e, instanceId, target) => {
        const instance = instances.getInstance(instanceId);
        if (!instance)
            throw new Error('实例不存在');
        return modhealth.applyModHealthFix(instanceId, instance.gameDir, target);
    });
    electron_1.ipcMain.handle('mods:openFolder', (_e, instanceId) => {
        const instance = instances.getInstance(instanceId);
        if (!instance)
            throw new Error('实例不存在');
        return electron_1.shell.openPath(path.join(instance.gameDir, 'mods'));
    });
    /* ---------- 整合包导入 ---------- */
    electron_1.ipcMain.handle('modpack:importDialog', async (_e, targetName) => {
        const win = electron_1.BrowserWindow.getFocusedWindow();
        const result = await electron_1.dialog.showOpenDialog(win, {
            properties: ['openFile'],
            title: '选择整合包（.zip）',
            filters: [{ name: '整合包', extensions: ['zip'] }],
        });
        if (result.canceled || !result.filePaths[0])
            return null;
        const filePath = result.filePaths[0];
        return withTask('modpack', `导入整合包：${path.basename(filePath)}`, () => modpack.importModpack(filePath, targetName, line => sendToAll('modpack:log', line)), { openDir: paths.instancesDir(), retry: { type: 'modpack', filePath } });
    });
    electron_1.ipcMain.handle('modpack:importFile', (_e, filePath, targetName) => {
        if (typeof filePath !== 'string' || !filePath)
            throw new Error('整合包路径无效');
        return withTask('modpack', `导入整合包：${path.basename(filePath)}`, () => modpack.importModpack(filePath, targetName, line => sendToAll('modpack:log', line)), { openDir: paths.instancesDir(), retry: { type: 'modpack', filePath } });
    });
    /* ---------- 备份 ---------- */
    electron_1.ipcMain.handle('backup:list', (_e, instanceId) => backups.listBackups(instanceId));
    electron_1.ipcMain.handle('backup:create', (_e, instanceId, name) => {
        // 运行中的世界文件仍在写入，手动备份会得到缺区块/半写入的存档
        assertInstanceIdle(instanceId, '创建存档备份');
        return backups.createBackup(instanceId, 'manual', name);
    });
    electron_1.ipcMain.handle('backup:delete', (_e, backupId, instanceId) => { backups.deleteBackup(backupId, instanceId); return true; });
    electron_1.ipcMain.handle('backup:restore', (_e, backupId, instanceId) => {
        // 游戏运行中恢复会被游戏进程覆盖，甚至在写存档时损坏世界
        assertInstanceIdle(instanceId, '恢复存档备份');
        return backups.restoreBackup(backupId, instanceId);
    });
    /* ---------- 崩溃分析 ---------- */
    electron_1.ipcMain.handle('crash:latest', (_e, instanceId) => crashService.analyzeCrash(instanceId));
    electron_1.ipcMain.handle('crash:analyzeText', (_e, text) => crashService.analyzeLogText(text));
    electron_1.ipcMain.handle('crash:fix', async (_e, instanceId, fix) => {
        switch (fix.action) {
            case 'fix:setMemoryPreset': {
                const preset = (fix.args?.preset ?? 'heavy');
                instances.updateInstance(instanceId, { memoryPreset: preset });
                return { ok: true, message: `已切换到「${preset === 'heavy' ? '大型整合包/光影' : preset}」内存预设，下次启动生效。` };
            }
            case 'fix:switchJava': {
                const instance = instances.getInstance(instanceId);
                if (!instance)
                    throw new Error('实例不存在');
                // 一键切换必须和启动管线用同一个权威来源：版本 JSON 的 javaVersion.majorVersion
                let major = javaService.recommendedJavaMajor(instance.mcVersion);
                try {
                    const settings = (0, settings_1.getSettings)();
                    const manifest = await versionService.getVersionManifest(settings.download.source, settings.download.customMirror);
                    const entry = manifest.versions.find(v => v.id === instance.mcVersion);
                    if (entry) {
                        const resolved = await versionService.resolveVersion(entry, settings.download.source, settings.download.customMirror);
                        if (Number.isInteger(resolved.javaVersion?.majorVersion))
                            major = resolved.javaVersion.majorVersion;
                    }
                }
                catch { /* 离线时退回版本号推导 */ }
                const pick = await javaService.pickJavaFor(instance.mcVersion, null, major);
                if (pick.java) {
                    instances.updateInstance(instanceId, { javaPath: pick.java.path });
                    return { ok: true, message: `已绑定 Java ${pick.java.version}（${pick.java.path}）。` };
                }
                const exe = await javaService.installJava(major, (stage, received, total) => sendToAll('java:progress', { stage, received, total }));
                instances.updateInstance(instanceId, { javaPath: exe });
                return { ok: true, message: `已自动下载并绑定 Java ${major}。` };
            }
            case 'fix:repairLibraries': {
                const result = await minecraft.repairLibraries(instanceId);
                return { ok: true, message: `已检查 ${result.checked} 个文件，修复 ${result.repaired} 个损坏文件${result.failed ? `，${result.failed} 个修复失败` : ''}。` };
            }
            case 'fix:reextractNatives': {
                minecraft.reextractNatives(instanceId);
                return { ok: true, message: '已清理旧的 natives 残留，下次启动将重新提取。' };
            }
            case 'fix:openModsFolder': {
                const instance = instances.getInstance(instanceId);
                if (instance)
                    electron_1.shell.openPath(path.join(instance.gameDir, 'mods'));
                return { ok: true, message: '已打开 mods 文件夹。' };
            }
            case 'fix:toggleMirror': {
                const settings = (0, settings_1.getSettings)();
                const next = settings.download.source === 'official' ? 'auto' : 'official';
                (0, settings_1.updateSettings)({ download: { ...settings.download, source: next } });
                return { ok: true, message: `下载源已切换为：${next === 'auto' ? '自动（BMCLAPI + 官方兜底）' : '官方源'}。` };
            }
            case 'fix:setUtf8': {
                (0, settings_1.updateSettings)({ launch: { utf8Encoding: true } });
                return { ok: true, message: '已开启强制 UTF-8 编码。' };
            }
            case 'fix:backupThenRestore': {
                const info = await backups.createBackup(instanceId, 'pre-restore', '一键修复前自动备份');
                return { ok: true, message: info ? `已创建备份：${info.name}（${Math.round(info.sizeBytes / 1024 / 1024)} MB）。` : '没有找到存档，已跳过备份。' };
            }
            case 'fix:addOpens': {
                const instance = instances.getInstance(instanceId);
                if (!instance)
                    throw new Error('实例不存在');
                const required = '--add-opens java.base/java.lang=ALL-UNNAMED';
                const current = (instance.jvmArgsExtra ?? '').split(/\s+/).filter(Boolean).join(' ');
                if (!current.includes(required)) {
                    instances.updateInstance(instanceId, { jvmArgsExtra: `${current} ${required}`.trim() });
                }
                return { ok: true, message: '已添加模块开放参数，下次启动生效。' };
            }
            case 'fix:disableMod': {
                const instance = instances.getInstance(instanceId);
                if (!instance)
                    throw new Error('实例不存在');
                const modsDir = path.join(instance.gameDir, 'mods');
                const target = fix.args?.file;
                if (target) {
                    // 磁盘上的禁用文件名是 foo.jar.disabled：先归一化，避免再次禁用变成 .disabled.disabled
                    const base = path.basename(String(target)).replace(/\.disabled$/i, '');
                    const enabled = path.join(modsDir, base);
                    const disabled = `${enabled}.disabled`;
                    if (fs.existsSync(enabled)) {
                        if (fs.existsSync(disabled)) {
                            return { ok: false, message: `mods 目录同时存在 ${base} 和 ${base}.disabled，请先手动删除一个重复文件。` };
                        }
                        fs.renameSync(enabled, disabled);
                        return { ok: true, message: `已将 ${base} 重命名为 .disabled，下次启动生效。` };
                    }
                    if (fs.existsSync(disabled)) {
                        return { ok: true, message: `${base} 已经是 .disabled。` };
                    }
                    return { ok: false, message: `在 mods 中找不到 ${base}` };
                }
                // 未指定具体模组：列出当前 mods 目录里全部条目，引导到体检处理
                const files = fs.existsSync(modsDir) ? fs.readdirSync(modsDir).filter(f => f.endsWith('.jar') || f.endsWith('.jar.disabled')) : [];
                return {
                    ok: true,
                    message: files.length > 0
                        ? `mods 目录当前 ${files.length} 个文件：${files.slice(0, 8).join('、')}${files.length > 8 ? '…' : ''}。请用「模组 → 体检」定位问题模组，或告诉 MCL 具体是哪个文件并传参 fix:disableMod + file=<文件名>。`
                        : 'mods 目录为空。',
                };
            }
            default:
                return { ok: false, message: '未知的修复动作。' };
        }
    });
    /* ---------- 迁移 ---------- */
    electron_1.ipcMain.handle('migrate:detect', () => migrate.detectCandidates());
    electron_1.ipcMain.handle('migrate:preview', (_e, root) => migrate.previewMigration(root));
    electron_1.ipcMain.handle('migrate:import', (_e, root, selectedNames) => migrate.importInstances(root, selectedNames));
    /* ---------- 日志 ---------- */
    electron_1.ipcMain.handle('logs:list', (_e, instanceId) => logsService.listLogs(instanceId));
    electron_1.ipcMain.handle('logs:read', (_e, name, instanceId, maxBytes) => logsService.readLog(name, instanceId, maxBytes));
    /* ---------- 诊断包 ---------- */
    electron_1.ipcMain.handle('diagnostic:export', (_e, instanceId) => diagnostic.exportDiagnostic(instanceId ?? null));
    /* ---------- 服务器管理 ---------- */
    // 同一服务器的启动请求串行化：startServer 内部有多段 await（选 Java、查端口），
    // 连点两次会在检查 child 之前都通过，最终 spawn 出两个抢同一端口的 Java 进程
    const startingServers = new Set();
    electron_1.ipcMain.handle('server:list', () => serverService.listServers());
    electron_1.ipcMain.handle('server:get', (_e, id) => serverService.getServer(id));
    electron_1.ipcMain.handle('server:create', (_e, input) => serverService.createServer(input));
    electron_1.ipcMain.handle('server:update', (_e, id, patch) => serverService.updateServer(id, patch));
    electron_1.ipcMain.handle('server:delete', (_e, id, backup) => serverService.deleteServer(id, backup !== false));
    electron_1.ipcMain.handle('server:prepare', (_e, id) => {
        const server = serverService.getServer(id);
        return withTask('server', `安装服务端：${server?.name ?? id}`, () => serverService.prepareServer(id), { openDir: paths.serverDir(id) });
    });
    electron_1.ipcMain.handle('server:start', async (_e, id) => {
        if (startingServers.has(id))
            throw new Error('服务器正在启动中，请等状态变为「运行中」或报错后再试。');
        startingServers.add(id);
        try {
            return await serverService.startServer(id);
        }
        finally {
            startingServers.delete(id);
        }
    });
    electron_1.ipcMain.handle('server:stop', (_e, id) => serverService.stopServer(id));
    electron_1.ipcMain.handle('server:kill', (_e, id) => serverService.killServer(id));
    electron_1.ipcMain.handle('server:sendCommand', (_e, id, command) => serverService.sendCommand(id, command));
    electron_1.ipcMain.handle('server:checkPort', (_e, port) => serverService.isPortAvailable(port));
    electron_1.ipcMain.handle('server:acceptEula', (_e, id) => serverService.acceptEula(id));
    electron_1.ipcMain.handle('server:properties', (_e, id) => serverService.readServerProperties(id));
    electron_1.ipcMain.handle('server:saveProperties', (_e, id, patch) => {
        const nextPatch = { ...patch };
        if (Object.prototype.hasOwnProperty.call(nextPatch, 'server-port')) {
            const port = Number(String(nextPatch['server-port']).trim());
            if (!Number.isInteger(port) || port < 1 || port > 65535)
                throw new Error('端口必须是 1–65535 之间的整数');
            nextPatch['server-port'] = String(port);
        }
        const saved = serverService.saveServerProperties(id, nextPatch);
        // 属性页直接改端口时同步 server.json，避免设置页显示旧端口
        if (nextPatch['server-port']) {
            const port = Number(nextPatch['server-port']);
            const current = serverService.getServer(id);
            if (current && current.port !== port)
                serverService.updateServer(id, { port });
        }
        return saved;
    });
    electron_1.ipcMain.handle('server:log', (_e, id, maxLines) => serverService.readServerLog(id, maxLines ?? 400));
    electron_1.ipcMain.handle('server:openDir', (_e, id) => {
        const server = serverService.getServer(id);
        if (!server)
            throw new Error('服务器不存在');
        return electron_1.shell.openPath(server.dir);
    });
    electron_1.ipcMain.handle('server:backups', (_e, id) => serverService.listServerBackups(id));
    electron_1.ipcMain.handle('server:backup', (_e, id, name) => serverService.backupServerWorld(id, name));
    electron_1.ipcMain.handle('server:restoreBackup', (_e, id, name) => serverService.restoreServerWorld(id, name));
    electron_1.ipcMain.handle('server:deleteBackup', (_e, id, name) => { serverService.deleteServerBackup(id, name); return true; });
    /* ---------- 云同步 ---------- */
    electron_1.ipcMain.handle('cloud:test', () => cloudService.testCloud());
    electron_1.ipcMain.handle('cloud:inspect', () => cloudService.inspectCloud());
    electron_1.ipcMain.handle('cloud:upload', () => {
        // 包含存档时才需要拦运行中的游戏；只同步配置时允许游戏开着
        if ((0, settings_1.getSettings)().cloud.includeSaves)
            assertNoGameBusy('上传含存档的云快照');
        return cloudService.uploadCloud();
    });
    electron_1.ipcMain.handle('cloud:download', () => {
        assertNoGameBusy('从云端恢复');
        return cloudService.downloadCloud();
    });
    /* ---------- 内容管理 ---------- */
    electron_1.ipcMain.handle('content:list', (_e, instanceId) => contentService.listContent(instanceId));
    // 游戏运行中会在退出/改设置时重写 options.txt 与 iris.properties：
    // 此时从启动器切换开关会被静默覆盖，直接拒绝并提示更可靠
    electron_1.ipcMain.handle('content:toggleResourcePack', (_e, instanceId, fileName) => {
        assertInstanceIdle(instanceId, '切换资源包');
        return contentService.toggleResourcePack(instanceId, fileName);
    });
    electron_1.ipcMain.handle('content:toggleShaderPack', (_e, instanceId, fileName) => {
        assertInstanceIdle(instanceId, '切换光影包');
        return contentService.toggleShaderPack(instanceId, fileName);
    });
    electron_1.ipcMain.handle('content:delete', (_e, instanceId, kind, fileName) => {
        // 运行中删除世界会删到游戏正在写入的区块文件，先拒绝
        if (kind === 'worlds')
            assertInstanceIdle(instanceId, '删除世界');
        return contentService.deleteContent(instanceId, kind, fileName);
    });
    electron_1.ipcMain.handle('content:backupWorld', (_e, instanceId, worldName, displayName) => {
        assertInstanceIdle(instanceId, '备份世界');
        return contentService.backupWorld(instanceId, worldName, displayName);
    });
    electron_1.ipcMain.handle('content:openItem', (_e, p) => {
        const root = path.resolve(paths.dataRoot());
        const target = path.resolve(p);
        if (target !== root && !target.startsWith(root + path.sep))
            throw new Error('只能打开 MCL 数据目录内的文件');
        return electron_1.shell.openPath(target);
    });
    electron_1.ipcMain.handle('content:openFolder', (_e, instanceId, kind) => {
        const instance = instances.getInstance(instanceId);
        if (!instance)
            throw new Error('实例不存在');
        const dirs = {
            resourcepacks: 'resourcepacks',
            shaderpacks: 'shaderpacks',
            screenshots: 'screenshots',
            worlds: 'saves',
        };
        const sub = dirs[String(kind)];
        if (!sub)
            throw new Error('未知的内容类型');
        return electron_1.shell.openPath(path.join(instance.gameDir, sub));
    });
    electron_1.ipcMain.handle('content:importDialog', async (_e, instanceId, kind, mode) => {
        const win = electron_1.BrowserWindow.getFocusedWindow();
        if (!win)
            throw new Error('窗口不可用');
        const isWorld = kind === 'worlds';
        // 运行中导入世界可能与游戏正在写入的同名世界冲突，先拒绝
        if (isWorld)
            assertInstanceIdle(instanceId, '导入世界');
        // 世界默认选文件夹；传 'file' 则选世界 ZIP
        const wantFolder = mode === 'folder' || (isWorld && mode !== 'file');
        if (wantFolder) {
            const result = await electron_1.dialog.showOpenDialog(win, {
                properties: ['openDirectory', 'multiSelections'],
                title: isWorld ? '选择要导入的世界文件夹' : '选择要导入的文件夹',
            });
            if (result.canceled || result.filePaths.length === 0)
                return null;
            return contentService.importContent(instanceId, kind, result.filePaths);
        }
        const filters = kind === 'screenshots'
            ? [{ name: '图片', extensions: ['png', 'jpg', 'jpeg'] }]
            : isWorld
                ? [{ name: '世界存档 ZIP', extensions: ['zip'] }]
                : [{ name: kind === 'shaderpacks' ? '光影包 ZIP' : '资源包 ZIP', extensions: ['zip'] }];
        const result = await electron_1.dialog.showOpenDialog(win, {
            properties: ['openFile', 'multiSelections'],
            title: kind === 'screenshots' ? '选择要导入的截图' : isWorld ? '选择要导入的世界 ZIP' : '选择要导入的 ZIP',
            filters,
        });
        if (result.canceled || result.filePaths.length === 0)
            return null;
        return contentService.importContent(instanceId, kind, result.filePaths);
    });
    // 拖放导入：路径来自系统文件拖放，复用与对话框完全相同的校验与导入逻辑
    electron_1.ipcMain.handle('content:importPaths', (_e, instanceId, kind, paths) => {
        if (kind === 'worlds')
            assertInstanceIdle(instanceId, '导入世界');
        return contentService.importContent(instanceId, kind, Array.isArray(paths) ? paths.filter(p => typeof p === 'string') : []);
    });
    electron_1.ipcMain.handle('content:exportWorld', async (_e, instanceId, worldName) => {
        assertInstanceIdle(instanceId, '导出世界');
        const win = electron_1.BrowserWindow.getFocusedWindow();
        if (!win)
            throw new Error('窗口不可用');
        const safe = String(worldName).replace(/[<>:"/\\|?*]/g, '_');
        const result = await electron_1.dialog.showSaveDialog(win, {
            title: '导出世界为 ZIP',
            defaultPath: path.join(electron_1.app.getPath('downloads'), `${safe}.zip`),
            filters: [{ name: '世界存档 ZIP', extensions: ['zip'] }],
        });
        if (result.canceled || !result.filePath)
            return null;
        return contentService.exportWorldZip(instanceId, worldName, result.filePath);
    });
    /* ---------- 实例导出 ---------- */
    electron_1.ipcMain.handle('export:instance', async (_e, instanceId, format) => {
        const instance = instances.getInstance(instanceId);
        if (!instance)
            throw new Error('实例不存在');
        if (!['mmc', 'mrpack', 'zip'].includes(String(format)))
            throw new Error('未知的导出格式');
        // 运行中的存档/日志仍在写入，导出包会带上半写入文件
        assertInstanceIdle(instanceId, '导出实例');
        const defaultName = exporter.defaultExportName(instance, format);
        const win = electron_1.BrowserWindow.getFocusedWindow();
        const result = await electron_1.dialog.showSaveDialog(win, {
            title: '导出实例',
            defaultPath: path.join(electron_1.app.getPath('downloads'), defaultName),
            filters: [{
                    name: format === 'mrpack' ? 'Modrinth 整合包' : 'ZIP 压缩包',
                    extensions: [format === 'mrpack' ? 'mrpack' : 'zip'],
                }],
        });
        if (result.canceled || !result.filePath)
            return null;
        return exporter.exportInstance(instanceId, format, result.filePath);
    });
    /* ---------- 启动器更新 ---------- */
    electron_1.ipcMain.handle('app:updateCheck', () => updateService.checkUpdate());
    electron_1.ipcMain.handle('app:updateDownload', async () => {
        const taskId = tasks_1.downloadTasks.begin('update', '下载启动器更新');
        try {
            const result = await updateService.downloadUpdate((done, total) => {
                tasks_1.downloadTasks.progress(taskId, done, total);
                sendToAll('app:updateProgress', { done, total });
            });
            tasks_1.downloadTasks.done(taskId, { revealFile: result.filePath, retry: { type: 'update' } });
            return result;
        }
        catch (e) {
            tasks_1.downloadTasks.fail(taskId, (0, net_1.errorReason)(e), { retry: { type: 'update' } });
            throw e;
        }
    });
    electron_1.ipcMain.handle('app:revealFile', (_e, filePath) => {
        if (typeof filePath !== 'string' || !filePath)
            return false;
        electron_1.shell.showItemInFolder(path.resolve(filePath));
        return true;
    });
    /* ---------- 局域网世界 ---------- */
    electron_1.ipcMain.handle('lan:scan', (_e, timeoutMs) => lanService.scanLanWorlds(timeoutMs));
    /* ---------- 缓存清理 ---------- */
    const measureDir = (dir) => {
        let sizeBytes = 0;
        let files = 0;
        const walk = (d) => {
            let entries = [];
            try {
                entries = fs.readdirSync(d, { withFileTypes: true });
            }
            catch {
                return;
            }
            for (const e of entries) {
                const full = path.join(d, e.name);
                if (e.isDirectory())
                    walk(full);
                else {
                    try {
                        sizeBytes += fs.statSync(full).size;
                        files++;
                    }
                    catch { /* ignore */ }
                }
            }
        };
        walk(dir);
        return { sizeBytes, files };
    };
    electron_1.ipcMain.handle('app:cacheInfo', () => ({ dir: paths.cacheDir(), ...measureDir(paths.cacheDir()) }));
    electron_1.ipcMain.handle('app:clearCache', () => {
        // 正在下载时缓存里有 .part 分段，直接清掉会让本次启动/安装失败或从头再来
        if (['preparing', 'downloading', 'launching'].includes(minecraft.launchState.status)) {
            throw new Error('游戏正在下载/准备，清理缓存会打断本次启动。请等启动完成后再试。');
        }
        if (serverService.listServers().some(s => s.status === 'preparing')) {
            throw new Error('有服务器正在安装，清理缓存会打断安装。请等安装完成后再试。');
        }
        const dir = paths.cacheDir();
        const before = measureDir(dir);
        if (fs.existsSync(dir)) {
            for (const name of fs.readdirSync(dir)) {
                fs.rmSync(path.join(dir, name), { recursive: true, force: true });
            }
        }
        return { freedBytes: before.sizeBytes, removedFiles: before.files };
    });
    /* ---------- 下载源测速 ---------- */
    electron_1.ipcMain.handle('mirror:test', async () => {
        const { pickBestSource } = await Promise.resolve().then(() => __importStar(require('./net')));
        return pickBestSource((0, settings_1.getSettings)().download.customMirror);
    });
    /* ---------- 下载任务中心 ---------- */
    electron_1.ipcMain.handle('tasks:list', () => tasks_1.downloadTasks.list());
    electron_1.ipcMain.handle('tasks:clearFinished', () => { tasks_1.downloadTasks.clearFinished(); return true; });
    electron_1.ipcMain.handle('tasks:remove', (_e, id) => { tasks_1.downloadTasks.remove(String(id ?? '')); return true; });
    electron_1.ipcMain.handle('tasks:cancel', (_e, id) => { tasks_1.downloadTasks.cancel(String(id ?? '')); return true; });
    /* ---------- 游玩统计 ---------- */
    electron_1.ipcMain.handle('stats:play', () => instances.getPlayStats());
    /* ---------- 游戏设置可视化（options.txt 白名单） ---------- */
    electron_1.ipcMain.handle('content:optionsRead', (_e, instanceId) => contentService.readGameOptions(instanceId));
    electron_1.ipcMain.handle('content:optionsSave', (_e, instanceId, patch) => {
        // 运行时游戏会重写 options.txt：此时保存会被静默覆盖，直接拒绝更可靠
        assertInstanceIdle(instanceId, '修改游戏设置');
        return contentService.saveGameOptions(instanceId, patch);
    });
}
