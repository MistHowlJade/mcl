"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.GAME_SUBDIRS = exports.electronCrashDir = exports.electronLogsDir = exports.electronCacheDir = exports.electronUserDataDir = void 0;
exports.dataRoot = dataRoot;
exports.sharedDir = sharedDir;
exports.assetsDir = assetsDir;
exports.assetsObjectsDir = assetsObjectsDir;
exports.assetsIndexDir = assetsIndexDir;
exports.librariesDir = librariesDir;
exports.versionsDir = versionsDir;
exports.instancesDir = instancesDir;
exports.instanceDir = instanceDir;
exports.gameDir = gameDir;
exports.nativesRoot = nativesRoot;
exports.javaDir = javaDir;
exports.cacheDir = cacheDir;
exports.backupsDir = backupsDir;
exports.instanceBackupsDir = instanceBackupsDir;
exports.logsDir = logsDir;
exports.serversDir = serversDir;
exports.serverDir = serverDir;
exports.serverFile = serverFile;
exports.serverBackupsDir = serverBackupsDir;
exports.redirectElectronPaths = redirectElectronPaths;
exports.configFile = configFile;
exports.accountsFile = accountsFile;
exports.instancesIndexFile = instancesIndexFile;
exports.residualPidsFile = residualPidsFile;
exports.tasksFile = tasksFile;
exports.playLogFile = playLogFile;
exports.installedModsFile = installedModsFile;
exports.instanceFile = instanceFile;
exports.ensureLayout = ensureLayout;
/**
 * MCL 数据目录布局（PCL2 / HMCL 式：数据默认跟着启动器走）
 *
 * 打包态默认：<启动器目录>/mcl-data（免安装 ZIP 解压后可写，拷走整个文件夹即带走全部游戏资源）
 * 兼容：exe 同级仍有 portable.txt 时同样使用 <该目录>/mcl-data
 * 回退：若启动器目录不可写（如装在 Program Files），退回 %APPDATA%/mcl
 * 开发模式：项目根目录/.mcl-data
 * 环境变量 MCL_HOME 优先级最高（用于隔离测试）
 *
 * 布局：
 *   <root>/shared/assets/objects/<hash2>/<hash>
 *   <root>/shared/libraries/<maven path>          ← 全实例共享，根治多实例磁盘膨胀（痛点 #48）
 *   <root>/shared/versions/<id>/<id>.json|jar     ← 全实例共享
 *   <root>/instances/<id>/game/                   ← 每个实例独立的 .minecraft（版本隔离，痛点 #43）
 *   <root>/instances/<id>/instance.json
 *   <root>/java/<major>/                          ← MCL 自动下载的 JRE
 *   <root>/cache/                                 ← 下载临时文件（.part）
 *   <root>/backups/<instanceId>/<name>.zip
 *   <root>/logs/mcl.log
 *   <root>/electron-user-data/          ← Electron 自身的 userData（Local Storage / Preferences…）
 *   <root>/electron-cache/              ← Electron / Chromium 缓存（Code Cache / GPUCache…）
 *   <root>/electron-logs/               ← Electron 日志
 *   <root>/electron-crash-dumps/        ← Electron 崩溃转储
 *
 * 所有 MCL 相关目录（游戏资源 + Electron 自身缓存）都在同一个 mcl-data 文件夹里，
 * 拷走该文件夹即带走全部数据，不在 %APPDATA% 留下散落目录。
 */
const electron_1 = require("electron");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
let cachedRoot = null;
/** 能否在该目录创建数据目录（用于决定是否真的可以“跟着本体走”） */
function canWriteDataDir(dir) {
    try {
        fs.mkdirSync(dir, { recursive: true });
        const probe = path.join(dir, `.mcl-write-${process.pid}`);
        fs.writeFileSync(probe, '');
        fs.unlinkSync(probe);
        return true;
    }
    catch {
        return false;
    }
}
/** 启动器所在目录；macOS 的可执行体在 Electron.app 内部，数据放 .app 旁边 */
function launcherDir() {
    const exeDir = path.dirname(process.execPath);
    return process.platform === 'darwin' ? path.resolve(exeDir, '..', '..', '..') : exeDir;
}
function dataRoot() {
    if (cachedRoot)
        return cachedRoot;
    const override = process.env.MCL_HOME;
    if (override) {
        cachedRoot = override;
        return cachedRoot;
    }
    if (electron_1.app.isPackaged) {
        const exeDir = path.dirname(process.execPath);
        const appDir = launcherDir();
        // 兼容旧的 portable.txt 约定：有标记时以标记所在目录为准
        const portableDirs = appDir === exeDir ? [exeDir] : [exeDir, appDir];
        const portableDir = portableDirs.find(d => fs.existsSync(path.join(d, 'portable.txt')));
        if (portableDir) {
            const root = path.join(portableDir, 'mcl-data');
            if (canWriteDataDir(root)) {
                cachedRoot = root;
                return cachedRoot;
            }
        }
        // PCL2 / HMCL 式：默认就在启动器旁边建 mcl-data，所有游戏资源跟着本体走
        const beside = path.join(appDir, 'mcl-data');
        if (canWriteDataDir(beside)) {
            cachedRoot = beside;
            return cachedRoot;
        }
        // 启动器装在只读目录（如 Program Files）才退回用户目录
        cachedRoot = electron_1.app.getPath('userData');
        return cachedRoot;
    }
    // 开发环境：放在仓库根目录下，便于排查
    cachedRoot = path.resolve(process.cwd(), '.mcl-data');
    return cachedRoot;
}
function sharedDir() { return path.join(dataRoot(), 'shared'); }
function assetsDir() { return path.join(sharedDir(), 'assets'); }
function assetsObjectsDir() { return path.join(assetsDir(), 'objects'); }
function assetsIndexDir() { return path.join(assetsDir(), 'indexes'); }
function librariesDir() { return path.join(sharedDir(), 'libraries'); }
function versionsDir() { return path.join(sharedDir(), 'versions'); }
function instancesDir() { return path.join(dataRoot(), 'instances'); }
function instanceDir(id) { return path.join(instancesDir(), id); }
function gameDir(id) { return path.join(instanceDir(id), 'game'); }
function nativesRoot(id) { return path.join(instanceDir(id), 'natives'); }
function javaDir() { return path.join(dataRoot(), 'java'); }
function cacheDir() { return path.join(dataRoot(), 'cache'); }
function backupsDir() { return path.join(dataRoot(), 'backups'); }
function instanceBackupsDir(id) { return path.join(backupsDir(), id); }
function logsDir() { return path.join(dataRoot(), 'logs'); }
function serversDir() { return path.join(dataRoot(), 'servers'); }
function serverDir(id) { return path.join(serversDir(), id); }
function serverFile(id) { return path.join(serverDir(id), 'server.json'); }
function serverBackupsDir(id) { return path.join(serverDir(id), 'backups'); }
/** Electron 自身的数据/缓存也放进同一个根目录（在主进程 ready 之前调用） */
const electronUserDataDir = () => path.join(dataRoot(), 'electron-user-data');
exports.electronUserDataDir = electronUserDataDir;
const electronCacheDir = () => path.join(dataRoot(), 'electron-cache');
exports.electronCacheDir = electronCacheDir;
const electronLogsDir = () => path.join(dataRoot(), 'electron-logs');
exports.electronLogsDir = electronLogsDir;
const electronCrashDir = () => path.join(dataRoot(), 'electron-crash-dumps');
exports.electronCrashDir = electronCrashDir;
function redirectElectronPaths() {
    const dirs = [(0, exports.electronUserDataDir)(), (0, exports.electronCacheDir)(), (0, exports.electronLogsDir)(), (0, exports.electronCrashDir)()];
    for (const dir of dirs)
        fs.mkdirSync(dir, { recursive: true });
    // setPath 必须在 app.whenReady() 之前，否则 Chromium 已经创建的缓存不会迁移
    electron_1.app.setPath('userData', dirs[0]);
    electron_1.app.setPath('cache', dirs[1]);
    electron_1.app.setPath('logs', dirs[2]);
    electron_1.app.setPath('crashDumps', dirs[3]);
}
function configFile() { return path.join(dataRoot(), 'config.json'); }
function accountsFile() { return path.join(dataRoot(), 'accounts.json'); }
function instancesIndexFile() { return path.join(dataRoot(), 'instances.json'); }
function residualPidsFile() { return path.join(dataRoot(), 'residual-pids.json'); }
/** 下载任务中心的最近任务记录（只保留元数据，不含游戏本体） */
function tasksFile() { return path.join(dataRoot(), 'tasks.json'); }
/** 游玩统计日志：按日期累计秒数与启动次数 */
function playLogFile() { return path.join(dataRoot(), 'playlog.json'); }
function installedModsFile(id) { return path.join(instanceDir(id), 'installed-mods.json'); }
function instanceFile(id) { return path.join(instanceDir(id), 'instance.json'); }
function ensureLayout() {
    for (const dir of [
        dataRoot(), sharedDir(), assetsDir(), assetsObjectsDir(), assetsIndexDir(),
        librariesDir(), versionsDir(), instancesDir(), javaDir(), cacheDir(),
        backupsDir(), logsDir(), serversDir(),
        (0, exports.electronUserDataDir)(), (0, exports.electronCacheDir)(), (0, exports.electronLogsDir)(), (0, exports.electronCrashDir)(),
    ]) {
        fs.mkdirSync(dir, { recursive: true });
    }
}
/** 游戏实例内部的标准子目录 */
exports.GAME_SUBDIRS = [
    'saves', 'mods', 'config', 'resourcepacks', 'shaderpacks',
    'screenshots', 'logs', 'crash-reports', 'data',
];
