"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
exports.serverEvents = void 0;
exports.listServers = listServers;
exports.getServer = getServer;
exports.createServer = createServer;
exports.updateServer = updateServer;
exports.deleteServer = deleteServer;
exports.readServerProperties = readServerProperties;
exports.saveServerProperties = saveServerProperties;
exports.prepareServer = prepareServer;
exports.acceptEula = acceptEula;
exports.isPortAvailable = isPortAvailable;
exports.killAllServersSync = killAllServersSync;
exports.startServer = startServer;
exports.stopServer = stopServer;
exports.killServer = killServer;
exports.sendCommand = sendCommand;
exports.listServerBackups = listServerBackups;
exports.backupServerWorld = backupServerWorld;
exports.restoreServerWorld = restoreServerWorld;
exports.deleteServerBackup = deleteServerBackup;
exports.readServerLog = readServerLog;
/**
 * Minecraft 服务端管理：创建、安装、启停、控制台、server.properties、世界备份
 *
 * 设计：
 * - 每个服务器独立目录 <root>/servers/<id>/，互不影响
 * - 原版 / Fabric / Quilt / Forge / NeoForge 五种服务端
 * - 零第三方依赖：安装器调用官方 Java 安装器，进程用 child_process 管理
 * - 启动前自动准备 Java（复用 java.ts 的版本匹配与 Adoptium 下载）
 */
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const net = __importStar(require("net"));
const crypto = __importStar(require("crypto"));
const child_process_1 = require("child_process");
const events_1 = require("events");
const paths = __importStar(require("./paths"));
const store_1 = require("./store");
const settings_1 = require("./settings");
const proxy_1 = require("./proxy");
const javaService = __importStar(require("./java"));
const versionService = __importStar(require("./version"));
const downloader_1 = require("./downloader");
const net_1 = require("./net");
const zip_1 = require("./zip");
exports.serverEvents = new events_1.EventEmitter();
const runtimes = new Map();
// server:status 事件在玩家进出/状态变化时频繁触发，每次都遍历整个世界目录会卡住主进程
const diskBytesCache = new Map();
const DISK_CACHE_MS = 60_000;
function serverDiskBytes(id) {
    const hit = diskBytesCache.get(id);
    const now = Date.now();
    if (hit && now - hit.at < DISK_CACHE_MS)
        return hit.bytes;
    const bytes = walkBytes(paths.serverDir(id));
    diskBytesCache.set(id, { at: now, bytes });
    return bytes;
}
function invalidateDiskBytes(id) {
    diskBytesCache.delete(id);
}
const runtimeOf = (id) => {
    let rt = runtimes.get(id);
    if (!rt) {
        rt = { child: null, status: 'stopped', startedAt: null, players: new Set(), logTail: [], stopping: false };
        runtimes.set(id, rt);
    }
    return rt;
};
const newId = () => crypto.randomBytes(8).toString('hex');
/** server.json 可能被手工改坏/半写入：字段不完整时跳过，避免服务器列表或启动流程崩掉 */
function isServerConfig(value) {
    if (!value || typeof value !== 'object')
        return false;
    const cfg = value;
    return typeof cfg.id === 'string' && /^[a-f0-9]{16}$/.test(cfg.id)
        && typeof cfg.name === 'string'
        && typeof cfg.mcVersion === 'string'
        && ['vanilla', 'fabric', 'quilt', 'forge', 'neoforge'].includes(String(cfg.loader))
        && Number.isInteger(cfg.port) && cfg.port >= 1 && cfg.port <= 65535
        && typeof cfg.createdAt === 'number';
}
/** 加载器版本只允许普通版本号字符：不能以 - 开头，避免被拼进 URL/安装器参数 */
const isLoaderVersion = (v) => typeof v === 'string'
    && /^[0-9A-Za-z][0-9A-Za-z._+\-]{0,63}$/.test(v);
function walkBytes(dir) {
    let total = 0;
    const walk = (d) => {
        let entries = [];
        try {
            entries = fs.readdirSync(d, { withFileTypes: true });
        }
        catch {
            return;
        }
        for (const e of entries) {
            const full = path.join(d, e.name);
            if (e.isDirectory())
                walk(full);
            else {
                try {
                    total += fs.statSync(full).size;
                }
                catch { /* ignore */ }
            }
        }
    };
    walk(dir);
    return total;
}
function tailFile(file, maxLines = 200) {
    try {
        if (!fs.existsSync(file))
            return [];
        const stat = fs.statSync(file);
        const start = Math.max(0, stat.size - 256 * 1024);
        const buf = Buffer.alloc(stat.size - start);
        const fd = fs.openSync(file, 'r');
        fs.readSync(fd, buf, 0, buf.length, start);
        fs.closeSync(fd);
        return buf.toString('utf8').split(/\r?\n/).filter(Boolean).slice(-maxLines);
    }
    catch {
        return [];
    }
}
/* ============================== 基础 CRUD ============================== */
function listServers() {
    const root = paths.serversDir();
    if (!fs.existsSync(root))
        return [];
    const out = [];
    for (const entry of fs.readdirSync(root, { withFileTypes: true })) {
        if (!entry.isDirectory())
            continue;
        const cfg = (0, store_1.readJson)(paths.serverFile(entry.name), null);
        // 目录名与配置里的 id 必须一致，否则会得到一个指向错误目录的“幽灵服务器”
        if (isServerConfig(cfg) && cfg.id === entry.name)
            out.push(toInfo(cfg));
    }
    return out.sort((a, b) => b.createdAt - a.createdAt);
}
function getServer(id) {
    if (!/^[a-f0-9]{16}$/.test(String(id ?? '')))
        return null;
    const cfg = (0, store_1.readJson)(paths.serverFile(id), null);
    return isServerConfig(cfg) && cfg.id === id ? toInfo(cfg) : null;
}
function readConfig(id) {
    if (!/^[a-f0-9]{16}$/.test(String(id ?? '')))
        throw new Error('服务器不存在');
    const cfg = (0, store_1.readJson)(paths.serverFile(id), null);
    if (!isServerConfig(cfg) || cfg.id !== id)
        throw new Error('服务器不存在');
    // 校验只覆盖关键字段：其余字段可能被手工改坏，启动前统一兜底，避免拼出 NaN 的 JVM 参数
    const memoryMB = Number.isFinite(cfg.memoryMB) ? Math.max(512, Math.min(32768, Math.round(cfg.memoryMB))) : 2048;
    return {
        ...cfg,
        memoryMB,
        loaderVersion: typeof cfg.loaderVersion === 'string' && isLoaderVersion(cfg.loaderVersion.trim()) ? cfg.loaderVersion.trim() : null,
        javaPath: typeof cfg.javaPath === 'string' ? cfg.javaPath : null,
        jvmArgsExtra: typeof cfg.jvmArgsExtra === 'string' ? cfg.jvmArgsExtra : '',
        prepared: cfg.prepared === true,
        eulaAccepted: cfg.eulaAccepted === true,
    };
}
function toInfo(cfg) {
    const rt = runtimeOf(cfg.id);
    const logFile = path.join(paths.serverDir(cfg.id), 'logs', 'latest.log');
    const logTail = rt.logTail.length > 0 ? rt.logTail.slice(-200) : tailFile(logFile);
    const memoryMB = Number.isFinite(cfg.memoryMB) ? Math.max(512, Math.min(32768, Math.round(cfg.memoryMB))) : 2048;
    // loaderVersion 可能被手工改坏：非法值不进 UI，也不进下载 URL/安装器参数
    const loaderVersion = typeof cfg.loaderVersion === 'string' && isLoaderVersion(cfg.loaderVersion.trim()) ? cfg.loaderVersion.trim() : null;
    return {
        ...cfg,
        loaderVersion,
        memoryMB,
        dir: paths.serverDir(cfg.id),
        status: rt.status,
        pid: rt.child?.pid ?? null,
        startedAt: rt.startedAt,
        players: [...rt.players],
        online: rt.status === 'running',
        diskBytes: serverDiskBytes(cfg.id),
        logTail,
    };
}
const SERVER_LOADERS = ['vanilla', 'fabric', 'quilt', 'forge', 'neoforge'];
const isServerLoader = (v) => SERVER_LOADERS.includes(v);
/** 版本号会进入 URL/目录名：拒绝 . / .. 与路径分隔符 */
const isMcVersion = (v) => typeof v === 'string'
    && v.length > 0 && v.length <= 128
    && /^[0-9A-Za-z_\-[\]]+(\.[0-9A-Za-z_\-[\]]+)*$/.test(v);
function createServer(input) {
    if (!input || typeof input !== 'object')
        throw new Error('创建服务器的参数不完整');
    if (!isMcVersion(input.mcVersion))
        throw new Error('Minecraft 版本号格式不正确');
    if (!isServerLoader(input.loader))
        throw new Error('不支持的服务器类型');
    const port = input.port ?? 25565;
    if (!Number.isInteger(port) || port < 1 || port > 65535)
        throw new Error('端口必须是 1–65535 之间的整数');
    const memoryMB = Number.isFinite(input.memoryMB) ? Math.max(512, Math.min(32768, Math.round(input.memoryMB))) : 2048;
    const id = newId();
    const name = typeof input.name === 'string' ? input.name.trim().slice(0, 80) : '';
    const loaderVersion = typeof input.loaderVersion === 'string' ? input.loaderVersion.trim() : '';
    if (loaderVersion && !isLoaderVersion(loaderVersion)) {
        throw new Error('加载器版本号格式不正确（只能包含字母、数字、点、下划线、加号和短横线）');
    }
    const cfg = {
        id,
        name: name || `${input.mcVersion} 服务器`,
        mcVersion: input.mcVersion,
        loader: input.loader,
        loaderVersion: loaderVersion || null,
        port,
        memoryMB,
        javaPath: typeof input.javaPath === 'string' && input.javaPath.trim() ? input.javaPath.trim() : null,
        jvmArgsExtra: '',
        eulaAccepted: false,
        prepared: false,
        createdAt: Date.now(),
        lastStartedAt: null,
    };
    fs.mkdirSync(paths.serverDir(id), { recursive: true });
    (0, store_1.writeJson)(paths.serverFile(id), cfg);
    writeDefaultProperties(id, port);
    return cfg;
}
function updateServer(id, patch) {
    const current = readConfig(id);
    const p = (patch && typeof patch === 'object' ? patch : {});
    const next = { ...current, id: current.id, createdAt: current.createdAt };
    if ('port' in p) {
        if (!Number.isInteger(p.port) || p.port < 1 || p.port > 65535)
            throw new Error('端口必须是 1–65535 之间的整数');
        next.port = p.port;
    }
    if ('memoryMB' in p) {
        next.memoryMB = Number.isFinite(p.memoryMB) ? Math.max(512, Math.min(32768, Math.round(p.memoryMB))) : current.memoryMB;
    }
    // 名称不能被清空：空名字会让服务器列表和通知里出现空白项
    if ('name' in p) {
        const name = typeof p.name === 'string' ? p.name.trim() : '';
        next.name = name ? name.slice(0, 80) : current.name;
    }
    if (isMcVersion(p.mcVersion))
        next.mcVersion = p.mcVersion;
    if (isServerLoader(p.loader))
        next.loader = p.loader;
    if ('loaderVersion' in p) {
        const raw = typeof p.loaderVersion === 'string' ? p.loaderVersion.trim() : '';
        if (raw && !isLoaderVersion(raw)) {
            throw new Error('加载器版本号格式不正确（只能包含字母、数字、点、下划线、加号和短横线）');
        }
        next.loaderVersion = raw || null;
    }
    if ('javaPath' in p)
        next.javaPath = typeof p.javaPath === 'string' && p.javaPath.trim() ? p.javaPath.trim() : null;
    if (typeof p.jvmArgsExtra === 'string')
        next.jvmArgsExtra = p.jvmArgsExtra;
    if (typeof p.eulaAccepted === 'boolean')
        next.eulaAccepted = p.eulaAccepted;
    if (typeof p.prepared === 'boolean')
        next.prepared = p.prepared;
    if ('lastStartedAt' in p)
        next.lastStartedAt = typeof p.lastStartedAt === 'number' && Number.isFinite(p.lastStartedAt) ? p.lastStartedAt : null;
    (0, store_1.writeJson)(paths.serverFile(id), next);
    // 端口同时写进 server.properties，否则启动检查用新端口、服务端实际监听旧端口
    if (next.port !== current.port) {
        saveServerProperties(id, { 'server-port': String(next.port) });
    }
    exports.serverEvents.emit('status', toInfo(next));
    return next;
}
async function deleteServer(id, backup = true) {
    const cfg = readConfig(id);
    const rt = runtimeOf(id);
    // 安装器 Java 进程还在写服务器目录，此时删除会遇到文件占用并留下半成品
    if (rt.status === 'preparing')
        throw new Error('服务端正在安装，无法删除。请等安装完成后再试。');
    // 正在运行的服务端先正常 stop，让它把世界写盘；stopServer 超时会自动强制结束
    if (rt.child)
        await stopServer(id).catch(() => killServer(id).catch(() => undefined));
    const dir = paths.serverDir(id);
    if (!fs.existsSync(dir))
        return { ok: false };
    let backupPath;
    if (backup) {
        const destDir = path.join(paths.backupsDir(), 'deleted-servers');
        fs.mkdirSync(destDir, { recursive: true });
        backupPath = path.join(destDir, `${cfg.name.replace(/[^\w\u4e00-\u9fa5-]/g, '_')}-${id}-${Date.now()}.zip`);
        try {
            await (0, zip_1.zipDirToFile)(dir, backupPath);
        }
        catch {
            // 备份失败就取消删除：确认框承诺了“先备份再删除”，不能把用户的世界直接删掉
            try {
                fs.rmSync(backupPath, { force: true });
            }
            catch { /* ignore */ }
            throw new Error('删除前备份失败，已取消删除以免丢失数据。请检查磁盘空间，或关闭占用服务器文件的程序后重试。');
        }
    }
    runtimes.delete(id);
    diskBytesCache.delete(id);
    fs.rmSync(dir, { recursive: true, force: true });
    return { ok: true, backupPath };
}
/* ============================== server.properties ============================== */
const DEFAULT_PROPERTIES = {
    'server-port': '25565',
    'motd': 'MCL 服务器',
    'max-players': '20',
    'online-mode': 'true',
    'difficulty': 'easy',
    'gamemode': 'survival',
    'view-distance': '10',
    'simulation-distance': '10',
    'pvp': 'true',
    'white-list': 'false',
    'enforce-whitelist': 'false',
    'enable-command-block': 'false',
    'allow-flight': 'false',
    'spawn-protection': '16',
    'level-name': 'world',
    'level-seed': '',
    'enable-status': 'true',
    'enforce-secure-profile': 'true',
    'sync-chunk-writes': 'true',
    'allow-nether': 'true',
    'generate-structures': 'true',
    'spawn-monsters': 'true',
    'spawn-animals': 'true',
    'spawn-npcs': 'true',
    'function-permission-level': '2',
    'op-permission-level': '4',
    'player-idle-timeout': '0',
    'rate-limit': '0',
};
function writeDefaultProperties(id, port) {
    const file = path.join(paths.serverDir(id), 'server.properties');
    if (fs.existsSync(file))
        return;
    const lines = ['#Minecraft server properties', '#Generated by MCL'];
    const props = { ...DEFAULT_PROPERTIES, 'server-port': String(port) };
    for (const [k, v] of Object.entries(props))
        lines.push(`${k}=${v}`);
    fs.writeFileSync(file, `${lines.join('\n')}\n`, 'utf8');
}
function readServerProperties(id) {
    readConfig(id);
    const file = path.join(paths.serverDir(id), 'server.properties');
    const out = {};
    if (!fs.existsSync(file))
        return out;
    for (const line of fs.readFileSync(file, 'utf8').split(/\r?\n/)) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#'))
            continue;
        const eq = trimmed.indexOf('=');
        if (eq <= 0)
            continue;
        out[trimmed.slice(0, eq).trim()] = trimmed.slice(eq + 1).trim();
    }
    return out;
}
/** 更新 server.properties：保留注释与未知键，只改传入的键 */
function saveServerProperties(id, patch) {
    readConfig(id);
    const file = path.join(paths.serverDir(id), 'server.properties');
    const lines = fs.existsSync(file) ? fs.readFileSync(file, 'utf8').split(/\r?\n/) : [];
    // 值里出现换行会额外写进一行属性（甚至覆盖别的键），写盘前统一去掉
    const clean = (value) => String(value ?? '').replace(/[\r\n]+/g, ' ');
    const remaining = new Map(Object.entries(patch).map(([k, v]) => [clean(k), clean(v)]));
    const replaced = new Set();
    const out = [];
    for (const line of lines) {
        const trimmed = line.trim();
        if (!trimmed || trimmed.startsWith('#') || !trimmed.includes('=')) {
            out.push(line);
            continue;
        }
        const key = trimmed.slice(0, trimmed.indexOf('=')).trim();
        if (!remaining.has(key)) {
            out.push(line);
            continue;
        }
        // readServerProperties 以最后一行为准：重复键必须全部处理，否则改了端口实际仍监听旧值
        if (!replaced.has(key)) {
            out.push(`${key}=${remaining.get(key)}`);
            replaced.add(key);
        }
        // 后续同 key 行直接丢弃，避免残留旧值重新生效
    }
    for (const [k, v] of remaining)
        if (!replaced.has(k))
            out.push(`${k}=${v}`);
    fs.writeFileSync(file, `${out.filter((l, i) => l !== '' || i < out.length - 1).join('\n')}\n`, 'utf8');
    return readServerProperties(id);
}
/* ============================== Java / 下载 ============================== */
async function resolveJava(cfg) {
    const settings = (0, settings_1.getSettings)();
    const wanted = cfg.javaPath ?? settings.java.defaultPath ?? null;
    let pick = await javaService.pickJavaFor(cfg.mcVersion, wanted);
    if (!pick.java) {
        const exe = await javaService.installJava(pick.recommendedMajor);
        pick = await javaService.pickJavaFor(cfg.mcVersion, exe);
    }
    if (!pick.java)
        throw new Error(`无法准备 Java ${pick.recommendedMajor}（自动下载失败），请检查网络或在设置中手动指定 Java。`);
    return pick.java.path;
}
async function mavenVersions(url) {
    const res = await (0, net_1.fetchWithTimeout)(url, { timeoutMs: 20000 });
    if (res.status >= 400)
        throw new Error(`Maven 元数据不可用（HTTP ${res.status}）`);
    return Array.from(res.body.toString('utf8').matchAll(/<version>([^<]+)<\/version>/g)).map(m => m[1].trim());
}
async function downloadFile(url, dest, name, sha1) {
    const settings = (0, settings_1.getSettings)();
    fs.mkdirSync(path.dirname(dest), { recursive: true });
    const dl = new downloader_1.DownloadManager({
        source: settings.download.source,
        customMirror: settings.download.customMirror,
        maxThreads: 1,
        retries: settings.download.retries,
        timeoutMs: settings.download.timeoutMs,
    });
    const reports = await dl.run([{ id: `server:${name}:${dest}`, url, dest, sha1, name }]);
    if (!reports[0]?.ok)
        throw new Error(`${name} 下载失败：${reports[0]?.error ?? '未知错误'}\nURL：${url}`);
}
async function latestFabricLoader(mcVersion) {
    const list = await (0, net_1.fetchJson)(`https://meta.fabricmc.net/v2/versions/loader/${mcVersion}`, { timeoutMs: 20000 });
    if (!list?.length)
        throw new Error(`Fabric 不支持 Minecraft ${mcVersion}`);
    return list[0].loader.version;
}
async function latestQuiltLoader(mcVersion) {
    const list = await (0, net_1.fetchJson)(`https://meta.quiltmc.org/v3/versions/loader/${mcVersion}`, { timeoutMs: 20000 });
    if (!list?.length)
        throw new Error(`Quilt 不支持 Minecraft ${mcVersion}`);
    return list[0].loader.version;
}
function neoForgePrefix(mcVersion) {
    // NeoForge 1.20.1 沿用 Forge 的 47.x 版本号，其余版本从 MC 版本推导（1.21 → 21.0.，1.21.4 → 21.4.）
    if (mcVersion === '1.20.1')
        return '47.';
    const parts = mcVersion.replace(/^1\./, '').split('.');
    // 1.21 在 NeoForge 里是 21.0.x：只写 "21." 会匹配到 21.1/21.2 等其它 MC 版本
    if (parts.length < 2)
        return `${parts[0] || '0'}.0.`;
    return `${parts[0]}.${parts[1]}.`;
}
function findInstalledJar(dir, loader) {
    // Quilt 必须用自己的 launch jar：若先找到遗留的 server.jar（原版），会把 Quilt 服务器当原版启动
    const candidates = loader === 'quilt'
        ? ['quilt-server-launch.jar', 'fabric-server-launch.jar']
        : ['server.jar', 'fabric-server-launch.jar'];
    for (const candidate of candidates) {
        const p = path.join(dir, candidate);
        if (fs.existsSync(p))
            return p;
    }
    return null;
}
function findForgeArgs(dir, loader, expectedVersion) {
    const base = path.join(dir, 'libraries', 'net', loader === 'forge' ? 'minecraftforge' : 'neoforged');
    if (!fs.existsSync(base))
        return null;
    const wanted = process.platform === 'win32' ? 'win_args.txt' : 'unix_args.txt';
    const stack = [base];
    const found = [];
    while (stack.length) {
        const current = stack.pop();
        let entries = [];
        try {
            entries = fs.readdirSync(current, { withFileTypes: true });
        }
        catch {
            continue;
        }
        for (const e of entries) {
            const full = path.join(current, e.name);
            if (e.isDirectory())
                stack.push(full);
            // 重装后旧版本的库仍在：指定版本时只认对应目录，避免启动到上一次安装的加载器
            else if (e.name === wanted && (!expectedVersion || full.split(path.sep).includes(expectedVersion)))
                found.push(full);
        }
    }
    if (found.length === 0)
        return null;
    // 重装后旧版本库仍在：取最近写入的参数文件，避免启动到上一次安装的版本
    try {
        return found.sort((a, b) => fs.statSync(b).mtimeMs - fs.statSync(a).mtimeMs)[0];
    }
    catch {
        return found[0];
    }
}
/**
 * 1.16 及更早的 Forge 安装器不生成 win_args.txt/unix_args.txt，
 * 而是在服务器根目录产出 forge-<mc>-<loader>[-universal].jar，需要 -jar 启动。
 */
function findForgeJar(dir, expectedVersion) {
    let entries = [];
    try {
        entries = fs.readdirSync(dir);
    }
    catch {
        return null;
    }
    const jars = entries.filter(f => {
        const lower = f.toLowerCase();
        if (!lower.endsWith('.jar') || !/^forge[-.]/i.test(f) || /installer|sources|mdk|javadoc/.test(lower))
            return false;
        return !expectedVersion || f.includes(expectedVersion);
    });
    if (jars.length === 0)
        return null;
    // 重装后旧版本 jar 可能还在：与参数文件一致，取最近写入的那个
    try {
        return path.join(dir, jars.sort((a, b) => fs.statSync(path.join(dir, b)).mtimeMs - fs.statSync(path.join(dir, a)).mtimeMs)[0]);
    }
    catch {
        return path.join(dir, jars[0]);
    }
}
/** 把用户手填的短版本号（如 36.2.34 / 47.1.3）规范成 Maven 目录名 */
function forgeDirName(loader, mcVersion, loaderVersion) {
    if (!loaderVersion)
        return null;
    // NeoForge 只有 1.20.1 沿用 Forge 的坐标，目录名带 1.20.1- 前缀
    if (loader === 'forge' || mcVersion === '1.20.1') {
        return loaderVersion.includes('-') ? loaderVersion : `${mcVersion}-${loaderVersion}`;
    }
    return loaderVersion;
}
function emitLog(id, line, source = 'server') {
    const rt = runtimeOf(id);
    const formatted = source === 'install' ? `[install] ${line}` : line;
    rt.logTail.push(formatted);
    if (rt.logTail.length > 800)
        rt.logTail.splice(0, rt.logTail.length - 800);
    exports.serverEvents.emit('log', { serverId: id, line: formatted });
}
function setStatus(id, status) {
    const cfg = (0, store_1.readJson)(paths.serverFile(id), null);
    if (!cfg)
        return;
    runtimeOf(id).status = status;
    exports.serverEvents.emit('status', toInfo(cfg));
}
/* ============================== 安装 / 准备 ============================== */
async function prepareServer(id) {
    const cfg = readConfig(id);
    const dir = paths.serverDir(id);
    fs.mkdirSync(dir, { recursive: true });
    const rt = runtimeOf(id);
    if (rt.status === 'preparing')
        throw new Error('服务端正在安装中，请稍候。');
    if (rt.status === 'running' || rt.status === 'starting' || rt.status === 'stopping')
        throw new Error('服务器正在运行，无法重新安装');
    setStatus(id, 'preparing');
    try {
        const javaPath = await resolveJava(cfg);
        if (cfg.eulaAccepted)
            writeEula(id);
        writeDefaultProperties(id, cfg.port);
        if (cfg.loader === 'vanilla') {
            const settings = (0, settings_1.getSettings)();
            const manifest = await versionService.getVersionManifest(settings.download.source, settings.download.customMirror);
            const entry = manifest.versions.find(v => v.id === cfg.mcVersion);
            if (!entry)
                throw new Error(`版本清单中找不到 ${cfg.mcVersion}`);
            const resolved = await versionService.resolveVersion(entry, settings.download.source, settings.download.customMirror);
            const server = resolved.downloads?.server;
            if (!server?.url)
                throw new Error(`Minecraft ${cfg.mcVersion} 没有可用的服务端下载（该版本可能不提供独立服务端）。`);
            emitLog(id, `正在下载原版服务端 ${cfg.mcVersion}…`, 'install');
            await downloadFile(server.url, path.join(dir, 'server.jar'), 'server.jar', server.sha1);
        }
        else if (cfg.loader === 'fabric') {
            const lv = cfg.loaderVersion || await latestFabricLoader(cfg.mcVersion);
            if (!cfg.loaderVersion)
                updateServer(id, { loaderVersion: lv });
            const url = `https://meta.fabricmc.net/v2/versions/loader/${cfg.mcVersion}/${lv}/server/jar`;
            emitLog(id, `正在下载 Fabric 服务端 ${cfg.mcVersion} / loader ${lv}…`, 'install');
            await downloadFile(url, path.join(dir, 'server.jar'), 'Fabric server.jar');
        }
        else if (cfg.loader === 'quilt') {
            const lv = cfg.loaderVersion || await latestQuiltLoader(cfg.mcVersion);
            if (!cfg.loaderVersion)
                updateServer(id, { loaderVersion: lv });
            const versions = await mavenVersions('https://maven.quiltmc.org/repository/release/org/quiltmc/quilt-installer/maven-metadata.xml');
            const installerVersion = versionService.newestVersion(versions);
            if (!installerVersion)
                throw new Error('无法确定 Quilt 安装器版本');
            const installerUrl = `https://maven.quiltmc.org/repository/release/org/quiltmc/quilt-installer/${installerVersion}/quilt-installer-${installerVersion}.jar`;
            const installerPath = path.join(dir, '.quilt-installer.jar');
            emitLog(id, `正在下载 Quilt 安装器 ${installerVersion}…`, 'install');
            await downloadFile(installerUrl, installerPath, 'Quilt 安装器');
            emitLog(id, '正在安装 Quilt 服务端（可能需要 1–3 分钟）…', 'install');
            try {
                await runInstaller(javaPath, ['-jar', installerPath, 'install', 'server', cfg.mcVersion, lv, `--install-dir=${dir}`, '--download-server'], dir, line => emitLog(id, line, 'install'));
            }
            finally {
                // 安装失败也清理安装包，避免服务器目录里残留几十 MB 的临时 jar
                fs.rmSync(installerPath, { force: true });
            }
            if (!findInstalledJar(dir, 'quilt'))
                throw new Error('Quilt 安装完成但找不到服务端启动 jar。');
        }
        else {
            const loader = cfg.loader;
            let forgeId = cfg.loaderVersion ?? '';
            let installerUrl;
            if (loader === 'forge') {
                if (!forgeId) {
                    const versions = await mavenVersions('https://maven.minecraftforge.net/net/minecraftforge/forge/maven-metadata.xml');
                    const matching = versions.filter(v => v.startsWith(`${cfg.mcVersion}-`));
                    if (!matching.length)
                        throw new Error(`找不到适用于 ${cfg.mcVersion} 的 Forge 版本，请手动指定加载器版本。`);
                    forgeId = versionService.newestVersion(matching);
                }
                const fullId = forgeId.includes('-') ? forgeId : `${cfg.mcVersion}-${forgeId}`;
                installerUrl = `https://maven.minecraftforge.net/net/minecraftforge/forge/${fullId}/forge-${fullId}-installer.jar`;
            }
            else {
                // NeoForge 1.20.1 沿用 Forge 47.x，发布坐标为 net.neoforged:forge，版本带 1.20.1- 前缀
                const neoForgeLegacy = cfg.mcVersion === '1.20.1';
                if (!forgeId) {
                    const metaUrl = neoForgeLegacy
                        ? 'https://maven.neoforged.net/releases/net/neoforged/forge/maven-metadata.xml'
                        : 'https://maven.neoforged.net/releases/net/neoforged/neoforge/maven-metadata.xml';
                    const versions = await mavenVersions(metaUrl);
                    // 1.20.1 的 NeoForge 版本形如 1.20.1-47.x，不能直接用 47. 前缀匹配
                    const prefix = neoForgeLegacy ? `${cfg.mcVersion}-47.` : neoForgePrefix(cfg.mcVersion);
                    const matching = versions.filter(v => v.startsWith(prefix));
                    if (!matching.length)
                        throw new Error(`找不到适用于 ${cfg.mcVersion} 的 NeoForge 版本，请手动指定加载器版本。`);
                    forgeId = versionService.newestVersion(matching);
                }
                if (neoForgeLegacy) {
                    forgeId = forgeId.startsWith(`${cfg.mcVersion}-`) ? forgeId : `${cfg.mcVersion}-${forgeId}`;
                    installerUrl = `https://maven.neoforged.net/releases/net/neoforged/forge/${forgeId}/forge-${forgeId}-installer.jar`;
                }
                else {
                    installerUrl = `https://maven.neoforged.net/releases/net/neoforged/neoforge/${forgeId}/neoforge-${forgeId}-installer.jar`;
                }
            }
            if (!cfg.loaderVersion)
                updateServer(id, { loaderVersion: forgeId });
            const installerPath = path.join(dir, `.${loader}-installer.jar`);
            emitLog(id, `正在下载 ${loader === 'forge' ? 'Forge' : 'NeoForge'} 安装器（${forgeId}）…`, 'install');
            await downloadFile(installerUrl, installerPath, `${loader} 安装器`);
            emitLog(id, '正在静默安装服务端（可能需要 1–5 分钟）…', 'install');
            try {
                await runInstaller(javaPath, [...(0, proxy_1.proxyJvmArgs)(), '-jar', installerPath, '--installServer', dir], dir, line => emitLog(id, line, 'install'));
            }
            finally {
                fs.rmSync(installerPath, { force: true });
            }
            // 1.16 及更早的 Forge 没有参数文件，安装器会直接产出可 -jar 启动的 Forge jar
            const expected = forgeDirName(loader, cfg.mcVersion, forgeId);
            const argsFile = findForgeArgs(dir, loader, expected);
            const legacyJar = loader === 'forge' && !argsFile ? findForgeJar(dir, expected) : null;
            if (!argsFile && !legacyJar)
                throw new Error(`${loader} 安装完成但找不到启动文件，请查看安装日志。`);
        }
        updateServer(id, { prepared: true, eulaAccepted: cfg.eulaAccepted });
        invalidateDiskBytes(id);
        emitLog(id, '服务端安装完成。', 'install');
        setStatus(id, 'stopped');
        return getServer(id);
    }
    catch (e) {
        setStatus(id, 'stopped');
        throw e;
    }
}
function runInstaller(javaPath, args, cwd, onLine) {
    return new Promise((resolve, reject) => {
        let settled = false;
        const finish = (err) => {
            if (settled)
                return;
            settled = true;
            clearTimeout(timer);
            if (err)
                reject(err);
            else
                resolve();
        };
        const child = (0, child_process_1.spawn)(javaPath, args, { cwd, windowsHide: true });
        // 安装器不会自己退出时不能让「安装服务端」永远转圈：20 分钟后强制结束
        const timer = setTimeout(() => {
            try {
                child.kill('SIGKILL');
            }
            catch { /* 进程可能已退出 */ }
            finish(new Error('安装器超过 20 分钟没有结束，已强制停止。请检查网络后重试，或手动运行安装器。'));
        }, 20 * 60 * 1000);
        child.stdout.on('data', d => String(d).split(/\r?\n/).filter(Boolean).forEach(onLine));
        child.stderr.on('data', d => String(d).split(/\r?\n/).filter(Boolean).forEach(onLine));
        child.on('error', e => finish(e));
        child.on('close', code => finish(code === 0 ? undefined : new Error(`安装器退出码 ${code}，请查看上面的安装日志。`)));
    });
}
function writeEula(id) {
    fs.writeFileSync(path.join(paths.serverDir(id), 'eula.txt'), '#By changing the setting below to TRUE you are indicating your agreement to our EULA (https://aka.ms/MinecraftEULA).\neula=true\n', 'utf8');
}
function acceptEula(id) {
    const cfg = updateServer(id, { eulaAccepted: true });
    writeEula(id);
    return cfg;
}
/* ============================== 启动 / 停止 ============================== */
function portAvailable(port) {
    return new Promise(resolve => {
        const server = net.createServer();
        server.once('error', () => resolve(false));
        server.once('listening', () => server.close(() => resolve(true)));
        server.listen(port, '0.0.0.0');
    });
}
function isPortAvailable(port) {
    if (!Number.isInteger(port) || port < 1 || port > 65535)
        return Promise.resolve(false);
    return portAvailable(port);
}
/** 退出启动器时强制结束所有服务端进程（同步，避免 Electron 先退出留下孤儿 Java） */
function killAllServersSync() {
    for (const rt of runtimes.values()) {
        const pid = rt.child?.pid;
        if (!pid)
            continue;
        try {
            if (process.platform === 'win32') {
                (0, child_process_1.execFileSync)('taskkill', ['/PID', String(pid), '/T', '/F'], { timeout: 8000, windowsHide: true, stdio: 'ignore' });
            }
            else {
                rt.child.kill('SIGKILL');
            }
        }
        catch { /* 进程已退出 */ }
        rt.child = null;
        rt.status = 'stopped';
    }
}
function jvmArgsFor(cfg) {
    const settings = (0, settings_1.getSettings)();
    const min = Math.max(256, Math.floor(cfg.memoryMB / 2));
    const args = [`-Xms${min}M`, `-Xmx${cfg.memoryMB}M`];
    if (settings.launch.utf8Encoding)
        args.push('-Dfile.encoding=UTF-8', '-Dsun.jnu.encoding=UTF-8');
    // 服务端也加 Log4j 缓解（老版本）
    if (settings.launch.log4jFix && /^1\.([0-9]|1[0-6])\./.test(cfg.mcVersion))
        args.push('-Dlog4j2.formatMsgNoLookups=true');
    for (const piece of (settings.launch.globalJvmArgs || '').split(/\s+|\n+/).map(s => s.trim()).filter(Boolean))
        args.push(piece);
    for (const piece of (cfg.jvmArgsExtra || '').split(/\s+|\n+/).map(s => s.trim()).filter(Boolean))
        args.push(piece);
    for (const piece of (0, proxy_1.proxyJvmArgs)())
        args.push(piece);
    return args;
}
async function startServer(id) {
    const cfg = readConfig(id);
    const rt = runtimeOf(id);
    if (rt.child || rt.status === 'running' || rt.status === 'starting' || rt.status === 'stopping')
        throw new Error('服务器已经在运行中');
    if (rt.status === 'preparing')
        throw new Error('服务端正在安装，请等安装完成后再启动');
    if (!cfg.eulaAccepted)
        throw new Error('请先阅读并同意 Minecraft 服务器 EULA（界面中勾选后再启动）。');
    const dir = paths.serverDir(id);
    if (!cfg.prepared)
        await prepareServer(id);
    const fresh = readConfig(id);
    const forgeLoader = fresh.loader === 'forge' || fresh.loader === 'neoforge' ? fresh.loader : null;
    const expectedForgeDir = forgeLoader ? forgeDirName(forgeLoader, fresh.mcVersion, fresh.loaderVersion ?? null) : null;
    const forgeArgs = forgeLoader ? findForgeArgs(dir, forgeLoader, expectedForgeDir) : null;
    // 1.16 及更早的 Forge 没有 win_args.txt：退回安装器产出的 forge-*.jar
    const legacyForgeJar = forgeLoader === 'forge' && !forgeArgs ? findForgeJar(dir, expectedForgeDir) : null;
    if (!forgeLoader && !findInstalledJar(dir, fresh.loader))
        throw new Error('服务端文件不存在，请点击「重新安装」后再启动。');
    if (forgeLoader && !forgeArgs && !legacyForgeJar)
        throw new Error('Forge/NeoForge 启动文件缺失，请点击「重新安装」后再启动。');
    // server.properties 才是服务端实际监听的权威端口；用户可能在属性页直接改过
    const propsPort = parseInt(readServerProperties(id)['server-port'] ?? '', 10);
    const effectivePort = Number.isInteger(propsPort) && propsPort >= 1 && propsPort <= 65535 ? propsPort : fresh.port;
    if (effectivePort !== fresh.port) {
        fresh.port = effectivePort;
        (0, store_1.writeJson)(paths.serverFile(id), fresh);
    }
    if (!(await portAvailable(effectivePort))) {
        throw new Error(`端口 ${effectivePort} 已被占用。请关闭占用该端口的程序，或在「服务器设置」里换一个端口。`);
    }
    const javaPath = await resolveJava(fresh);
    let args;
    if (forgeLoader && forgeArgs) {
        const userArgsFile = path.join(dir, 'user_jvm_args.txt');
        fs.writeFileSync(userArgsFile, `${jvmArgsFor(fresh).join('\n')}\n`, 'utf8');
        // JVM 参数已经写进 user_jvm_args.txt；命令行只引用参数文件。
        // 若再把 jvmArgsFor 放进命令行，每个参数会重复一次（-javaagent 之类会加载两遍）。
        args = [
            `@${path.relative(dir, userArgsFile).replace(/\\/g, '/')}`,
            `@${path.relative(dir, forgeArgs).replace(/\\/g, '/')}`,
            'nogui',
        ];
    }
    else if (forgeLoader && legacyForgeJar) {
        // 旧版 Forge 的 jar 不读 user_jvm_args.txt：JVM 参数必须直接放在命令行
        args = [...jvmArgsFor(fresh), '-jar', path.basename(legacyForgeJar), 'nogui'];
    }
    else {
        const jar = findInstalledJar(dir, fresh.loader);
        args = [...jvmArgsFor(fresh), '-jar', path.basename(jar), 'nogui'];
    }
    setStatus(id, 'starting');
    emitLog(id, `[mcl] 启动：${javaPath} ${args.slice(0, 5).join(' ')} …`);
    const child = (0, child_process_1.spawn)(javaPath, args, { cwd: dir, windowsHide: true, stdio: ['pipe', 'pipe', 'pipe'] });
    rt.child = child;
    rt.startedAt = Date.now();
    rt.stopping = false;
    rt.players.clear();
    updateServer(id, { lastStartedAt: rt.startedAt });
    // 玩家进出/进程退出时 server.json 可能正好被删除或改坏：
    // 事件回调里抛异常会直接崩掉主进程，这里统一静默跳过。
    const emitStatusSafe = () => {
        try {
            exports.serverEvents.emit('status', toInfo(readConfig(id)));
        }
        catch { /* 配置已不存在 */ }
    };
    const handleLine = (raw) => {
        const line = raw.trimEnd();
        if (!line.trim())
            return;
        emitLog(id, line);
        if (/Done \([\d.]+s\)! For help/.test(line))
            setStatus(id, 'running');
        const join = line.match(/(?:^|\]: )([A-Za-z0-9_]{1,16}) joined the game/);
        if (join) {
            rt.players.add(join[1]);
            emitStatusSafe();
        }
        const leave = line.match(/(?:^|\]: )([A-Za-z0-9_]{1,16}) left the game/);
        if (leave) {
            rt.players.delete(leave[1]);
            emitStatusSafe();
        }
        if (/Stopping server/.test(line))
            setStatus(id, 'stopping');
    };
    // stdout 的一个 chunk 可能截断在半行：必须跨 chunk 缓冲，否则 "Done (...)" 与玩家进出永远匹配不到
    const makeChunkHandler = () => {
        let pending = '';
        return (text) => {
            pending += String(text);
            const parts = pending.split(/\r?\n/);
            pending = parts.pop() ?? '';
            for (const line of parts)
                handleLine(line);
        };
    };
    child.stdout.on('data', makeChunkHandler());
    child.stderr.on('data', makeChunkHandler());
    child.on('error', err => {
        emitLog(id, `[mcl] 进程错误：${err.message}`);
        rt.status = 'crashed';
        rt.child = null;
        emitStatusSafe();
    });
    child.on('close', code => {
        const intentional = rt.stopping || code === 0;
        emitLog(id, `[mcl] 服务器进程退出，退出码 ${code}`);
        rt.child = null;
        rt.startedAt = null;
        rt.players.clear();
        rt.status = intentional ? 'stopped' : 'crashed';
        rt.stopping = false;
        emitStatusSafe();
    });
    return getServer(id);
}
async function stopServer(id) {
    const rt = runtimeOf(id);
    if (!rt.child)
        return false;
    rt.stopping = true;
    setStatus(id, 'stopping');
    emitLog(id, '[mcl] 正在发送 stop 命令…');
    try {
        rt.child.stdin.write('stop\n');
    }
    catch { /* ignore */ }
    const child = rt.child;
    const exited = await new Promise(resolve => {
        const timer = setTimeout(() => resolve(false), 30000);
        child.once('close', () => { clearTimeout(timer); resolve(true); });
    });
    if (!exited) {
        emitLog(id, '[mcl] 服务器 30 秒内未退出，强制结束进程。');
        await killServer(id);
    }
    return true;
}
/** 强制结束服务端（含子进程树） */
async function killServer(id) {
    const rt = runtimeOf(id);
    const child = rt.child;
    if (!child?.pid)
        return false;
    rt.stopping = true;
    if (process.platform === 'win32') {
        await new Promise(resolve => {
            (0, child_process_1.execFile)('taskkill', ['/PID', String(child.pid), '/T', '/F'], { timeout: 10000, windowsHide: true }, () => resolve());
        });
    }
    else {
        try {
            child.kill('SIGTERM');
        }
        catch { /* ignore */ }
        await new Promise(r => setTimeout(r, 1500));
        try {
            child.kill('SIGKILL');
        }
        catch { /* ignore */ }
    }
    return true;
}
function sendCommand(id, command) {
    const rt = runtimeOf(id);
    if (!rt.child?.stdin.writable)
        throw new Error('服务器没有运行');
    rt.child.stdin.write(`${command.replace(/\r?\n/g, '')}\n`);
    emitLog(id, `> ${command}`);
    return true;
}
/* ============================== 世界备份 ============================== */
function listServerBackups(id) {
    readConfig(id);
    const dir = paths.serverBackupsDir(id);
    if (!fs.existsSync(dir))
        return [];
    const out = [];
    for (const f of fs.readdirSync(dir)) {
        if (!f.endsWith('.zip'))
            continue;
        const p = path.join(dir, f);
        // 备份可能刚好被另一处操作删除：跳过而不是让整个列表报错
        try {
            const stat = fs.statSync(p);
            out.push({ name: f.replace(/\.zip$/, ''), filePath: p, sizeBytes: stat.size, createdAt: stat.mtimeMs });
        }
        catch { /* 文件已不存在 */ }
    }
    return out.sort((a, b) => b.createdAt - a.createdAt);
}
/** level-name 可被手动改成 ../xxx，必须校验解析后的世界目录仍在服务器目录内 */
function resolveServerWorldDir(id, worldName) {
    const serverDir = path.resolve(paths.serverDir(id));
    const worldDir = path.resolve(serverDir, worldName);
    if (worldDir !== serverDir && !worldDir.startsWith(serverDir + path.sep)) {
        throw new Error(`level-name「${worldName}」指向了服务器目录之外，请先在服务器属性里改成正常的世界名。`);
    }
    if (worldDir === serverDir)
        throw new Error('level-name 不能是服务器根目录，请改成具体世界名。');
    return worldDir;
}
async function backupServerWorld(id, name) {
    const rt = runtimeOf(id);
    // 运行中的世界文件仍在被服务端写入，直接打包可能得到缺区块/半写入的损坏存档
    if (rt.child || (rt.status !== 'stopped' && rt.status !== 'crashed')) {
        throw new Error('服务器运行中无法安全备份世界：世界文件仍在写入，打包出的存档可能损坏。请先停止服务器再备份。');
    }
    readConfig(id);
    const props = readServerProperties(id);
    const worldName = props['level-name'] || 'world';
    const worldDir = resolveServerWorldDir(id, worldName);
    if (!fs.existsSync(worldDir))
        throw new Error(`找不到世界目录：${worldName}`);
    const dir = paths.serverBackupsDir(id);
    fs.mkdirSync(dir, { recursive: true });
    const stamp = new Date().toISOString().replace(/[:.]/g, '-');
    const requested = (typeof name === 'string' ? name.trim() : '') || `world-${stamp}`;
    const base = requested.replace(/[^\w\u4e00-\u9fa5-]/g, '_').slice(0, 80) || `world-${stamp}`;
    const filePath = path.join(dir, `${base}.zip`);
    // 先写 .part 再改名：打包中途进程退出时，列表里不会出现可恢复、实际已截断的备份
    const partPath = `${filePath}.part`;
    try {
        await (0, zip_1.zipDirToFile)(worldDir, partPath);
        fs.renameSync(partPath, filePath);
    }
    catch (e) {
        try {
            fs.rmSync(partPath, { force: true });
        }
        catch { /* ignore */ }
        throw e;
    }
    invalidateDiskBytes(id);
    return { name: base, filePath, sizeBytes: fs.statSync(filePath).size, createdAt: Date.now() };
}
async function restoreServerWorld(id, backupName) {
    const rt = runtimeOf(id);
    if (rt.child || (rt.status !== 'stopped' && rt.status !== 'crashed'))
        throw new Error('请先停止服务器再恢复世界备份');
    readConfig(id);
    const props = readServerProperties(id);
    const worldName = props['level-name'] || 'world';
    const zipPath = path.join(paths.serverBackupsDir(id), `${path.basename(backupName)}.zip`);
    if (!fs.existsSync(zipPath))
        throw new Error('备份文件不存在');
    const worldDir = resolveServerWorldDir(id, worldName);
    const suffix = Date.now().toString(36);
    // 临时目录放在服务端备份目录：恢复中途崩溃时不会被误认成世界/安装文件
    const tempRoot = paths.serverBackupsDir(id);
    fs.mkdirSync(tempRoot, { recursive: true });
    const tempDir = path.join(tempRoot, `.restore-${suffix}`);
    const oldDir = path.join(tempRoot, `.old-${suffix}`);
    fs.mkdirSync(path.dirname(worldDir), { recursive: true });
    try {
        fs.mkdirSync(tempDir, { recursive: true });
        const files = await (0, zip_1.zipExtractAllFromFile)(zipPath, tempDir);
        // 直接往现有世界目录覆盖会把比备份新的区块留在原地，恢复出新旧混杂的存档；
        // 先解压到临时目录再整体替换，失败时原世界保持不动
        if (!files.some(p => path.basename(p) === 'level.dat'))
            throw new Error('备份里找不到 level.dat，不是有效的世界存档');
        if (fs.existsSync(worldDir))
            fs.renameSync(worldDir, oldDir);
        try {
            fs.renameSync(tempDir, worldDir);
        }
        catch (e) {
            if (fs.existsSync(oldDir)) {
                try {
                    fs.renameSync(oldDir, worldDir);
                }
                catch { /* ignore */ }
            }
            throw e;
        }
        try {
            fs.rmSync(oldDir, { recursive: true, force: true });
        }
        catch { /* 旧世界清理失败不影响已完成的恢复 */ }
        invalidateDiskBytes(id);
        return { restoredFiles: files.length };
    }
    finally {
        try {
            fs.rmSync(tempDir, { recursive: true, force: true });
        }
        catch { /* ignore */ }
    }
}
function deleteServerBackup(id, backupName) {
    readConfig(id);
    const zipPath = path.join(paths.serverBackupsDir(id), `${path.basename(backupName)}.zip`);
    fs.rmSync(zipPath, { force: true });
    invalidateDiskBytes(id);
}
/* ============================== 日志 ============================== */
function readServerLog(id, maxLines = 400) {
    readConfig(id);
    const rt = runtimeOf(id);
    if (rt.logTail.length > 0)
        return rt.logTail.slice(-maxLines);
    return tailFile(path.join(paths.serverDir(id), 'logs', 'latest.log'), maxLines);
}
