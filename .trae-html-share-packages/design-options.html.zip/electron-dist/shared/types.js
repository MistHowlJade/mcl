"use strict";
/**
 * MCL 共享类型定义（主进程 / 渲染进程共用）
 */
Object.defineProperty(exports, "__esModule", { value: true });
