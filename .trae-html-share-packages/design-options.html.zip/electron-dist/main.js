"use strict";
var __createBinding = (this && this.__createBinding) || (Object.create ? (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    var desc = Object.getOwnPropertyDescriptor(m, k);
    if (!desc || ("get" in desc ? !m.__esModule : desc.writable || desc.configurable)) {
      desc = { enumerable: true, get: function() { return m[k]; } };
    }
    Object.defineProperty(o, k2, desc);
}) : (function(o, m, k, k2) {
    if (k2 === undefined) k2 = k;
    o[k2] = m[k];
}));
var __setModuleDefault = (this && this.__setModuleDefault) || (Object.create ? (function(o, v) {
    Object.defineProperty(o, "default", { enumerable: true, value: v });
}) : function(o, v) {
    o["default"] = v;
});
var __importStar = (this && this.__importStar) || (function () {
    var ownKeys = function(o) {
        ownKeys = Object.getOwnPropertyNames || function (o) {
            var ar = [];
            for (var k in o) if (Object.prototype.hasOwnProperty.call(o, k)) ar[ar.length] = k;
            return ar;
        };
        return ownKeys(o);
    };
    return function (mod) {
        if (mod && mod.__esModule) return mod;
        var result = {};
        if (mod != null) for (var k = ownKeys(mod), i = 0; i < k.length; i++) if (k[i] !== "default") __createBinding(result, mod, k[i]);
        __setModuleDefault(result, mod);
        return result;
    };
})();
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * MCL 主进程入口
 * - 无边框窗口 + 深色原生底
 * - 启动时静默清理残余游戏进程（痛点 #31）
 * - 安全默认值：contextIsolation + sandbox + 无 nodeIntegration
 */
const electron_1 = require("electron");
const fs = __importStar(require("fs"));
const path = __importStar(require("path"));
const url_1 = require("url");
const ipc_1 = require("./services/ipc");
const paths_1 = require("./services/paths");
const settings_1 = require("./services/settings");
const channel_1 = require("./services/channel");
const minecraft_1 = require("./services/minecraft");
const server_1 = require("./services/server");
// 本地媒体协议：只读、限定在 MCL 数据目录内，用于截图/世界图标预览
electron_1.protocol.registerSchemesAsPrivileged([
    {
        scheme: 'mcl-media',
        privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true },
    },
]);
const MEDIA_MIME = {
    '.png': 'image/png',
    '.jpg': 'image/jpeg',
    '.jpeg': 'image/jpeg',
    '.gif': 'image/gif',
    '.webp': 'image/webp',
};
function registerMediaProtocol() {
    electron_1.protocol.handle('mcl-media', async (request) => {
        try {
            const url = new URL(request.url);
            const raw = url.searchParams.get('p');
            if (!raw)
                return new Response('缺少路径参数', { status: 400 });
            // URLSearchParams 已经解码一次，不能再 decodeURIComponent，否则路径里的 % 会被二次解码
            const target = path.resolve(raw);
            const root = path.resolve((0, paths_1.dataRoot)());
            // 目录穿越防护：渲染进程只能读取 MCL 数据目录内的文件
            if (target !== root && !target.startsWith(root + path.sep)) {
                return new Response('拒绝访问数据目录之外的文件', { status: 403 });
            }
            // 只允许图片：数据目录里还有 accounts.json / settings.json 等含令牌的文件
            const mime = MEDIA_MIME[path.extname(target).toLowerCase()];
            if (!mime)
                return new Response('仅支持图片预览', { status: 403 });
            const stat = await fs.promises.stat(target);
            if (!stat.isFile())
                return new Response('文件不存在', { status: 404 });
            const data = await fs.promises.readFile(target);
            return new Response(data, {
                headers: {
                    'Content-Type': mime,
                    'Cache-Control': 'no-cache',
                },
            });
        }
        catch {
            return new Response('文件不存在', { status: 404 });
        }
    });
}
// 把所有 MCL 相关目录（含 Electron 自身缓存）收敛到数据根，必须在 ready / 单实例锁之前
(0, paths_1.redirectElectronPaths)();
// 单实例锁：防止同时开两个窗口导致数据目录竞争
const gotLock = electron_1.app.requestSingleInstanceLock();
if (!gotLock) {
    electron_1.app.quit();
}
else {
    electron_1.app.on('second-instance', () => {
        const win = electron_1.BrowserWindow.getAllWindows()[0];
        if (win) {
            if (win.isMinimized())
                win.restore();
            win.focus();
        }
    });
}
const DEV_URL = process.env.VITE_DEV_SERVER_URL;
const CHANNEL = (0, channel_1.getChannel)();
async function createWindow() {
    (0, paths_1.ensureLayout)();
    const settings = (0, settings_1.getSettings)();
    const win = new electron_1.BrowserWindow({
        width: 1360,
        height: 840,
        minWidth: 1024,
        minHeight: 640,
        frame: false,
        backgroundColor: '#10131a',
        icon: path.join(__dirname, '..', 'assets', 'app.ico'),
        show: false,
        webPreferences: {
            preload: path.join(__dirname, 'preload.js'),
            contextIsolation: true,
            sandbox: true,
            nodeIntegration: false,
            spellcheck: false,
        },
    });
    win.once('ready-to-show', () => {
        win.show();
        // 开发版：任务栏标题带标识，并自动弹出独立 DevTools，方便直接看控制台与网络
        if (CHANNEL === 'dev') {
            win.setTitle(`MCL · ${channel_1.CHANNEL_LABEL.dev}（DevTools 已开启）`);
            win.webContents.openDevTools({ mode: 'detach' });
        }
        // 配置可能被手工改坏或来自旧版云快照：非数字会让 setZoomFactor 抛错，窗口直接起不来
        const rawZoom = Number(settings.general.zoomFactor);
        win.webContents.setZoomFactor(Number.isFinite(rawZoom) ? Math.min(2, Math.max(0.75, rawZoom)) : 1);
    });
    // 外部链接一律交给系统浏览器，不在应用内打开（防钓鱼）
    win.webContents.setWindowOpenHandler(({ url }) => {
        if (/^https?:\/\//i.test(url))
            electron_1.shell.openExternal(url);
        return { action: 'deny' };
    });
    // 禁止当前窗口被导航到远程页面：preload 暴露了 IPC，远程页面绝不能在应用窗口里加载
    const indexPath = path.resolve(__dirname, '..', 'dist', 'index.html');
    win.webContents.on('will-navigate', (event, url) => {
        let allowed = false;
        try {
            const target = new URL(url);
            if (DEV_URL) {
                allowed = target.origin === new URL(DEV_URL).origin;
            }
            else {
                // 生产环境只允许停在打包好的 index.html：任意 file:// 页面也会拿到 preload 的 IPC
                allowed = target.protocol === 'file:' && path.resolve((0, url_1.fileURLToPath)(target)) === indexPath;
            }
        }
        catch {
            allowed = false;
        }
        if (allowed)
            return;
        event.preventDefault();
        if (/^https?:\/\//i.test(url))
            void electron_1.shell.openExternal(url);
    });
    if (DEV_URL) {
        await win.loadURL(DEV_URL);
    }
    else {
        await win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
    }
}
if (gotLock) {
    electron_1.app.whenReady().then(() => {
        registerMediaProtocol();
        (0, ipc_1.registerIpcHandlers)();
        (0, ipc_1.bindServiceEvents)();
        // 残余进程清理：异步进行，不阻塞窗口
        const settings = (0, settings_1.getSettings)();
        if (settings.launch.autoKillResidual) {
            void (0, minecraft_1.killResidualProcesses)().catch(() => undefined);
        }
        void createWindow();
        electron_1.app.on('activate', () => {
            if (electron_1.BrowserWindow.getAllWindows().length === 0)
                void createWindow();
        });
    });
    // 退出时先给运行中的服务端发 stop 让世界正常保存；10 秒内没退才强杀，避免留下孤儿 Java。
    let quitting = false;
    electron_1.app.on('before-quit', (e) => {
        if (quitting)
            return;
        const running = (0, server_1.listServers)().filter(s => s.status === 'running' || s.status === 'starting');
        if (running.length === 0)
            return;
        e.preventDefault();
        quitting = true;
        void Promise.race([
            Promise.all(running.map(s => (0, server_1.stopServer)(s.id).catch(() => undefined))),
            new Promise(resolve => setTimeout(resolve, 10000)),
        ]).finally(() => {
            try {
                (0, server_1.killAllServersSync)();
            }
            catch { /* 忽略 */ }
            electron_1.app.quit();
        });
    });
    electron_1.app.on('window-all-closed', () => {
        if (process.platform !== 'darwin')
            electron_1.app.quit();
    });
}
