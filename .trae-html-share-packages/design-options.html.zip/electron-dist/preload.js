"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
/**
 * Preload：唯一的渲染进程桥
 * 仅暴露 invoke / on 通道，不把 Node 能力泄漏给网页（contextIsolation + sandbox）
 */
const electron_1 = require("electron");
const invoke = (channel, ...args) => electron_1.ipcRenderer.invoke(channel, ...args);
const on = (channel, callback) => {
    const listener = (_event, ...args) => callback(...args);
    electron_1.ipcRenderer.on(channel, listener);
    return () => electron_1.ipcRenderer.removeListener(channel, listener);
};
// Electron 32 起 File.path 被移除：拖放文件必须用 webUtils.getPathForFile 取真实路径
const getDropPaths = (files) => Array.from(files)
    .map(file => electron_1.webUtils.getPathForFile(file))
    .filter(p => typeof p === 'string' && p.length > 0);
electron_1.contextBridge.exposeInMainWorld('mcl', { invoke, on, getDropPaths });
