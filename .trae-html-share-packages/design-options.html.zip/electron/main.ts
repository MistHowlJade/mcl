/**
 * MCL 主进程入口
 * - 无边框窗口 + 深色原生底
 * - 启动时静默清理残余游戏进程（痛点 #31）
 * - 安全默认值：contextIsolation + sandbox + 无 nodeIntegration
 */
import { app, BrowserWindow, shell, protocol } from 'electron';
import * as fs from 'fs';
import * as path from 'path';
import { fileURLToPath } from 'url';
import { registerIpcHandlers, bindServiceEvents } from './services/ipc';
import { dataRoot, ensureLayout, redirectElectronPaths } from './services/paths';
import { getSettings } from './services/settings';
import { getChannel, CHANNEL_LABEL } from './services/channel';
import { killResidualProcesses } from './services/minecraft';
import { killAllServersSync, listServers, stopServer } from './services/server';

// 本地媒体协议：只读、限定在 MCL 数据目录内，用于截图/世界图标预览
protocol.registerSchemesAsPrivileged([
  {
    scheme: 'mcl-media',
    privileges: { standard: true, secure: true, supportFetchAPI: true, corsEnabled: true, stream: true },
  },
]);

const MEDIA_MIME: Record<string, string> = {
  '.png': 'image/png',
  '.jpg': 'image/jpeg',
  '.jpeg': 'image/jpeg',
  '.gif': 'image/gif',
  '.webp': 'image/webp',
};

function registerMediaProtocol(): void {
  protocol.handle('mcl-media', async (request) => {
    try {
      const url = new URL(request.url);
      const raw = url.searchParams.get('p');
      if (!raw) return new Response('缺少路径参数', { status: 400 });
      // URLSearchParams 已经解码一次，不能再 decodeURIComponent，否则路径里的 % 会被二次解码
      const target = path.resolve(raw);
      const root = path.resolve(dataRoot());
      // 目录穿越防护：渲染进程只能读取 MCL 数据目录内的文件
      if (target !== root && !target.startsWith(root + path.sep)) {
        return new Response('拒绝访问数据目录之外的文件', { status: 403 });
      }
      // 只允许图片：数据目录里还有 accounts.json / settings.json 等含令牌的文件
      const mime = MEDIA_MIME[path.extname(target).toLowerCase()];
      if (!mime) return new Response('仅支持图片预览', { status: 403 });
      const stat = await fs.promises.stat(target);
      if (!stat.isFile()) return new Response('文件不存在', { status: 404 });
      const data = await fs.promises.readFile(target);
      return new Response(data, {
        headers: {
          'Content-Type': mime,
          'Cache-Control': 'no-cache',
        },
      });
    } catch {
      return new Response('文件不存在', { status: 404 });
    }
  });
}

// 把所有 MCL 相关目录（含 Electron 自身缓存）收敛到数据根，必须在 ready / 单实例锁之前
redirectElectronPaths();

// 单实例锁：防止同时开两个窗口导致数据目录竞争
const gotLock = app.requestSingleInstanceLock();
if (!gotLock) {
  app.quit();
} else {
  app.on('second-instance', () => {
    const win = BrowserWindow.getAllWindows()[0];
    if (win) {
      if (win.isMinimized()) win.restore();
      win.focus();
    }
  });
}

const DEV_URL = process.env.VITE_DEV_SERVER_URL;
const CHANNEL = getChannel();

async function createWindow(): Promise<void> {
  ensureLayout();
  const settings = getSettings();
  const win = new BrowserWindow({
    width: 1360,
    height: 840,
    minWidth: 1024,
    minHeight: 640,
    frame: false,
    backgroundColor: '#10131a',
    icon: path.join(__dirname, '..', 'assets', 'app.ico'),
    show: false,
    webPreferences: {
      preload: path.join(__dirname, 'preload.js'),
      contextIsolation: true,
      sandbox: true,
      nodeIntegration: false,
      spellcheck: false,
    },
  });

  win.once('ready-to-show', () => {
    win.show();
    // 开发版：任务栏标题带标识，并自动弹出独立 DevTools，方便直接看控制台与网络
    if (CHANNEL === 'dev') {
      win.setTitle(`MCL · ${CHANNEL_LABEL.dev}（DevTools 已开启）`);
      win.webContents.openDevTools({ mode: 'detach' });
    }
    // 配置可能被手工改坏或来自旧版云快照：非数字会让 setZoomFactor 抛错，窗口直接起不来
    const rawZoom = Number(settings.general.zoomFactor);
    win.webContents.setZoomFactor(Number.isFinite(rawZoom) ? Math.min(2, Math.max(0.75, rawZoom)) : 1);
  });

  // 外部链接一律交给系统浏览器，不在应用内打开（防钓鱼）
  win.webContents.setWindowOpenHandler(({ url }) => {
    if (/^https?:\/\//i.test(url)) shell.openExternal(url);
    return { action: 'deny' };
  });
  // 禁止当前窗口被导航到远程页面：preload 暴露了 IPC，远程页面绝不能在应用窗口里加载
  const indexPath = path.resolve(__dirname, '..', 'dist', 'index.html');
  win.webContents.on('will-navigate', (event, url) => {
    let allowed = false;
    try {
      const target = new URL(url);
      if (DEV_URL) {
        allowed = target.origin === new URL(DEV_URL).origin;
      } else {
        // 生产环境只允许停在打包好的 index.html：任意 file:// 页面也会拿到 preload 的 IPC
        allowed = target.protocol === 'file:' && path.resolve(fileURLToPath(target)) === indexPath;
      }
    } catch { allowed = false; }
    if (allowed) return;
    event.preventDefault();
    if (/^https?:\/\//i.test(url)) void shell.openExternal(url);
  });

  if (DEV_URL) {
    await win.loadURL(DEV_URL);
  } else {
    await win.loadFile(path.join(__dirname, '..', 'dist', 'index.html'));
  }
}

if (gotLock) {
  app.whenReady().then(() => {
    registerMediaProtocol();
    registerIpcHandlers();
    bindServiceEvents();
    // 残余进程清理：异步进行，不阻塞窗口
    const settings = getSettings();
    if (settings.launch.autoKillResidual) {
      void killResidualProcesses().catch(() => undefined);
    }
    void createWindow();

    app.on('activate', () => {
      if (BrowserWindow.getAllWindows().length === 0) void createWindow();
    });
  });

  // 退出时先给运行中的服务端发 stop 让世界正常保存；10 秒内没退才强杀，避免留下孤儿 Java。
  let quitting = false;
  app.on('before-quit', (e) => {
    if (quitting) return;
    const running = listServers().filter(s => s.status === 'running' || s.status === 'starting');
    if (running.length === 0) return;
    e.preventDefault();
    quitting = true;
    void Promise.race([
      Promise.all(running.map(s => stopServer(s.id).catch(() => undefined))),
      new Promise(resolve => setTimeout(resolve, 10000)),
    ]).finally(() => {
      try { killAllServersSync(); } catch { /* 忽略 */ }
      app.quit();
    });
  });

  app.on('window-all-closed', () => {
    if (process.platform !== 'darwin') app.quit();
  });
}
