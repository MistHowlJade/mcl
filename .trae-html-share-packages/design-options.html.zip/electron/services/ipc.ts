/**
 * IPC 总线：渲染进程 ↔ 主进程
 * 所有 handle 包装统一错误边界（异常 → 标准 { ok:false, error } 之外的抛出由 renderer catch）
 */
import { BrowserWindow, dialog, ipcMain, shell, app, clipboard } from 'electron';
import * as fs from 'fs';
import * as path from 'path';
import * as paths from './paths';
import { getSettings, updateSettings, resetSettings } from './settings';
import * as instances from './instances';
import * as versionService from './version';
import * as javaService from './java';
import * as authService from './auth';
import * as minecraft from './minecraft';
import * as backups from './backup';
import * as modrinth from './modrinth';
import * as modpack from './modpack';
import * as modhealth from './modhealth';
import * as migrate from './migrate';
import * as crashService from './crash';
import * as diagnostic from './diagnostic';
import * as logsService from './logs';
import * as serverService from './server';
import * as cloudService from './cloud';
import * as contentService from './content';
import * as exporter from './exporter';
import * as updateService from './update';
import * as lanService from './lan';
import { downloadTasks } from './tasks';
import { getVersionManifest } from './version';
import { errorReason } from './net';
import { AppInfo, CrashFix, LoaderType, MemoryPreset, TaskAction, TaskKind } from '../shared/types';
import { getChannel } from './channel';

const sendToAll = (channel: string, payload: unknown) => {
  for (const win of BrowserWindow.getAllWindows()) {
    if (!win.isDestroyed()) win.webContents.send(channel, payload);
  }
};

/**
 * 运行中的实例会持续写存档/日志：复制、备份、导出、删世界前统一拒绝，
 * 避免产出半写入的损坏文件，或删到游戏正在使用的世界。
 */
function assertInstanceIdle(instanceId: string, action: string): void {
  const busyStates = ['preparing', 'downloading', 'launching', 'running'];
  if (minecraft.launchState.instanceId === instanceId && busyStates.includes(minecraft.launchState.status)) {
    throw new Error(`这个实例正在运行，无法${action}。请先退出游戏，等实例状态变为「已退出」后再试。`);
  }
}

/** 云快照可能覆盖存档/配置：有游戏在运行时整体拒绝，避免两边同时写同一批文件 */
function assertNoGameBusy(action: string): void {
  const busyStates = ['preparing', 'downloading', 'launching', 'running'];
  if (busyStates.includes(minecraft.launchState.status)) {
    throw new Error(`游戏正在运行，无法${action}。请先退出游戏，避免覆盖正在写入的存档与配置。`);
  }
}

/* ---------- 下载任务中心：与启动流程联动 ---------- */
let launchDownloadTask: string | null = null;
function finishLaunchDownloadTask(ok: boolean, error?: string): void {
  if (!launchDownloadTask) return;
  const id = launchDownloadTask;
  launchDownloadTask = null;
  if (ok) downloadTasks.done(id); else downloadTasks.fail(id, error ?? '下载未完成');
}

/** 把一次「有明确开始/结束」的业务包成任务，失败时把人话错误带进任务列表 */
async function withTask<T>(kind: TaskKind, name: string, fn: () => Promise<T>, action?: TaskAction): Promise<T> {
  const id = downloadTasks.begin(kind, name, action);
  try {
    const result = await fn();
    downloadTasks.done(id, action);
    return result;
  } catch (e) {
    downloadTasks.fail(id, errorReason(e), action);
    throw e;
  }
}

// 服务事件 → 渲染进程
export function bindServiceEvents(): void {
  downloadTasks.on('changed', () => sendToAll('tasks:changed', downloadTasks.list()));
  minecraft.launchEvents.on('status', (s: { status: string; instanceId: string | null }) => {
    if (s.status === 'downloading' && s.instanceId) {
      if (!launchDownloadTask) {
        const inst = instances.getInstance(s.instanceId);
        launchDownloadTask = downloadTasks.begin('launch', `${inst?.name ?? '游戏'} · 下载游戏文件`,
          { retry: { type: 'launch', instanceId: s.instanceId } });
        downloadTasks.setCanceler(launchDownloadTask, () => minecraft.cancelLaunchDownload());
      }
    } else if (['launching', 'running'].includes(s.status) && launchDownloadTask) {
      // 进入启动阶段说明本次下载已完成
      finishLaunchDownloadTask(true);
    }
  });
  minecraft.launchEvents.on('progress', (p: { done: number; total: number } | null) => {
    if (launchDownloadTask && p) downloadTasks.progress(launchDownloadTask, p.done, p.total);
  });
  minecraft.launchEvents.on('exit', (e: { crashed?: boolean } | null) => {
    if (e?.crashed) finishLaunchDownloadTask(false, '游戏启动失败');
  });
  minecraft.launchEvents.on('status', s => sendToAll('launch:status', s));
  minecraft.launchEvents.on('log', line => sendToAll('launch:log', line));
  minecraft.launchEvents.on('progress', p => sendToAll('launch:progress', p));
  minecraft.launchEvents.on('crash', d => sendToAll('launch:crash', d));
  minecraft.launchEvents.on('exit', e => sendToAll('launch:exit', e));
  serverService.serverEvents.on('status', (info: unknown) => sendToAll('server:status', info));
  serverService.serverEvents.on('log', (payload: unknown) => sendToAll('server:log', payload));
}

const isSafeExternal = (url: string) => /^https?:\/\//i.test(url);

export function registerIpcHandlers(): void {
  /* ---------- 应用元信息 ---------- */
  ipcMain.handle('app:info', (): AppInfo => ({
    name: 'MCL',
    version: app.getVersion(),
    dataDir: paths.dataRoot(),
    platform: process.platform,
    arch: process.arch,
    channel: getChannel(),
  }));

  /* ---------- 窗口控制（无边框窗口） ---------- */
  ipcMain.handle('win:minimize', () => BrowserWindow.getFocusedWindow()?.minimize());
  ipcMain.handle('win:toggleMaximize', () => {
    const win = BrowserWindow.getFocusedWindow();
    if (!win) return false;
    if (win.isMaximized()) win.unmaximize(); else win.maximize();
    return win.isMaximized();
  });
  ipcMain.handle('win:isMaximized', () => BrowserWindow.getFocusedWindow()?.isMaximized() ?? false);
  ipcMain.handle('win:close', () => BrowserWindow.getFocusedWindow()?.close());
  ipcMain.handle('win:setZoom', (_e, factor: number) => {
    const win = BrowserWindow.getFocusedWindow();
    if (win) win.webContents.setZoomFactor(Math.min(2, Math.max(0.75, Number(factor) || 1)));
    return true;
  });

  /* ---------- 设置 ---------- */
  ipcMain.handle('settings:get', () => getSettings());
  ipcMain.handle('settings:update', (_e, patch: any) => updateSettings(patch));
  ipcMain.handle('settings:reset', () => resetSettings());

  /* ---------- Shell ---------- */
  ipcMain.handle('shell:openPath', (_e, p: string) => {
    if (typeof p !== 'string' || !p) return '路径无效';
    // 只允许打开 MCL 数据目录内的路径：即使渲染进程被注入，也不能借 openPath 启动任意程序
    const root = path.resolve(paths.dataRoot());
    const target = path.resolve(p);
    if (target !== root && !target.startsWith(root + path.sep)) return '只能打开 MCL 数据目录内的文件';
    return shell.openPath(target);
  });
  ipcMain.handle('shell:openExternal', (_e, url: string) => {
    if (!isSafeExternal(url)) return;
    return shell.openExternal(url);
  });
  ipcMain.handle('clipboard:write', (_e, text: string) => {
    clipboard.writeText(String(text ?? ''));
    return true;
  });
  ipcMain.handle('dialog:pickFolder', async () => {
    const win = BrowserWindow.getFocusedWindow();
    const result = await dialog.showOpenDialog(win!, { properties: ['openDirectory'], title: '选择数据目录' });
    return result.canceled ? null : result.filePaths[0];
  });
  ipcMain.handle('dialog:pickFile', async (_e, filters: Array<{ name: string; extensions: string[] }>) => {
    const win = BrowserWindow.getFocusedWindow();
    const result = await dialog.showOpenDialog(win!, { properties: ['openFile'], filters });
    return result.canceled ? null : result.filePaths[0];
  });

  /* ---------- 版本清单 ---------- */
  ipcMain.handle('versions:list', async () => {
    const settings = getSettings();
    const manifest = await getVersionManifest(settings.download.source, settings.download.customMirror);
    return manifest.versions.map(v => ({ id: v.id, type: v.type, releaseTime: v.releaseTime }));
  });

  /* ---------- Java ---------- */
  ipcMain.handle('java:detect', () => javaService.detectSystemJavas());
  ipcMain.handle('java:recommended', (_e, mcVersion: string) => ({
    major: javaService.recommendedJavaMajor(mcVersion),
  }));
  ipcMain.handle('java:install', async (_e, major: number) => {
    const taskId = downloadTasks.begin('java', `安装 Java ${major}`);
    const action: TaskAction = { openDir: paths.javaDir(), retry: { type: 'java', major } };
    try {
      const exe = await javaService.installJava(major, (stage, received, total) => {
        if (typeof received === 'number' && typeof total === 'number') downloadTasks.progress(taskId, received, total);
        sendToAll('java:progress', { stage, received, total });
      });
      downloadTasks.done(taskId, { ...action, revealFile: exe });
      return exe;
    } catch (e) {
      downloadTasks.fail(taskId, errorReason(e), action);
      throw e;
    }
  });

  /* ---------- 实例 ---------- */
  ipcMain.handle('instances:list', () => instances.listInstances());
  ipcMain.handle('instances:get', (_e, id: string) => instances.getInstance(id));
  ipcMain.handle('instances:create', (_e, input: { name: string; mcVersion: string; loader: LoaderType; loaderVersion?: string | null; memoryPreset?: MemoryPreset; javaPath?: string | null }) => instances.createInstance(input));
  ipcMain.handle('instances:update', (_e, id: string, patch: any) => instances.updateInstance(id, patch));
  ipcMain.handle('instances:duplicate', (_e, id: string) => {
    assertInstanceIdle(id, '复制实例');
    return instances.duplicateInstance(id);
  });
  ipcMain.handle('instances:delete', async (_e, id: string) => {
    // 游戏运行时删除会把正在使用的存档/模组删到一半，先拒绝并给出人话提示
    assertInstanceIdle(id, '删除实例');
    const backupDir = path.join(paths.backupsDir(), 'deleted-instances');
    return instances.deleteInstanceWithBackup(id, backupDir);
  });
  ipcMain.handle('instances:diskUsage', (_e, id: string) => ({ instance: instances.instanceDiskBytes(id), shared: instances.sharedDiskBytes() }));
  ipcMain.handle('instances:openGameDir', (_e, id: string) => {
    const instance = instances.getInstance(id);
    if (!instance) throw new Error('实例不存在');
    return shell.openPath(instance.gameDir);
  });
  ipcMain.handle('instances:openInstanceDir', (_e, id: string) => {
    const instance = instances.getInstance(id);
    if (!instance) throw new Error('实例不存在');
    return shell.openPath(paths.instanceDir(instance.id));
  });

  /* ---------- 启动 ---------- */
  ipcMain.handle('launch:start', async (_e, instanceId: string, accountId?: string | null) => {
    // 状态由 launchInstance 自己接管（它的并发保护依赖 status，不能在这里预写 instanceId）
    void minecraft.launchInstance(instanceId, { accountId }).catch(err => {
      const message = errorReason(err);
      // 若只是"已有实例在运行"被拒绝，绝不能把正在运行的实例状态重置为 idle
      if (!(err instanceof minecraft.LaunchBusyError) && minecraft.launchState.instanceId === instanceId) {
        minecraft.launchState.status = 'idle';
        minecraft.launchState.message = message;
        minecraft.launchState.progress = null;
        sendToAll('launch:status', { ...minecraft.launchState });
      }
      finishLaunchDownloadTask(false, message);
      sendToAll('launch:failed', { instanceId, error: message });
    });
    return { started: true };
  });
  ipcMain.handle('launch:state', () => ({ ...minecraft.launchState }));
  ipcMain.handle('launch:cancelDownload', () => minecraft.cancelLaunchDownload());
  ipcMain.handle('launch:killResidual', async () => ({ killed: await minecraft.killResidualProcesses() }));

  /* ---------- 账号 ---------- */
  ipcMain.handle('accounts:list', () => authService.listAccounts());
  ipcMain.handle('accounts:active', () => authService.getActiveAccount());
  ipcMain.handle('accounts:setActive', (_e, id: string) => { authService.setActiveAccount(id); return true; });
  ipcMain.handle('accounts:remove', (_e, id: string) => { authService.removeAccount(id); return true; });
  ipcMain.handle('accounts:createOffline', (_e, name: string, skinDataUrl?: string | null) => authService.createOfflineAccount(name, skinDataUrl ?? null));
  ipcMain.handle('accounts:beginMicrosoft', async () => {
    const session = await authService.beginMicrosoftLogin();
    // 后台完成轮询链路；结果通过事件推给渲染进程（带 userCode 供前端忽略旧尝试）
    void authService.finishMicrosoftLogin(session).then(result => {
      sendToAll('accounts:microsoft-result', { ok: true, userCode: session.userCode, account: result.account, warn: result.warn ?? null });
    }).catch(err => {
      const message = errorReason(err);
      sendToAll('accounts:microsoft-result', { ok: false, userCode: session.userCode, canceled: message.includes('登录已取消'), error: message });
    });
    return session;
  });
  ipcMain.handle('accounts:cancelMicrosoft', (_e, userCode: string) => { authService.cancelMicrosoftLogin(userCode); return true; });
  /* ---------- 皮肤 / 披风 ---------- */
  const pickPng = async (title: string): Promise<string | null> => {
    const win = BrowserWindow.getFocusedWindow();
    const result = await dialog.showOpenDialog(win!, {
      properties: ['openFile'],
      title,
      filters: [{ name: 'PNG 图片', extensions: ['png'] }],
    });
    return result.canceled ? null : (result.filePaths[0] ?? null);
  };

  ipcMain.handle('accounts:localSkin', async (_e, accountId: string, model: 'classic' | 'slim') => {
    const file = await pickPng('选择皮肤 PNG（64×64 或旧版 64×32）');
    if (!file) return null;
    return authService.setLocalSkin(accountId, file, model === 'slim' ? 'slim' : 'classic');
  });
  ipcMain.handle('accounts:clearLocalSkin', (_e, accountId: string) => authService.clearLocalSkin(accountId));
  ipcMain.handle('accounts:localCape', async (_e, accountId: string) => {
    const file = await pickPng('选择披风 PNG（64×32）');
    if (!file) return null;
    return authService.setLocalCape(accountId, file);
  });
  ipcMain.handle('accounts:clearLocalCape', (_e, accountId: string) => authService.clearLocalCape(accountId));
  ipcMain.handle('accounts:microsoftSkin', async (_e, accountId: string, variant: 'classic' | 'slim') => {
    const file = await pickPng('选择要上传到 Mojang 的皮肤 PNG');
    if (!file) return null;
    return authService.uploadMicrosoftSkin(accountId, file, variant === 'slim' ? 'slim' : 'classic');
  });
  ipcMain.handle('accounts:microsoftSkinReset', (_e, accountId: string) => authService.resetMicrosoftSkin(accountId));

  /* ---------- 模组（Modrinth） ---------- */
  ipcMain.handle('modrinth:search', (_e, query: string, opts: { loader?: string; gameVersion?: string; projectType?: 'mod' | 'modpack'; index?: 'relevance' | 'downloads' | 'follows' | 'updated' }) =>
    modrinth.searchMods(query, opts));
  ipcMain.handle('modrinth:searchContent', (_e, query: string, opts: { projectType: any; loader?: string; gameVersion?: string; limit?: number; index?: 'relevance' | 'downloads' | 'follows' | 'updated' }) =>
    modrinth.searchContent(query, opts));
  ipcMain.handle('modrinth:installContent', (_e, instanceId: string, projectId: string, versionId: string | null, kind: 'modpack' | 'resourcepacks' | 'shaderpacks' | 'worlds', opts: { gameVersion?: string; loader?: string; name?: string }) => {
    const inst = instances.getInstance(instanceId);
    const sub = kind === 'modpack' ? null : kind === 'worlds' ? 'saves' : kind;
    const action: TaskAction = { openDir: inst ? (sub ? path.join(inst.gameDir, sub) : paths.instancesDir()) : paths.instancesDir() };
    const labels = { modpack: '整合包', resourcepacks: '资源包', shaderpacks: '光影包', worlds: '世界' };
    const taskKinds: Record<typeof kind, TaskKind> = { modpack: 'modpack', resourcepacks: 'resourcepack', shaderpacks: 'shader', worlds: 'world' };
    return withTask(taskKinds[kind], `下载${labels[kind]}：${opts.name ?? projectId}`,
      () => modrinth.installContent(instanceId, projectId, versionId, kind, opts), action);
  });
  ipcMain.handle('modrinth:installed', (_e, instanceId: string) => {
    const tracked = modrinth.readInstalledMods(instanceId);
    const files = modrinth.listModFiles(instanceId);
    // mods 里可能同时有 foo.jar 与 foo.jar.disabled（手工复制/解压造成）：
    // 来源记录只挂在启用中的那份，否则两条结果会得到同一个 fileName，列表 key 重复且操作指向不明
    const enabledNames = new Set(files.filter(f => !f.disabled).map(f => f.fileName.toLowerCase()));
    const claimed = new Set<string>();
    return files.map(f => {
      // 禁用文件磁盘名是 foo.jar.disabled，跟踪记录里仍是 foo.jar：
      // 不归一化会丢掉来源与可更新标记，更新时也找不到记录
      const trackedName = f.fileName.replace(/\.disabled$/i, '');
      const key = trackedName.toLowerCase();
      const claimable = !claimed.has(key) && (!f.disabled || !enabledNames.has(key));
      const match = claimable ? tracked.find(t => t.fileName.toLowerCase() === key) : undefined;
      if (match) claimed.add(key);
      return match ? { ...match, fileName: trackedName, sizeBytes: f.sizeBytes, disabled: f.disabled } : {
        fileName: f.fileName, projectId: null, versionId: null, versionNumber: null, title: null, loader: null,
        installedAt: 0, sizeBytes: f.sizeBytes, disabled: f.disabled, updateAvailable: null,
      };
    });
  });
  ipcMain.handle('modrinth:install', (_e, instanceId: string, projectId: string, versionId: string | null, opts: { loader?: string; gameVersion?: string }) => {
    const inst = instances.getInstance(instanceId);
    return withTask('mod', `安装模组：${projectId}`, () => modrinth.installMod(instanceId, projectId, versionId ?? undefined, opts),
      inst ? { openDir: path.join(inst.gameDir, 'mods') } : undefined);
  });
  ipcMain.handle('modrinth:checkUpdates', (_e, instanceId: string, mcVersion: string, loader?: string) =>
    modrinth.checkModUpdates(instanceId, mcVersion, loader));
  ipcMain.handle('modrinth:updateMod', (_e, instanceId: string, fileName: string) => {
    const inst = instances.getInstance(instanceId);
    return withTask('mod', `更新模组：${fileName}`, () => modrinth.updateMod(instanceId, fileName),
      inst ? { openDir: path.join(inst.gameDir, 'mods') } : undefined);
  });
  ipcMain.handle('modrinth:toggle', (_e, instanceId: string, fileName: string) => modrinth.toggleModDisabled(instanceId, fileName));

  /* ---------- 模组体检 ---------- */
  ipcMain.handle('mods:health', (_e, instanceId: string) => {
    const instance = instances.getInstance(instanceId);
    if (!instance) throw new Error('实例不存在');
    return modhealth.checkModHealth(instanceId, instance.gameDir, instance.loader);
  });
  ipcMain.handle('mods:healthFix', (_e, instanceId: string, target: string) => {
    const instance = instances.getInstance(instanceId);
    if (!instance) throw new Error('实例不存在');
    return modhealth.applyModHealthFix(instanceId, instance.gameDir, target);
  });
  ipcMain.handle('mods:openFolder', (_e, instanceId: string) => {
    const instance = instances.getInstance(instanceId);
    if (!instance) throw new Error('实例不存在');
    return shell.openPath(path.join(instance.gameDir, 'mods'));
  });

  /* ---------- 整合包导入 ---------- */
  ipcMain.handle('modpack:importDialog', async (_e, targetName?: string) => {
    const win = BrowserWindow.getFocusedWindow();
    const result = await dialog.showOpenDialog(win!, {
      properties: ['openFile'],
      title: '选择整合包（.zip）',
      filters: [{ name: '整合包', extensions: ['zip'] }],
    });
    if (result.canceled || !result.filePaths[0]) return null;
    const filePath = result.filePaths[0];
    return withTask('modpack', `导入整合包：${path.basename(filePath)}`,
      () => modpack.importModpack(filePath, targetName, line => sendToAll('modpack:log', line)),
      { openDir: paths.instancesDir(), retry: { type: 'modpack', filePath } });
  });
  ipcMain.handle('modpack:importFile', (_e, filePath: string, targetName?: string) => {
    if (typeof filePath !== 'string' || !filePath) throw new Error('整合包路径无效');
    return withTask('modpack', `导入整合包：${path.basename(filePath)}`,
      () => modpack.importModpack(filePath, targetName, line => sendToAll('modpack:log', line)),
      { openDir: paths.instancesDir(), retry: { type: 'modpack', filePath } });
  });

  /* ---------- 备份 ---------- */
  ipcMain.handle('backup:list', (_e, instanceId: string) => backups.listBackups(instanceId));
  ipcMain.handle('backup:create', (_e, instanceId: string, name?: string) => {
    // 运行中的世界文件仍在写入，手动备份会得到缺区块/半写入的存档
    assertInstanceIdle(instanceId, '创建存档备份');
    return backups.createBackup(instanceId, 'manual', name);
  });
  ipcMain.handle('backup:delete', (_e, backupId: string, instanceId?: string) => { backups.deleteBackup(backupId, instanceId); return true; });
  ipcMain.handle('backup:restore', (_e, backupId: string, instanceId: string) => {
    // 游戏运行中恢复会被游戏进程覆盖，甚至在写存档时损坏世界
    assertInstanceIdle(instanceId, '恢复存档备份');
    return backups.restoreBackup(backupId, instanceId);
  });

  /* ---------- 崩溃分析 ---------- */
  ipcMain.handle('crash:latest', (_e, instanceId: string) => crashService.analyzeCrash(instanceId));
  ipcMain.handle('crash:analyzeText', (_e, text: string) => crashService.analyzeLogText(text));
  ipcMain.handle('crash:fix', async (_e, instanceId: string, fix: CrashFix) => {
    switch (fix.action) {
      case 'fix:setMemoryPreset': {
        const preset = (fix.args?.preset ?? 'heavy') as MemoryPreset;
        instances.updateInstance(instanceId, { memoryPreset: preset });
        return { ok: true, message: `已切换到「${preset === 'heavy' ? '大型整合包/光影' : preset}」内存预设，下次启动生效。` };
      }
      case 'fix:switchJava': {
        const instance = instances.getInstance(instanceId);
        if (!instance) throw new Error('实例不存在');
        // 一键切换必须和启动管线用同一个权威来源：版本 JSON 的 javaVersion.majorVersion
        let major = javaService.recommendedJavaMajor(instance.mcVersion);
        try {
          const settings = getSettings();
          const manifest = await versionService.getVersionManifest(settings.download.source, settings.download.customMirror);
          const entry = manifest.versions.find(v => v.id === instance.mcVersion);
          if (entry) {
            const resolved = await versionService.resolveVersion(entry, settings.download.source, settings.download.customMirror);
            if (Number.isInteger(resolved.javaVersion?.majorVersion)) major = resolved.javaVersion.majorVersion;
          }
        } catch { /* 离线时退回版本号推导 */ }
        const pick = await javaService.pickJavaFor(instance.mcVersion, null, major);
        if (pick.java) {
          instances.updateInstance(instanceId, { javaPath: pick.java.path });
          return { ok: true, message: `已绑定 Java ${pick.java.version}（${pick.java.path}）。` };
        }
        const exe = await javaService.installJava(major, (stage, received, total) => sendToAll('java:progress', { stage, received, total }));
        instances.updateInstance(instanceId, { javaPath: exe });
        return { ok: true, message: `已自动下载并绑定 Java ${major}。` };
      }
      case 'fix:repairLibraries': {
        const result = await minecraft.repairLibraries(instanceId);
        return { ok: true, message: `已检查 ${result.checked} 个文件，修复 ${result.repaired} 个损坏文件${result.failed ? `，${result.failed} 个修复失败` : ''}。` };
      }
      case 'fix:reextractNatives': {
        minecraft.reextractNatives(instanceId);
        return { ok: true, message: '已清理旧的 natives 残留，下次启动将重新提取。' };
      }
      case 'fix:openModsFolder': {
        const instance = instances.getInstance(instanceId);
        if (instance) shell.openPath(path.join(instance.gameDir, 'mods'));
        return { ok: true, message: '已打开 mods 文件夹。' };
      }
      case 'fix:toggleMirror': {
        const settings = getSettings();
        const next = settings.download.source === 'official' ? 'auto' : 'official';
        updateSettings({ download: { ...settings.download, source: next } });
        return { ok: true, message: `下载源已切换为：${next === 'auto' ? '自动（BMCLAPI + 官方兜底）' : '官方源'}。` };
      }
      case 'fix:setUtf8': {
        updateSettings({ launch: { utf8Encoding: true } });
        return { ok: true, message: '已开启强制 UTF-8 编码。' };
      }
      case 'fix:backupThenRestore': {
        const info = await backups.createBackup(instanceId, 'pre-restore', '一键修复前自动备份');
        return { ok: true, message: info ? `已创建备份：${info.name}（${Math.round(info.sizeBytes / 1024 / 1024)} MB）。` : '没有找到存档，已跳过备份。' };
      }
      case 'fix:addOpens': {
        const instance = instances.getInstance(instanceId);
        if (!instance) throw new Error('实例不存在');
        const required = '--add-opens java.base/java.lang=ALL-UNNAMED';
        const current = (instance.jvmArgsExtra ?? '').split(/\s+/).filter(Boolean).join(' ');
        if (!current.includes(required)) {
          instances.updateInstance(instanceId, { jvmArgsExtra: `${current} ${required}`.trim() });
        }
        return { ok: true, message: '已添加模块开放参数，下次启动生效。' };
      }
      case 'fix:disableMod': {
        const instance = instances.getInstance(instanceId);
        if (!instance) throw new Error('实例不存在');
        const modsDir = path.join(instance.gameDir, 'mods');
        const target = fix.args?.file;
        if (target) {
          // 磁盘上的禁用文件名是 foo.jar.disabled：先归一化，避免再次禁用变成 .disabled.disabled
          const base = path.basename(String(target)).replace(/\.disabled$/i, '');
          const enabled = path.join(modsDir, base);
          const disabled = `${enabled}.disabled`;
          if (fs.existsSync(enabled)) {
            if (fs.existsSync(disabled)) {
              return { ok: false, message: `mods 目录同时存在 ${base} 和 ${base}.disabled，请先手动删除一个重复文件。` };
            }
            fs.renameSync(enabled, disabled);
            return { ok: true, message: `已将 ${base} 重命名为 .disabled，下次启动生效。` };
          }
          if (fs.existsSync(disabled)) {
            return { ok: true, message: `${base} 已经是 .disabled。` };
          }
          return { ok: false, message: `在 mods 中找不到 ${base}` };
        }
        // 未指定具体模组：列出当前 mods 目录里全部条目，引导到体检处理
        const files = fs.existsSync(modsDir) ? fs.readdirSync(modsDir).filter(f => f.endsWith('.jar') || f.endsWith('.jar.disabled')) : [];
        return {
          ok: true,
          message: files.length > 0
            ? `mods 目录当前 ${files.length} 个文件：${files.slice(0, 8).join('、')}${files.length > 8 ? '…' : ''}。请用「模组 → 体检」定位问题模组，或告诉 MCL 具体是哪个文件并传参 fix:disableMod + file=<文件名>。`
            : 'mods 目录为空。',
        };
      }
      default:
        return { ok: false, message: '未知的修复动作。' };
    }
  });

  /* ---------- 迁移 ---------- */
  ipcMain.handle('migrate:detect', () => migrate.detectCandidates());
  ipcMain.handle('migrate:preview', (_e, root: string) => migrate.previewMigration(root));
  ipcMain.handle('migrate:import', (_e, root: string, selectedNames?: string[]) => migrate.importInstances(root, selectedNames));

  /* ---------- 日志 ---------- */
  ipcMain.handle('logs:list', (_e, instanceId?: string | null) => logsService.listLogs(instanceId));
  ipcMain.handle('logs:read', (_e, name: string, instanceId?: string | null, maxBytes?: number) => logsService.readLog(name, instanceId, maxBytes));

  /* ---------- 诊断包 ---------- */
  ipcMain.handle('diagnostic:export', (_e, instanceId?: string | null) => diagnostic.exportDiagnostic(instanceId ?? null));

  /* ---------- 服务器管理 ---------- */
  // 同一服务器的启动请求串行化：startServer 内部有多段 await（选 Java、查端口），
  // 连点两次会在检查 child 之前都通过，最终 spawn 出两个抢同一端口的 Java 进程
  const startingServers = new Set<string>();
  ipcMain.handle('server:list', () => serverService.listServers());
  ipcMain.handle('server:get', (_e, id: string) => serverService.getServer(id));
  ipcMain.handle('server:create', (_e, input: any) => serverService.createServer(input));
  ipcMain.handle('server:update', (_e, id: string, patch: any) => serverService.updateServer(id, patch));
  ipcMain.handle('server:delete', (_e, id: string, backup?: boolean) => serverService.deleteServer(id, backup !== false));
  ipcMain.handle('server:prepare', (_e, id: string) => {
    const server = serverService.getServer(id);
    return withTask('server', `安装服务端：${server?.name ?? id}`,
      () => serverService.prepareServer(id), { openDir: paths.serverDir(id) });
  });
  ipcMain.handle('server:start', async (_e, id: string) => {
    if (startingServers.has(id)) throw new Error('服务器正在启动中，请等状态变为「运行中」或报错后再试。');
    startingServers.add(id);
    try { return await serverService.startServer(id); }
    finally { startingServers.delete(id); }
  });
  ipcMain.handle('server:stop', (_e, id: string) => serverService.stopServer(id));
  ipcMain.handle('server:kill', (_e, id: string) => serverService.killServer(id));
  ipcMain.handle('server:sendCommand', (_e, id: string, command: string) => serverService.sendCommand(id, command));
  ipcMain.handle('server:checkPort', (_e, port: number) => serverService.isPortAvailable(port));
  ipcMain.handle('server:acceptEula', (_e, id: string) => serverService.acceptEula(id));
  ipcMain.handle('server:properties', (_e, id: string) => serverService.readServerProperties(id));
  ipcMain.handle('server:saveProperties', (_e, id: string, patch: Record<string, string>) => {
    const nextPatch = { ...patch };
    if (Object.prototype.hasOwnProperty.call(nextPatch, 'server-port')) {
      const port = Number(String(nextPatch['server-port']).trim());
      if (!Number.isInteger(port) || port < 1 || port > 65535) throw new Error('端口必须是 1–65535 之间的整数');
      nextPatch['server-port'] = String(port);
    }
    const saved = serverService.saveServerProperties(id, nextPatch);
    // 属性页直接改端口时同步 server.json，避免设置页显示旧端口
    if (nextPatch['server-port']) {
      const port = Number(nextPatch['server-port']);
      const current = serverService.getServer(id);
      if (current && current.port !== port) serverService.updateServer(id, { port });
    }
    return saved;
  });
  ipcMain.handle('server:log', (_e, id: string, maxLines?: number) => serverService.readServerLog(id, maxLines ?? 400));
  ipcMain.handle('server:openDir', (_e, id: string) => {
    const server = serverService.getServer(id);
    if (!server) throw new Error('服务器不存在');
    return shell.openPath(server.dir);
  });
  ipcMain.handle('server:backups', (_e, id: string) => serverService.listServerBackups(id));
  ipcMain.handle('server:backup', (_e, id: string, name?: string) => serverService.backupServerWorld(id, name));
  ipcMain.handle('server:restoreBackup', (_e, id: string, name: string) => serverService.restoreServerWorld(id, name));
  ipcMain.handle('server:deleteBackup', (_e, id: string, name: string) => { serverService.deleteServerBackup(id, name); return true; });

  /* ---------- 云同步 ---------- */
  ipcMain.handle('cloud:test', () => cloudService.testCloud());
  ipcMain.handle('cloud:inspect', () => cloudService.inspectCloud());
  ipcMain.handle('cloud:upload', () => {
    // 包含存档时才需要拦运行中的游戏；只同步配置时允许游戏开着
    if (getSettings().cloud.includeSaves) assertNoGameBusy('上传含存档的云快照');
    return cloudService.uploadCloud();
  });
  ipcMain.handle('cloud:download', () => {
    assertNoGameBusy('从云端恢复');
    return cloudService.downloadCloud();
  });

  /* ---------- 内容管理 ---------- */
  ipcMain.handle('content:list', (_e, instanceId: string) => contentService.listContent(instanceId));
  // 游戏运行中会在退出/改设置时重写 options.txt 与 iris.properties：
  // 此时从启动器切换开关会被静默覆盖，直接拒绝并提示更可靠
  ipcMain.handle('content:toggleResourcePack', (_e, instanceId: string, fileName: string) => {
    assertInstanceIdle(instanceId, '切换资源包');
    return contentService.toggleResourcePack(instanceId, fileName);
  });
  ipcMain.handle('content:toggleShaderPack', (_e, instanceId: string, fileName: string) => {
    assertInstanceIdle(instanceId, '切换光影包');
    return contentService.toggleShaderPack(instanceId, fileName);
  });
  ipcMain.handle('content:delete', (_e, instanceId: string, kind: any, fileName: string) => {
    // 运行中删除世界会删到游戏正在写入的区块文件，先拒绝
    if (kind === 'worlds') assertInstanceIdle(instanceId, '删除世界');
    return contentService.deleteContent(instanceId, kind, fileName);
  });
  ipcMain.handle('content:backupWorld', (_e, instanceId: string, worldName: string, displayName?: string) => {
    assertInstanceIdle(instanceId, '备份世界');
    return contentService.backupWorld(instanceId, worldName, displayName);
  });
  ipcMain.handle('content:openItem', (_e, p: string) => {
    const root = path.resolve(paths.dataRoot());
    const target = path.resolve(p);
    if (target !== root && !target.startsWith(root + path.sep)) throw new Error('只能打开 MCL 数据目录内的文件');
    return shell.openPath(target);
  });
  ipcMain.handle('content:openFolder', (_e, instanceId: string, kind: any) => {
    const instance = instances.getInstance(instanceId);
    if (!instance) throw new Error('实例不存在');
    const dirs: Record<string, string> = {
      resourcepacks: 'resourcepacks',
      shaderpacks: 'shaderpacks',
      screenshots: 'screenshots',
      worlds: 'saves',
    };
    const sub = dirs[String(kind)];
    if (!sub) throw new Error('未知的内容类型');
    return shell.openPath(path.join(instance.gameDir, sub));
  });
  ipcMain.handle('content:importDialog', async (_e, instanceId: string, kind: any, mode?: 'file' | 'folder') => {
    const win = BrowserWindow.getFocusedWindow();
    if (!win) throw new Error('窗口不可用');
    const isWorld = kind === 'worlds';
    // 运行中导入世界可能与游戏正在写入的同名世界冲突，先拒绝
    if (isWorld) assertInstanceIdle(instanceId, '导入世界');
    // 世界默认选文件夹；传 'file' 则选世界 ZIP
    const wantFolder = mode === 'folder' || (isWorld && mode !== 'file');
    if (wantFolder) {
      const result = await dialog.showOpenDialog(win, {
        properties: ['openDirectory', 'multiSelections'],
        title: isWorld ? '选择要导入的世界文件夹' : '选择要导入的文件夹',
      });
      if (result.canceled || result.filePaths.length === 0) return null;
      return contentService.importContent(instanceId, kind, result.filePaths);
    }
    const filters = kind === 'screenshots'
      ? [{ name: '图片', extensions: ['png', 'jpg', 'jpeg'] }]
      : isWorld
        ? [{ name: '世界存档 ZIP', extensions: ['zip'] }]
        : [{ name: kind === 'shaderpacks' ? '光影包 ZIP' : '资源包 ZIP', extensions: ['zip'] }];
    const result = await dialog.showOpenDialog(win, {
      properties: ['openFile', 'multiSelections'],
      title: kind === 'screenshots' ? '选择要导入的截图' : isWorld ? '选择要导入的世界 ZIP' : '选择要导入的 ZIP',
      filters,
    });
    if (result.canceled || result.filePaths.length === 0) return null;
    return contentService.importContent(instanceId, kind, result.filePaths);
  });
  // 拖放导入：路径来自系统文件拖放，复用与对话框完全相同的校验与导入逻辑
  ipcMain.handle('content:importPaths', (_e, instanceId: string, kind: any, paths: string[]) => {
    if (kind === 'worlds') assertInstanceIdle(instanceId, '导入世界');
    return contentService.importContent(instanceId, kind, Array.isArray(paths) ? paths.filter(p => typeof p === 'string') : []);
  });
  ipcMain.handle('content:exportWorld', async (_e, instanceId: string, worldName: string) => {
    assertInstanceIdle(instanceId, '导出世界');
    const win = BrowserWindow.getFocusedWindow();
    if (!win) throw new Error('窗口不可用');
    const safe = String(worldName).replace(/[<>:"/\\|?*]/g, '_');
    const result = await dialog.showSaveDialog(win, {
      title: '导出世界为 ZIP',
      defaultPath: path.join(app.getPath('downloads'), `${safe}.zip`),
      filters: [{ name: '世界存档 ZIP', extensions: ['zip'] }],
    });
    if (result.canceled || !result.filePath) return null;
    return contentService.exportWorldZip(instanceId, worldName, result.filePath);
  });

  /* ---------- 实例导出 ---------- */
  ipcMain.handle('export:instance', async (_e, instanceId: string, format: any) => {
    const instance = instances.getInstance(instanceId);
    if (!instance) throw new Error('实例不存在');
    if (!['mmc', 'mrpack', 'zip'].includes(String(format))) throw new Error('未知的导出格式');
    // 运行中的存档/日志仍在写入，导出包会带上半写入文件
    assertInstanceIdle(instanceId, '导出实例');
    const defaultName = exporter.defaultExportName(instance, format);
    const win = BrowserWindow.getFocusedWindow();
    const result = await dialog.showSaveDialog(win!, {
      title: '导出实例',
      defaultPath: path.join(app.getPath('downloads'), defaultName),
      filters: [{
        name: format === 'mrpack' ? 'Modrinth 整合包' : 'ZIP 压缩包',
        extensions: [format === 'mrpack' ? 'mrpack' : 'zip'],
      }],
    });
    if (result.canceled || !result.filePath) return null;
    return exporter.exportInstance(instanceId, format, result.filePath);
  });

  /* ---------- 启动器更新 ---------- */
  ipcMain.handle('app:updateCheck', () => updateService.checkUpdate());
  ipcMain.handle('app:updateDownload', async () => {
    const taskId = downloadTasks.begin('update', '下载启动器更新');
    try {
      const result = await updateService.downloadUpdate((done, total) => {
        downloadTasks.progress(taskId, done, total);
        sendToAll('app:updateProgress', { done, total });
      });
      downloadTasks.done(taskId, { revealFile: result.filePath, retry: { type: 'update' } });
      return result;
    } catch (e) {
      downloadTasks.fail(taskId, errorReason(e), { retry: { type: 'update' } });
      throw e;
    }
  });
  ipcMain.handle('app:revealFile', (_e, filePath: string) => {
    if (typeof filePath !== 'string' || !filePath) return false;
    shell.showItemInFolder(path.resolve(filePath));
    return true;
  });

  /* ---------- 局域网世界 ---------- */
  ipcMain.handle('lan:scan', (_e, timeoutMs?: number) => lanService.scanLanWorlds(timeoutMs));

  /* ---------- 缓存清理 ---------- */
  const measureDir = (dir: string): { sizeBytes: number; files: number } => {
    let sizeBytes = 0;
    let files = 0;
    const walk = (d: string) => {
      let entries: fs.Dirent[] = [];
      try { entries = fs.readdirSync(d, { withFileTypes: true }); } catch { return; }
      for (const e of entries) {
        const full = path.join(d, e.name);
        if (e.isDirectory()) walk(full);
        else { try { sizeBytes += fs.statSync(full).size; files++; } catch { /* ignore */ } }
      }
    };
    walk(dir);
    return { sizeBytes, files };
  };
  ipcMain.handle('app:cacheInfo', () => ({ dir: paths.cacheDir(), ...measureDir(paths.cacheDir()) }));
  ipcMain.handle('app:clearCache', () => {
    // 正在下载时缓存里有 .part 分段，直接清掉会让本次启动/安装失败或从头再来
    if (['preparing', 'downloading', 'launching'].includes(minecraft.launchState.status)) {
      throw new Error('游戏正在下载/准备，清理缓存会打断本次启动。请等启动完成后再试。');
    }
    if (serverService.listServers().some(s => s.status === 'preparing')) {
      throw new Error('有服务器正在安装，清理缓存会打断安装。请等安装完成后再试。');
    }
    const dir = paths.cacheDir();
    const before = measureDir(dir);
    if (fs.existsSync(dir)) {
      for (const name of fs.readdirSync(dir)) {
        fs.rmSync(path.join(dir, name), { recursive: true, force: true });
      }
    }
    return { freedBytes: before.sizeBytes, removedFiles: before.files };
  });

  /* ---------- 下载源测速 ---------- */
  ipcMain.handle('mirror:test', async () => {
    const { pickBestSource } = await import('./net');
    return pickBestSource(getSettings().download.customMirror);
  });

  /* ---------- 下载任务中心 ---------- */
  ipcMain.handle('tasks:list', () => downloadTasks.list());
  ipcMain.handle('tasks:clearFinished', () => { downloadTasks.clearFinished(); return true; });
  ipcMain.handle('tasks:remove', (_e, id: string) => { downloadTasks.remove(String(id ?? '')); return true; });
  ipcMain.handle('tasks:cancel', (_e, id: string) => { downloadTasks.cancel(String(id ?? '')); return true; });

  /* ---------- 游玩统计 ---------- */
  ipcMain.handle('stats:play', () => instances.getPlayStats());

  /* ---------- 游戏设置可视化（options.txt 白名单） ---------- */
  ipcMain.handle('content:optionsRead', (_e, instanceId: string) => contentService.readGameOptions(instanceId));
  ipcMain.handle('content:optionsSave', (_e, instanceId: string, patch: Record<string, string>) => {
    // 运行时游戏会重写 options.txt：此时保存会被静默覆盖，直接拒绝更可靠
    assertInstanceIdle(instanceId, '修改游戏设置');
    return contentService.saveGameOptions(instanceId, patch);
  });
}
