/**
 * 从其它启动器迁移（痛点 #45/#46/#48）：扫描 HMCL / PCL2 / Prism / MultiMC / .minecraft
 * 只复制存档/模组/配置等"用户数据"，库与资源交给 MCL 的共享目录重新按需下载
 */
import * as fs from 'fs';
import * as path from 'path';
import * as os from 'os';
import * as paths from './paths';
import { createInstance, deleteInstance } from './instances';
import { MigrationCandidate, MigrationPreview, MigrationResult, LoaderType } from '../shared/types';
import { getSettings } from './settings';

const roaming = () => process.env.APPDATA ?? path.join(os.homedir(), 'AppData', 'Roaming');

export function detectCandidates(): MigrationCandidate[] {
  const candidates: MigrationCandidate[] = [
    { launcher: 'HMCL', path: path.join(roaming(), '.hmcl'), exists: false, hint: 'HMCL 默认数据目录（版本隔离时各版本在对应目录下）' },
    { launcher: 'PCL2 / 官方启动器（.minecraft）', path: path.join(roaming(), '.minecraft'), exists: false, hint: 'PCL2 默认数据目录（共享。含 versions/ 时为版本隔离）' },
    { launcher: 'Prism Launcher', path: path.join(roaming(), 'PrismLauncher'), exists: false, hint: 'Prism 默认数据目录（实例在 instances/ 下）' },
    { launcher: 'MultiMC', path: path.join(roaming(), 'MultiMC'), exists: false, hint: 'MultiMC 默认数据目录' },
    { launcher: 'ATLauncher', path: path.join(roaming(), 'ATLauncher'), exists: false, hint: 'ATLauncher 数据目录' },
    { launcher: 'PCL2 CE（自定义目录）', path: path.join(roaming(), 'PCL'), exists: false, hint: '若 PCL 使用独立数据目录也可手动选择' },
  ];
  for (const c of candidates) c.exists = fs.existsSync(c.path);
  return candidates;
}

interface FoundInstance { name: string; gameDir: string; mcVersion: string | null; loader: LoaderType; loaderVersion: string | null }

function looksLikeGameDir(dir: string): boolean {
  try {
    const names = fs.readdirSync(dir);
    return names.includes('saves') || names.includes('mods') || names.includes('version_manifest_v2.json') || names.includes('libraries');
  } catch { return false; }
}

/** 扫描数据根目录，找出所有"实例" */
function scanInstances(root: string): FoundInstance[] {
  const out: FoundInstance[] = [];
  const rootType = path.basename(root).toLowerCase();

  // Prism / MultiMC：instances/<名字>/.minecraft 或 instances/<名字>/minecraft
  const prismInstances = path.join(root, 'instances');
  if (fs.existsSync(prismInstances)) {
    for (const e of fs.readdirSync(prismInstances, { withFileTypes: true })) {
      if (!e.isDirectory()) continue;
      const instDir = path.join(prismInstances, e.name);
      const candidate = [path.join(instDir, '.minecraft'), path.join(instDir, 'minecraft')].find(looksLikeGameDir);
      if (candidate) {
        const pack = readPackLoaderInfo(instDir);
        out.push({ name: e.name, gameDir: candidate, mcVersion: readPackVersion(instDir), loader: pack.loader, loaderVersion: pack.loaderVersion });
      } else if (looksLikeGameDir(instDir)) {
        out.push({ name: e.name, gameDir: instDir, mcVersion: null, loader: 'vanilla', loaderVersion: null });
      }
    }
    return out;
  }

  // .minecraft 布局（PCL2/HMCL/官方）
  // 1) 版本隔离：versions/<版本名>/（存档直接在版本目录内）
  const versionsDir = path.join(root, 'versions');
  if (fs.existsSync(versionsDir)) {
    for (const e of fs.readdirSync(versionsDir, { withFileTypes: true })) {
      if (!e.isDirectory()) continue;
      const vdir = path.join(versionsDir, e.name);
      if (looksLikeGameDir(vdir)) {
        const parsed = parseVersionName(e.name);
        // 目录名拿不到 MC 版本时，读版本 json 的 inheritsFrom（Forge 等）兜底
        const mcVersion = parsed.mcVersion ?? readMcVersionFromJson(vdir, e.name);
        out.push({ name: e.name, gameDir: vdir, mcVersion, loader: parsed.loader, loaderVersion: parsed.loaderVersion });
      }
    }
  }
  // 2) 根目录本身就是游戏目录（未开隔离）
  if (looksLikeGameDir(root) && fs.readdirSync(root).some(n => ['saves', 'mods', 'config'].includes(n))) {
    out.push({ name: rootType === '.minecraft' ? '.minecraft 默认实例' : path.basename(root), gameDir: root, mcVersion: detectMcVersionFromLibraries(root), loader: 'vanilla', loaderVersion: null });
  }
  return out;
}

/** Prism/MultiMC：从 mmc-pack.json 或 inplace 实例读版本 */
function readPackVersion(instDir: string): string | null {
  const pack = path.join(instDir, 'mmc-pack.json');
  try {
    if (fs.existsSync(pack)) {
      const json = JSON.parse(fs.readFileSync(pack, 'utf8'));
      const mc = (json?.components ?? []).find((c: any) => c?.uid === 'net.minecraft');
      return mc?.version ?? null;
    }
  } catch { /* ignore */ }
  return null;
}

/** Prism/MultiMC：从 mmc-pack.json 的组件读取加载器类型与精确版本 */
function readPackLoaderInfo(instDir: string): { loader: LoaderType; loaderVersion: string | null } {
  try {
    const file = path.join(instDir, 'mmc-pack.json');
    if (fs.existsSync(file)) {
      const json = JSON.parse(fs.readFileSync(file, 'utf8'));
      const components = (json?.components ?? []) as Array<{ uid?: string; version?: string }>;
      const find = (uid: string) => components.find(c => String(c?.uid ?? '') === uid);
      const fabric = find('net.fabricmc.fabric-loader');
      if (fabric) return { loader: 'fabric', loaderVersion: fabric.version ?? null };
      const quilt = find('org.quiltmc.quilt-loader');
      if (quilt) return { loader: 'quilt', loaderVersion: quilt.version ?? null };
      const forge = find('net.minecraftforge');
      if (forge) return { loader: 'forge', loaderVersion: forge.version ?? null };
      const neo = find('net.neoforged');
      if (neo) return { loader: 'neoforge', loaderVersion: neo.version ?? null };
    }
  } catch { /* ignore */ }
  return { loader: 'vanilla', loaderVersion: null };
}

/** 按语义版本比较两个版本号（越大越新） */
export function compareMcVersions(a: string, b: string): number {
  const pa = String(a).split('.').map(x => parseInt(x, 10) || 0);
  const pb = String(b).split('.').map(x => parseInt(x, 10) || 0);
  for (let i = 0; i < Math.max(pa.length, pb.length); i++) {
    const d = (pa[i] ?? 0) - (pb[i] ?? 0);
    if (d !== 0) return d;
  }
  return 0;
}

/**
 * 从目录名解析 MC 版本 / 加载器：
 *   1.20.1                            → mc 1.20.1, vanilla
 *   fabric-loader-0.15.7-1.20.4        → mc 1.20.4, fabric 0.15.7
 *   quilt-loader-0.23.1-1.20.1         → mc 1.20.1, quilt 0.23.1
 *   1.20.1-forge-47.2.0 / forge-1.20.1-47.2.0 → mc 1.20.1, forge 47.2.0
 *   neoforge-21.1.73                   → mc 无法从名字确定（null），neoforge 21.1.73
 */
export function parseVersionName(name: string): { mcVersion: string | null; loader: LoaderType; loaderVersion: string | null } {
  const lower = name.toLowerCase();
  const loader: LoaderType =
    lower.includes('neoforge') ? 'neoforge'
    : lower.includes('forge') ? 'forge'
    : lower.includes('fabric') ? 'fabric'
    : lower.includes('quilt') ? 'quilt'
    : 'vanilla';

  const tokens = name.split(/[-_\s]/).filter(Boolean);
  // MC 版本：1.x.y 或 1.x；排除 loader 版本（它们不以 1. 开头，除非恰好）
  const mcToken = tokens.find(t => /^1\.\d+(\.\d+)?$/.test(t)) ?? null;

  let loaderVersion: string | null = null;
  // 先剥掉 MC 版本，避免 forge-1.20.1-47.2.0 把 1.20.1 误当成加载器版本
  const rest = mcToken ? name.split(mcToken).join('-') : name;
  const grab = (re: RegExp) => { const m = rest.match(re); return m?.[1] ?? null; };
  if (loader === 'forge') loaderVersion = grab(/forge[-_\s]+([\d.]+)/i);
  else if (loader === 'neoforge') loaderVersion = grab(/neoforge[-_\s]+([\d.]+)/i);
  else if (loader === 'fabric') loaderVersion = grab(/fabric[-_]?loader[-_]([\d.]+)/i) ?? grab(/fabric[-_]([\d.]+)/i);
  else if (loader === 'quilt') loaderVersion = grab(/quilt[-_]?loader[-_]([\d.]+)/i) ?? grab(/quilt[-_]([\d.]+)/i);

  return { mcVersion: mcToken, loader, loaderVersion };
}

/** 从版本 json 精确读取 MC 版本（inheritsFrom 或 id），失败返回 null */
function readMcVersionFromJson(versionDir: string, dirName: string): string | null {
  const candidates = [`${dirName}.json`, dirName.endsWith('.json') ? dirName : `${dirName}-client.json`];
  for (const c of candidates) {
    try {
      const file = path.join(versionDir, c);
      if (!fs.existsSync(file)) continue;
      const json = JSON.parse(fs.readFileSync(file, 'utf8'));
      if (typeof json.inheritsFrom === 'string') return json.inheritsFrom;   // Forge 等：父版本就是 MC 版本
      if (typeof json.id === 'string') {
        const m = json.id.match(/^1\.\d+(\.\d+)?/);
        if (m) return m[0];
      }
    } catch { /* 忽略损坏的 json */ }
  }
  return null;
}

function detectMcVersionFromLibraries(root: string): string | null {
  // 语义版本取最高：先剥离 loader 前缀，再按数字比较（1.20.1 > 1.9）
  const versions = path.join(root, 'versions');
  try {
    if (fs.existsSync(versions)) {
      const candidates = fs.readdirSync(versions)
        .map(n => parseVersionName(n).mcVersion ?? readMcVersionFromJson(path.join(versions, n), n))
        .filter((v): v is string => !!v);
      if (candidates.length) return candidates.sort(compareMcVersions).pop()!;
    }
  } catch { /* ignore */ }
  return null;
}

const COPY_DIRS = ['saves', 'mods', 'config', 'resourcepacks', 'shaderpacks', 'screenshots', 'xaero', 'journeymap', 'minimap', 'schematics'];
const COPY_FILES = ['options.txt', 'servers.dat', 'keybinds.txt', 'realms_persistence.json'];

export function previewMigration(root: string): MigrationPreview {
  const found = scanInstances(root);
  const instances = found.map(f => {
    let totalBytes = 0;
    let saves: string[] = [];
    let modsCount = 0;
    let configFiles = 0;
    try { saves = fs.existsSync(path.join(f.gameDir, 'saves')) ? fs.readdirSync(path.join(f.gameDir, 'saves')).filter(d => { try { return fs.statSync(path.join(f.gameDir, 'saves', d)).isDirectory(); } catch { return false; } }) : []; } catch { saves = []; }
    try { modsCount = fs.existsSync(path.join(f.gameDir, 'mods')) ? fs.readdirSync(path.join(f.gameDir, 'mods')).filter(n => n.endsWith('.jar')).length : 0; } catch { modsCount = 0; }
    const countDir = (dir: string): number => {
      let total = 0;
      const walk = (d: string) => { for (const e of fs.readdirSync(d, { withFileTypes: true })) { const full = path.join(d, e.name); if (e.isDirectory()) walk(full); else { try { total += fs.statSync(full).size; } catch { /* skip */ } } } };
      try { walk(dir); } catch { /* skip */ }
      return total;
    };
    try { totalBytes = countDir(f.gameDir); } catch { totalBytes = 0; }
    try { configFiles = fs.existsSync(path.join(f.gameDir, 'config')) ? fs.readdirSync(path.join(f.gameDir, 'config')).length : 0; } catch { configFiles = 0; }
    return { name: f.name, mcVersion: f.mcVersion, loader: f.loader, loaderVersion: f.loaderVersion, saves, modsCount, configFiles, totalBytes };
  });
  return { path: root, instances };
}

export function importInstances(root: string, selectedNames?: string[]): MigrationResult {
  const found = scanInstances(root);
  const selected = selectedNames?.length ? found.filter(f => selectedNames.includes(f.name)) : found;
  const imported: string[] = [];
  const skipped: Array<{ name: string; reason: string }> = [];
  const warnings: string[] = [];
  const copyInsteadOfMove = getSettings().migration.copyInsteadOfMove;

  for (const f of selected) {
    let createdId: string | null = null;
    // 移动模式下记录是否已经真正移动过文件：一旦移动过，失败时不能删实例（会毁掉唯一副本）
    const moveState = { moved: false };
    try {
      if (!f.mcVersion) {
        warnings.push(`实例「${f.name}」未识别 MC 版本（无版本 json），已按"未识别"导入——请在「实例」页手动选择版本后再启动。`);
      }
      const cfg = createInstance({
        name: f.name.slice(0, 60),
        mcVersion: f.mcVersion ?? 'unknown',
        loader: f.loader,
        loaderVersion: f.loaderVersion,
        memoryPreset: 'standard',
      });
      createdId = cfg.id;
      const dest = paths.gameDir(cfg.id);
      for (const dir of COPY_DIRS) {
        const src = path.join(f.gameDir, dir);
        if (fs.existsSync(src)) copyRecursive(src, path.join(dest, dir), copyInsteadOfMove, moveState);
      }
      for (const file of COPY_FILES) {
        const src = path.join(f.gameDir, file);
        if (!fs.existsSync(src)) continue;
        const target = path.join(dest, file);
        if (copyInsteadOfMove) {
          fs.copyFileSync(src, target);
        } else {
          moveFile(src, target);
          moveState.moved = true;
        }
      }
      imported.push(f.name);
    } catch (e) {
      // 复制模式失败：删除半成品实例；移动模式已搬走文件则保留，避免数据丢失
      if (createdId) {
        if (!copyInsteadOfMove && moveState.moved) {
          warnings.push(`实例「${f.name}」导入中断，已移动的文件保留在 MCL 实例中，请检查后决定是否删除。`);
        } else {
          try { deleteInstance(createdId); } catch { /* 清理失败不覆盖原始错误 */ }
        }
      }
      skipped.push({ name: f.name, reason: e instanceof Error ? e.message : String(e) });
    }
  }
  return { imported, skipped, warnings };
}

function moveFile(src: string, dest: string): void {
  try {
    fs.renameSync(src, dest);
  } catch (e) {
    // rename 跨盘符会抛 EXDEV：退化为复制后删除源文件
    if ((e as NodeJS.ErrnoException).code !== 'EXDEV') throw e;
    fs.copyFileSync(src, dest);
    fs.rmSync(src, { force: true });
  }
}

function copyRecursive(src: string, dest: string, copy: boolean, moveState: { moved: boolean }): void {
  fs.mkdirSync(dest, { recursive: true });
  for (const entry of fs.readdirSync(src, { withFileTypes: true })) {
    const s = path.join(src, entry.name);
    const d = path.join(dest, entry.name);
    if (entry.isDirectory()) copyRecursive(s, d, copy, moveState);
    else {
      if (copy) {
        fs.copyFileSync(s, d);
      } else {
        moveFile(s, d);
        moveState.moved = true;
      }
    }
  }
}
