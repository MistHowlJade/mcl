/* 临时预览配置：只在浏览器里跑渲染层，不影响正式构建 */
import { defineConfig } from 'vite';
import react from '@vitejs/plugin-react';
import { resolve, dirname } from 'path';
import { fileURLToPath } from 'url';
import fs from 'fs';

const dir = dirname(fileURLToPath(import.meta.url));
const mock = fs.readFileSync(resolve(dir, '.preview-mock.js'), 'utf8');

export default defineConfig({
  root: 'src',
  base: './',
  publicDir: resolve(dir, 'public'),
  plugins: [
    react(),
    {
      name: 'mcl-preview-mock',
      transformIndexHtml(html) {
        return html.replace(
          '<script type="module" src="/main.tsx"></script>',
          `<script>\n${mock}\n</script>\n  <script type="module" src="/main.tsx"></script>`
        );
      },
    },
  ],
  server: {
    host: '0.0.0.0',
    port: 5173,
    strictPort: true,
    allowedHosts: true,
  },
});
