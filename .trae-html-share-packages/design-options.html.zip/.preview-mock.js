/* 临时预览 Mock：仅用于浏览器预览，不属于生产代码 */
(() => {
  const now = Date.now();
  const day = 86400000;
  const hour = 3600000;
  const iso = (offset) => new Date(now - offset).toISOString().slice(0, 10);

  const instances = [
    {
      id: 'inst-abyss', name: '深渊生存 · 长期档', mcVersion: '1.20.1', loader: 'fabric', loaderVersion: '0.15.11',
      memoryPreset: 'heavy', heapInitialMB: null, heapMaxMB: null, jvmArgsExtra: '', noModUpdate: false,
      tags: ['整合包', '长期档'], favorite: true, resolution: { width: 1920, height: 1080 },
      createdAt: now - 120 * day, lastPlayedAt: now - 2 * hour, playTimeSeconds: 186120,
      gameDir: 'C:\\MCL\\mcl-data\\instances\\inst-abyss\\game', modsCount: 42, savesCount: 3, lastCrashAt: now - 9 * day,
    },
    {
      id: 'inst-create', name: 'Create 机械 1.18.2', mcVersion: '1.18.2', loader: 'forge', loaderVersion: '40.2.17',
      memoryPreset: 'standard', noModUpdate: true, tags: ['机械', '模组'], favorite: true,
      createdAt: now - 200 * day, lastPlayedAt: now - 5 * day, playTimeSeconds: 501840,
      gameDir: 'C:\\MCL\\mcl-data\\instances\\inst-create\\game', modsCount: 128, savesCount: 6,
    },
    {
      id: 'inst-vanilla', name: '纯净测试 1.21', mcVersion: '1.21', loader: 'vanilla', loaderVersion: null,
      memoryPreset: 'low', tags: ['纯净'], favorite: false,
      createdAt: now - 30 * day, lastPlayedAt: now - 2 * day, playTimeSeconds: 14400,
      gameDir: 'C:\\MCL\\mcl-data\\instances\\inst-vanilla\\game', modsCount: 0, savesCount: 1,
    },
    {
      id: 'inst-neo', name: 'NeoForge 实验场', mcVersion: '1.20.4', loader: 'neoforge', loaderVersion: '20.4.237',
      memoryPreset: 'standard', tags: ['模组'], favorite: false,
      createdAt: now - 60 * day, lastPlayedAt: now - 8 * day, playTimeSeconds: 7200,
      gameDir: 'C:\\MCL\\mcl-data\\instances\\inst-neo\\game', modsCount: 15, savesCount: 0,
    },
    {
      id: 'inst-quilt', name: 'Quilt 轻量整合', mcVersion: '1.19.4', loader: 'quilt', loaderVersion: '0.23.1',
      memoryPreset: 'standard', tags: ['整合包', '轻量'], favorite: false,
      createdAt: now - 150 * day, lastPlayedAt: now - 14 * day, playTimeSeconds: 20880,
      gameDir: 'C:\\MCL\\mcl-data\\instances\\inst-quilt\\game', modsCount: 8, savesCount: 2,
    },
    {
      id: 'inst-old', name: '远古整合包', mcVersion: 'unknown', loader: 'forge', loaderVersion: null,
      memoryPreset: 'low', tags: ['怀旧'], favorite: false,
      createdAt: now - 300 * day, lastPlayedAt: null, playTimeSeconds: 0,
      gameDir: 'C:\\MCL\\mcl-data\\instances\\inst-old\\game', modsCount: 64, savesCount: 0,
    },
  ];

  const accounts = [
    { id: 'acc-jade', type: 'offline', name: 'Jade', uuid: '0f1e2d3c-4b5a-6978-8796-a5b4c3d2e1f0', skinUrl: null, capeUrl: null, lastUsedAt: now - hour },
    { id: 'acc-steve', type: 'microsoft', name: 'Steve_CN', uuid: '1a2b3c4d-5e6f-7081-92a3-b4c5d6e7f809', skinUrl: null, capeUrl: null, skinModel: 'classic', expiresAt: now + 20 * day, lastUsedAt: now - 20 * day },
  ];

  const settings = {
    general: { zoomFactor: 1, autoBackupBeforeLaunch: true, backupKeep: 10, confirmBeforeLaunch: false, defaultResolution: { width: 1280, height: 720 } },
    download: { source: 'auto', customMirror: '', maxThreads: 16, segmentSizeMB: 8, timeoutMs: 20000, retries: 3 },
    java: { defaultPath: '' },
    launch: { autoKillResidual: true, log4jFix: true, utf8Encoding: true, showLogOnCrash: true, globalJvmArgs: '' },
    curseforge: { apiKey: '' },
    migration: { copyInsteadOfMove: true },
    network: { proxyMode: 'off', proxyUrl: '', proxyUsername: '', proxyPassword: '', applyToDownloads: true, applyToGame: true },
    cloud: { provider: 'webdav', webdavUrl: 'https://dav.example.com/mcl/', webdavUsername: 'jade', webdavPassword: '******', gistToken: '', gistId: '', includeSaves: false, lastSyncAt: now - day, lastSyncDirection: 'upload' },
  };

  const playStats = {
    daily: [
      { date: iso(6 * day), seconds: 5400 }, { date: iso(5 * day), seconds: 0 }, { date: iso(4 * day), seconds: 12600 },
      { date: iso(3 * day), seconds: 3600 }, { date: iso(2 * day), seconds: 21600 }, { date: iso(day), seconds: 7200 },
      { date: iso(0), seconds: 9000 },
    ],
    totalSeconds: 734400, sessions: 96,
    perInstance: [
      { instanceId: 'inst-create', name: 'Create 机械 1.18.2', seconds: 501840 },
      { instanceId: 'inst-abyss', name: '深渊生存 · 长期档', seconds: 186120 },
      { instanceId: 'inst-quilt', name: 'Quilt 轻量整合', seconds: 20880 },
    ],
  };

  const servers = [
    {
      id: 'srv-friends', name: '好友生存服', mcVersion: '1.20.1', loader: 'fabric', loaderVersion: '0.15.11',
      port: 25565, memoryMB: 4096, eulaAccepted: true, prepared: true, createdAt: now - 80 * day, lastStartedAt: now - 3 * hour,
      dir: 'C:\\MCL\\mcl-data\\servers\\srv-friends', status: 'running', pid: 4242, startedAt: now - 3 * hour,
      players: ['Jade', 'Alex'], online: true, diskBytes: 2576980377,
      logTail: ['[12:01:02] [Server thread/INFO]: Starting minecraft server version 1.20.1', '[12:01:08] [Server thread/INFO]: Done (5.812s)! For help, type "help"'],
    },
    {
      id: 'srv-creative', name: '创造服（测试）', mcVersion: '1.21', loader: 'vanilla', loaderVersion: null,
      port: 25566, memoryMB: 2048, eulaAccepted: true, prepared: true, createdAt: now - 40 * day, lastStartedAt: now - 5 * day,
      dir: 'C:\\MCL\\mcl-data\\servers\\srv-creative', status: 'stopped', pid: null, players: [], online: false, diskBytes: 734003200, logTail: [],
    },
    {
      id: 'srv-modpack', name: '整合包服', mcVersion: '1.19.2', loader: 'forge', loaderVersion: '43.3.0',
      port: 25567, memoryMB: 6144, eulaAccepted: false, prepared: false, createdAt: now - 12 * day, lastStartedAt: null,
      dir: 'C:\\MCL\\mcl-data\\servers\\srv-modpack', status: 'stopped', pid: null, players: [], online: false, diskBytes: 1073741824, logTail: [],
    },
  ];

  const content = {
    resourcepacks: [
      { name: 'Faithful 32x', fileName: 'Faithful32x.zip', path: 'C:\\MCL\\mcl-data\\instances\\inst-abyss\\game\\resourcepacks\\Faithful32x.zip', sizeBytes: 52428800, mtime: now - 20 * day, enabled: true },
      { name: 'Stay True', fileName: 'StayTrue.zip', path: 'C:\\MCL\\mcl-data\\instances\\inst-abyss\\game\\resourcepacks\\StayTrue.zip', sizeBytes: 18874368, mtime: now - 40 * day, enabled: false },
    ],
    shaderpacks: [
      { name: 'Complementary Reimagined', fileName: 'ComplementaryReimagined.zip', path: 'C:\\MCL\\mcl-data\\instances\\inst-abyss\\game\\shaderpacks\\ComplementaryReimagined.zip', sizeBytes: 10485760, mtime: now - 10 * day, enabled: true },
    ],
    screenshots: [
      { name: '2026-11-21_22.13.08.png', fileName: '2026-11-21_22.13.08.png', path: 'C:\\MCL\\mcl-data\\instances\\inst-abyss\\game\\screenshots\\2026-11-21_22.13.08.png', sizeBytes: 2097152, mtime: now - 2 * day, previewPath: null },
      { name: '2026-11-18_19.02.41.png', fileName: '2026-11-18_19.02.41.png', path: 'C:\\MCL\\mcl-data\\instances\\inst-abyss\\game\\screenshots\\2026-11-18_19.02.41.png', sizeBytes: 1887436, mtime: now - 5 * day, previewPath: null },
    ],
    worlds: [
      { name: '深渊生存', fileName: '深渊生存', path: 'C:\\MCL\\mcl-data\\instances\\inst-abyss\\game\\saves\\深渊生存', sizeBytes: 734003200, mtime: now - 2 * hour, previewPath: null },
      { name: '创造测试', fileName: '创造测试', path: 'C:\\MCL\\mcl-data\\instances\\inst-abyss\\game\\saves\\创造测试', sizeBytes: 104857600, mtime: now - 20 * day, previewPath: null },
    ],
  };

  const backups = [
    { id: 'bk-1', instanceId: 'inst-abyss', name: '启动前自动备份', filePath: 'C:\\MCL\\mcl-data\\backups\\abyss-1.zip', sizeBytes: 658505728, createdAt: now - 2 * hour, kind: 'auto', worldNames: ['深渊生存'] },
    { id: 'bk-2', instanceId: 'inst-abyss', name: '手动备份 · 打龙前', filePath: 'C:\\MCL\\mcl-data\\backups\\abyss-2.zip', sizeBytes: 641728512, createdAt: now - 3 * day, kind: 'manual', worldNames: ['深渊生存'] },
    { id: 'bk-3', instanceId: 'inst-create', name: '启动前自动备份', filePath: 'C:\\MCL\\mcl-data\\backups\\create-1.zip', sizeBytes: 943718400, createdAt: now - 5 * day, kind: 'auto', worldNames: ['Create 工厂', '测试世界'] },
  ];

  const installedMods = [
    { fileName: 'sodium-fabric-0.5.11.jar', projectId: 'AANobbMI', versionId: 'v1', versionNumber: '0.5.11', title: 'Sodium', loader: 'fabric', installedAt: now - 30 * day, sizeBytes: 1048576, disabled: false, updateAvailable: { versionNumber: '0.5.12', fileUrl: '', versionId: 'v2' } },
    { fileName: 'iris-1.7.3.jar', projectId: 'YL57xq9U', versionId: 'v3', versionNumber: '1.7.3', title: 'Iris Shaders', loader: 'fabric', installedAt: now - 30 * day, sizeBytes: 2097152, disabled: false, updateAvailable: null },
    { fileName: 'modmenu-11.0.1.jar', projectId: 'mOgUt4GM', versionId: 'v4', versionNumber: '11.0.1', title: 'Mod Menu', loader: 'fabric', installedAt: now - 30 * day, sizeBytes: 512000, disabled: false, updateAvailable: null },
  ];

  const projects = [
    { projectId: 'AANobbMI', slug: 'sodium', title: 'Sodium', description: '现代渲染优化模组，大幅提升帧率并减少卡顿。', iconUrl: null, author: 'CaffeineMC', downloads: 48200000, follows: 12800, categories: ['optimization'], gameVersions: ['1.20.1', '1.20.4', '1.21'], loaders: ['fabric', 'quilt'] },
    { projectId: 'LNytGWDc', slug: 'create', title: 'Create', description: '机械动力：建造旋转机械、自动化工厂与列车系统。', iconUrl: null, author: 'simibubi', downloads: 21500000, follows: 9600, categories: ['technology'], gameVersions: ['1.18.2', '1.19.2', '1.20.1'], loaders: ['forge', 'neoforge'] },
    { projectId: 'YL57xq9U', slug: 'iris', title: 'Iris Shaders', description: '兼容 OptiFine 光影包的高性能光影加载器。', iconUrl: null, author: 'IrisShaders', downloads: 15600000, follows: 7400, categories: ['shaders'], gameVersions: ['1.20.1', '1.21'], loaders: ['fabric'] },
    { projectId: 'u6dRKJwZ', slug: 'jei', title: 'Just Enough Items', description: '物品与合成配方速查，整合包必备。', iconUrl: null, author: 'mezz', downloads: 31000000, follows: 8100, categories: ['utility'], gameVersions: ['1.18.2', '1.20.1', '1.21'], loaders: ['forge', 'fabric', 'neoforge'] },
    { projectId: '1KVo5zza', slug: 'fabulously-optimized', title: 'Fabulously Optimized', description: '开箱即用的轻量优化整合包，帧率翻倍。', iconUrl: null, author: 'robotkoer', downloads: 9800000, follows: 4200, categories: ['optimization', 'modpack'], gameVersions: ['1.20.1', '1.21'], loaders: ['fabric'] },
    { projectId: '9eGKb6K1', slug: 'simple-voice-chat', title: 'Simple Voice Chat', description: '近距离语音聊天，开服联机更有代入感。', iconUrl: null, author: 'henkelmax', downloads: 7200000, follows: 3900, categories: ['social'], gameVersions: ['1.20.1', '1.20.4', '1.21'], loaders: ['fabric', 'forge', 'neoforge'] },
  ];

  const logs = [
    { name: 'latest.log', sizeBytes: 482000, mtime: now - 2 * hour, kind: 'game' },
    { name: '2026-11-21-3.log.gz', sizeBytes: 128000, mtime: now - 2 * day, kind: 'game' },
    { name: 'launcher.log', sizeBytes: 96000, mtime: now - hour, kind: 'launcher' },
  ];

  const sampleLog = `[12:00:01] [main/INFO]: Loading Minecraft 1.20.1 with Fabric Loader 0.15.11
[12:00:02] [main/INFO]: Loading 42 mods:
\t- fabric-api 0.92.2
\t- sodium 0.5.11
\t- iris 1.7.3
[12:00:08] [Render thread/INFO]: OpenGL debug message
[12:00:09] [Render thread/INFO]: Backend library: LWJGL version 3.3.2
[12:00:12] [Render thread/INFO]: Sound engine started
[12:00:13] [Render thread/INFO]: Created: 1024x512x4 minecraft:textures/atlas/blocks.png-atlas
[12:00:14] [Render thread/INFO]: Narrator library for x64 successfully loaded
[12:00:15] [Render thread/INFO]: Reloading ResourceManager: vanilla, fabric
[12:00:16] [Server thread/INFO]: Starting integrated minecraft server
[12:00:20] [Server thread/INFO]: Done (3.914s)! For help, type "help"`;

  const crash = {
    matched: true, normal: false, ruleId: 'out-of-memory',
    title: '游戏内存不足',
    summary: '游戏在加载世界时耗尽了内存。常见于大型整合包或光影 + 高视距，把内存预设调到「大型整合包·光影」通常就能解决。',
    detail: 'java.lang.OutOfMemoryError: Java heap space\n\tat net.minecraft.client.renderer.chunk.RenderChunk.rebuild(RenderChunk.java:142)',
    fixes: [
      { id: 'fix-mem', label: '切换到 8G 内存预设', description: '把该实例的内存预设改为「大型整合包·光影」（-Xmx8G）', action: 'fix:setMemoryPreset', args: { preset: 'heavy' }, severity: 'high' },
      { id: 'fix-mods', label: '打开模组目录', description: '移除不兼容或重复的模组后再试', action: 'fix:openModsFolder', severity: 'medium' },
    ],
    sourceFile: 'C:\\MCL\\mcl-data\\instances\\inst-abyss\\game\\crash-reports\\crash-2026-11-14.log',
    excerpt: '---- Minecraft Crash Report ----\n// Ooh. Shiny.\n\nDescription: Rendering chunk\njava.lang.OutOfMemoryError: Java heap space',
  };

  const migrationCandidates = [
    { launcher: 'PCL2', path: 'C:\\Users\\Jade\\AppData\\Roaming\\PCL', exists: true, hint: '检测到 PCL2 数据目录，可导入实例与存档' },
    { launcher: 'HMCL', path: 'C:\\Users\\Jade\\AppData\\Roaming\\.hmcl', exists: true, hint: '检测到 HMCL 数据目录，可导入版本与存档' },
    { launcher: '官方启动器', path: 'C:\\Users\\Jade\\AppData\\Roaming\\.minecraft', exists: true, hint: '检测到官方启动器目录' },
  ];

  const migrationPreview = {
    path: 'C:\\Users\\Jade\\AppData\\Roaming\\PCL',
    instances: [
      { name: '1.20.1-Fabric', mcVersion: '1.20.1', loader: 'fabric', loaderVersion: '0.15.11', saves: ['深渊生存'], modsCount: 42, configFiles: 18, totalBytes: 3221225472 },
      { name: '1.18.2-Forge', mcVersion: '1.18.2', loader: 'forge', loaderVersion: '40.2.17', saves: ['Create 工厂'], modsCount: 128, configFiles: 34, totalBytes: 4294967296 },
    ],
  };

  const tasks = [
    { id: 'task-1', name: 'Sodium 0.5.12（模组更新）', kind: 'mod', status: 'running', bytesDone: 682000, bytesTotal: 1100000, speed: 524288, cancelable: true, startedAt: now - 42000, action: { openDir: 'C:\\MCL\\mcl-data\\instances\\inst-abyss\\game\\mods' } },
    { id: 'task-2', name: 'Java 21 (Temurin)', kind: 'java', status: 'done', bytesDone: 192937984, bytesTotal: 192937984, speed: 0, startedAt: now - day, finishedAt: now - day + 180000 },
  ];

  const gameOptions = { renderDistance: '12', simulationDistance: '8', graphicsMode: 'fancy', maxFps: '120', guiScale: '3', particles: 'all' };

  const routes = {
    'app:info': () => ({ name: 'MCL', version: '0.1.0', dataDir: 'C:\\MCL\\mcl-data', platform: 'win32', arch: 'x64', channel: 'stable' }),
    'app:updateCheck': () => ({ current: '0.1.0', latest: '0.1.1', hasUpdate: true, url: 'https://github.com/MistHowlJade/mcl/releases', notes: '修复若干小问题', publishedAt: new Date(now - 2 * day).toISOString(), assets: [] }),
    'app:updateDownload': () => ({ filePath: 'C:\\Users\\Jade\\Downloads\\MCL-0.1.1-portable.exe', fileName: 'MCL-0.1.1-portable.exe', sizeBytes: 89200000 }),
    'app:cacheInfo': () => ({ dir: 'C:\\MCL\\mcl-data\\cache', sizeBytes: 2147483648, files: 342 }),
    'app:clearCache': () => ({ freedBytes: 1073741824, removedFiles: 122 }),
    'app:revealFile': () => true,
    'window:isMaximized': () => false,
    'window:toggleMaximize': () => false,
    'window:setZoom': () => true,
    'settings:get': () => settings,
    'settings:update': (patch) => { deepMerge(settings, patch); return settings; },
    'settings:reset': () => settings,
    'accounts:active': () => accounts[0],
    'accounts:list': () => accounts,
    'accounts:setActive': (id) => accounts.find(a => a.id === id) || null,
    'accounts:createOffline': (name) => { const acc = { id: 'acc-' + Date.now(), type: 'offline', name, uuid: '00000000-0000-0000-0000-000000000000', skinUrl: null, lastUsedAt: now }; accounts.push(acc); return acc; },
    'instances:list': () => instances,
    'instances:get': (id) => instances.find(i => i.id === id) || null,
    'instances:create': (input) => { const inst = { ...instances[0], ...input, id: 'inst-' + Date.now(), gameDir: 'C:\\MCL\\mcl-data\\instances\\new\\game', modsCount: 0, savesCount: 0, createdAt: now, lastPlayedAt: null, playTimeSeconds: 0 }; instances.push(inst); return inst; },
    'instances:update': (id, patch) => { const inst = instances.find(i => i.id === id); if (inst) Object.assign(inst, patch); return inst || null; },
    'instances:diskUsage': () => ({ instance: 3221225472, shared: 5368709120 }),
    'stats:play': () => playStats,
    'versions:list': () => ['1.21', '1.20.6', '1.20.4', '1.20.1', '1.19.4', '1.18.2', '1.16.5', '1.12.2'].map((id, i) => ({ id, type: 'release', releaseTime: new Date(now - (i + 1) * 30 * day).toISOString(), url: '', sha1: '' })),
    'java:detect': () => [
      { path: 'C:\\MCL\\mcl-data\\java\\temurin-17\\bin\\java.exe', version: '17.0.11', major: 17, vendor: 'Eclipse Adoptium', is64: true, managed: true },
      { path: 'C:\\MCL\\mcl-data\\java\\temurin-21\\bin\\java.exe', version: '21.0.3', major: 21, vendor: 'Eclipse Adoptium', is64: true, managed: true },
    ],
    'java:recommended': () => ({ major: 17 }),
    'lan:scan': () => [],
    'server:list': () => servers,
    'server:get': (id) => servers.find(s => s.id === id) || null,
    'server:log': () => ['[12:01:02] [Server thread/INFO]: Starting minecraft server version 1.20.1', '[12:01:03] [Server thread/INFO]: Loading properties', '[12:01:05] [Server thread/INFO]: Preparing level "world"', '[12:01:08] [Server thread/INFO]: Done (5.812s)! For help, type "help"', '[12:03:20] [Server thread/INFO]: Jade joined the game', '[12:03:25] [Server thread/INFO]: Alex joined the game'],
    'server:properties': () => ({ 'server-port': '25565', 'motd': 'MCL 好友生存服', 'max-players': '20', 'online-mode': 'false', 'difficulty': 'normal', 'view-distance': '10', 'pvp': 'true' }),
    'server:backups': () => [{ name: 'world-2026-11-22.zip', filePath: 'C:\\MCL\\mcl-data\\servers\\srv-friends\\backups\\world-2026-11-22.zip', sizeBytes: 524288000, createdAt: now - day }],
    'server:checkPort': () => true,
    'modrinth:search': () => projects,
    'modrinth:searchContent': () => projects,
    'modrinth:installed': () => installedMods,
    'modrinth:checkUpdates': () => installedMods.filter(m => m.updateAvailable),
    'mods:health': () => [{ kind: 'duplicate', modName: 'sodium', detail: '发现两个 Sodium 版本：0.5.11 与 0.5.10', fix: { action: 'quarantine-oldest', target: 'sodium-fabric-0.5.10.jar' } }],
    'backup:list': () => backups,
    'content:list': () => content,
    'content:optionsRead': () => gameOptions,
    'content:optionsSave': (id, patch) => { Object.assign(gameOptions, patch); return gameOptions; },
    'crash:latest': () => crash,
    'crash:analyzeText': () => crash,
    'crash:fix': () => ({ ok: true, message: '已处理' }),
    'migrate:detect': () => migrationCandidates,
    'migrate:preview': () => migrationPreview,
    'logs:list': () => logs,
    'logs:read': () => sampleLog,
    'tasks:list': () => tasks,
    'cloud:inspect': () => ({ exists: true, updatedAt: now - day, sizeBytes: 8388608, location: 'https://dav.example.com/mcl/', note: '最近一次上传成功' }),
    'cloud:test': () => ({ ok: true, message: '连接成功（预览模式）' }),
    'launch:state': () => ({ instanceId: null, status: 'idle', pid: null, message: '', progress: null }),
    'launch:start': (id) => ({ instanceId: id, status: 'running', pid: 5200, message: '游戏已启动（预览）', progress: null }),
    'launch:killResidual': () => 0,
    'mirror:test': () => ({ source: 'auto', latencies: [{ source: '官方', latencyMs: 420, ok: true }, { source: 'BMCLAPI', latencyMs: 38, ok: true }] }),
    'diagnostic:export': () => 'C:\\MCL\\mcl-data\\logs\\diagnostic-preview.zip',
    'dialog:pickFile': () => null,
    'dialog:pickFolder': () => null,
    'modpack:importFile': () => ({ fileName: 'preview.mrpack', path: 'C:\\preview.mrpack', sizeBytes: 1024, instanceId: 'inst-new', warnings: [] }),
    'export:instance': () => ({ filePath: 'C:\\Users\\Jade\\Downloads\\instance.zip', format: 'zip', sizeBytes: 1048576, files: 320 }),
  };

  const listeners = new Map();

  function deepMerge(target, patch) {
    if (!patch || typeof patch !== 'object') return target;
    for (const k of Object.keys(patch)) {
      const v = patch[k];
      if (v && typeof v === 'object' && !Array.isArray(v) && target[k] && typeof target[k] === 'object') deepMerge(target[k], v);
      else target[k] = v;
    }
    return target;
  }

  window.mcl = {
    invoke: async (channel, ...args) => {
      const route = routes[channel];
      if (route) return route(...args);
      if (channel.endsWith(':list')) return [];
      return null;
    },
    on: (channel, cb) => {
      const list = listeners.get(channel) || [];
      list.push(cb);
      listeners.set(channel, list);
      return () => {
        const cur = listeners.get(channel) || [];
        listeners.set(channel, cur.filter(f => f !== cb));
      };
    },
    getDropPaths: () => [],
  };

  console.info('[MCL preview] mock data injected');
})();
